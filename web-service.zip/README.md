# trade.log — trading journal dashboard

A TradeZella-style trading journal. Static frontend (HTML/CSS/vanilla JS,
no build step) deployed on **Cloudflare Pages**, backed by **Supabase**
(auth + database, via Row Level Security) and a small Python/Flask API
(`chart_service.py`, in the companion `chart-service` repo) deployed on
**Render**. A daily GitHub Actions cron kicks off the IBKR sync.

> This project used to be a single-user, no-backend static site (read
> `data/trades.json` off disk, AI features wired through n8n webhooks).
> It has since been migrated to the multi-user/Supabase/Render setup
> described below — see "History" at the bottom if you're looking for
> the old architecture.

## Stack

| Layer | What | Where |
|---|---|---|
| Frontend | Static HTML/CSS/JS, one page per section, shared `common.css` + `common.js` shell | Cloudflare Pages |
| Auth + data | Supabase (`trades`, `trade_details`, `broker_accounts`, `backtest_runs` tables, `user_kv` for settings), Row Level Security scopes every query to `auth.uid()` | Supabase |
| AI / heavy compute | Flask API — chart generation, vision-LLM verdicts, backtesting, support/resistance, chat, CSV import | Render (`chart-service` repo) |
| Daily sync | Pulls the day's IBKR Flex report, matches fills, generates charts, gets an AI verdict, publishes to Supabase | GitHub Actions cron → `POST /daily-sync` on Render |

Pages live at the project root; shared JS lives in `js/` and shared CSS in
`css/` (e.g. `js/config.js`, `css/common.css`).

Every page loads, in this order: `js/config.js` (sets `window.SUPABASE_URL` /
`SUPABASE_ANON_KEY` and the Render API base URL) → the Supabase JS CDN
script → `js/auth.js` (resolves the session, exposes `window.fetchTradesIndex()`
/ `window.fetchTradeDetail()` / etc., and redirects to `login.html` if
there's no session) → the page's own script.

## Pages

**Main nav (all present in every page's sidebar):**

- **`index.html`** — Dashboard / Day View / Reports tabs (hash-routed, one page)
- **`journal.html`** — full trade log, filterable/sortable, deep-linkable via `?setup=`
- **`stats.html`** ("Performance") — equity curve, win rate, setup breakdown, slippage, feedback tally
- **`edge-analysis.html`** — deeper statistical breakdown of what's actually working: setup decay, volume/float tags, confidence ranges (t-test + bootstrap), regret curve, MAE/MFE with stop/target sweeps, position sizing, and a trade-shuffle simulation of losing streaks and drawdown. The bar-level sections (regret + MAE/MFE) share one on-demand run over the most recent 100 trades. Pure math lives in `js/edge-stats.js` (unit-tested: `npm run test:unit`).
- **`patterns.html`** — recurring `lesson_tags` clustered by frequency
- **`calculator.html`** — position-size / risk-per-trade calculator
- **`backtester.html`** — ORB/gap-gainer strategy backtester against real Polygon minute bars
- **`rewind.html`** — chart-reading practice replaying your own logged trades, not graded
- **`practice.html`** — paper-trade a logged chart bar-by-bar; its Analytics tab used to be `practice-analytics.html`
- **`daily.html`** — daily plan (max loss, goal, checklist) and end-of-day review, plus a weekly table and discipline score
- **`settings.html`** — capital ledger (deposits/withdrawals), account prefs

**Per-trade / support:**
- **`trade.html?id=<trade_id>`** — full trade detail: interactive candlestick chart, AI verdict, Support/Resistance (on-demand), star grade, and your own journal card (planned stop/target, setup, mistakes, rules followed, notes)
- **`import-trades.html`** — CSV import of new trades
- **`login.html`** — Supabase email/password sign-in; `auth.js` redirects here on any page when there's no session

**Redirect stubs** (old standalone pages, features moved elsewhere; each just bounces to the new location so old bookmarks/links don't 404):
- `notes.html` → `journal.html` (Notes Search is now the search icon / `/` shortcut in every topbar)
- `chat.html` → `index.html` (AI Chat is now the floating chat bubble on every page)
- `practice-analytics.html` → `practice.html?tab=analytics`
- `playbooks.html` → `stats.html` (the per-setup scorecard it showed is now part of Performance's setup breakdown)

## Shared assets

All shared/page JS lives in `js/`, all shared/page CSS lives in `css/`;
pages themselves (`index.html`, `journal.html`, etc.) stay at the project
root so existing links between pages don't need `js/`/`css/` prefixes.

- **`css/common.css`** — design tokens + app-shell/sidebar layout + additive feature styles (including the floating AI Chat launcher/panel), loaded by every page. Consolidation of what used to be separate `core.css` / `chat-widget.css` / `global-search.css` files.
- Page-specific CSS loaded only where needed: `css/dashboard.css` (Dashboard tab), `css/rewind.css`, `css/practice.css`, `css/quiz-shared.css`, `css/report.css`, `css/ui-modal.css` (shared modal widget, loaded everywhere). Backtester/report-only styles (previously `css/polish.css`) now live in a scoped section at the end of `css/common.css`.
- **`js/common.js`** — shared sidebar (main-nav + "More" section, both generated from a single item list — see `SIDEBAR_MAIN_ITEMS` / `SIDEBAR_MORE_ITEMS`) + mobile-nav wiring + the floating AI Chat widget + `NavState` (mirrors in-page UI state into the URL via `history.replaceState` so Back doesn't lose your place — every page here is a real navigation, not an SPA route). Consolidation of what used to be separate `nav.js` / `chat-widget.js` files.
- **`js/auth.js`** — session/auth layer + `window.KV` (a small per-user key/value store backed by Supabase, used for things like Settings' capital ledger) + `window.fetchTradesIndex()` / `window.fetchTradeDetail()`. Falls back to rejected-promise stubs instead of throwing if the Supabase CDN script fails to load, so a blocked/slow CDN request degrades to an error message instead of a blank broken page.
- **`js/config.js`** — the only file you should need to touch per-deployment: Supabase project URL/anon key, and the Render API base URL used for chart generation, backtesting, AI chat, and Support/Resistance.

## Config

Set in `js/config.js`:

```js
window.SUPABASE_URL = "https://<project>.supabase.co";
window.SUPABASE_ANON_KEY = "<anon key>";       // safe to expose — RLS scopes everything to auth.uid()
window.CHART_SERVICE_URL = "https://<your-render-service>.onrender.com";
window.N8N_SR_URL = "<render>/support-resistance";
window.N8N_CHAT_URL = "<render>/trade-chat";
window.N8N_BACKTEST_AI_URL = "<render>/backtest-ai";
window.N8N_BACKTEST_IMPORT_URL = "<render>/backtest-import";
```

(The `N8N_*` names are historical — these all point straight at the Render
API now, not n8n. See the companion `chart-service` repo's README for what
each route does.)

## Running locally

Browsers block `fetch()` against `file://` URLs, so don't just double-click
`index.html`. Serve the folder instead:

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

You'll need a real Supabase project (with the schema the backend expects —
see the `chart-service` README) and to be logged in via `login.html`
before any page will show data.

## AI features (all now hosted on Render, see `chart-service` repo)

- **Support & Resistance** (on `trade.html`) — off by default, on-demand per click
- **AI Chat** — floating bubble on every page, reads your trade history + optionally one trade's live indicators
- **Backtester** — `POST /backtest/start` + poll `/backtest/status/<job_id>`; "Configure with AI" panel drives it conversationally; "Send to Journal" posts results through the same AI-verdict pipeline as real trades, into that run's own isolated report (never your real journal)

## History

Earlier version of this project was a fully static, single-user,
no-backend site: `data/trades.json` + `data/trades/<id>.json` published by
hand, and the AI features (Support/Resistance, Chat, Backtest config)
wired to n8n webhooks calling Gemini, with a local `chart_service.py` run
via `start_chart_service.ps1` + ngrok for the backtester. That's all been
replaced by the Supabase + Render setup above — n8n is no longer part of
this project. (The one-time `import-legacy.html` tool that moved data
from that era into Supabase has since been removed, now that every
account's history is confirmed migrated.)

## Installable app + seamless page transitions

The site is an installable PWA and is meant to be wrapped as an Android APK
(PWABuilder / Bubblewrap TWA, or Capacitor pointed at the live URL).

- `manifest.json` + `icons/` -- app name, icons, standalone display, theme colour.
- `sw.js` -- service worker. Pre-caches the whole shell on install and serves
  same-origin files (and the supabase-js / lightweight-charts CDN scripts)
  stale-while-revalidate, so page loads come from the device. API calls
  (Supabase, Render, the live-trading tunnel) are never intercepted. A deploy
  shows up one navigation later; bump `CACHE_VERSION` in `sw.js` to force a
  full purge. If you add a page/CSS/JS file, add it to `SHELL` in `sw.js` so
  it is pre-cached (it still works if you forget -- it just caches on first use).
- `js/pwa-register.js` -- registers the service worker; loaded from every page's `<head>`.
- **View transitions** -- `css/common.css` opts every page into cross-document
  view transitions (`@view-transition`), so a normal page load cross-fades from
  the old page instead of flashing a loader; the desktop sidebar is pinned so
  it never animates. `js/page-transition.js` skips the loader overlay when the
  browser supports this (Chrome / Android WebView 126+) and wraps the in-place
  SPA swaps in `document.startViewTransition()`. Browsers without support, or
  with `prefers-reduced-motion`, keep the original loader-overlay behaviour.
- `<link rel="expect" href="#page-title" blocking="render">` in each page's
  `<head>` holds the first paint until the sidebar + topbar exist, so the new
  page never appears half-built inside a transition.


## Reliability notes
- `js/auth.js` retries transient data failures (network blips, 5xx/429, expired JWT with a session refresh, clock skew, hung requests) before any page sees an error; the dashboard/reports page then shows a banner with a Retry button and retries on its own (backoff, `online`, tab refocus).
- `supabase-js` and `lightweight-charts` are self-hosted in `js/vendor/` (no CDN dependency). Bump `CACHE_VERSION` in `sw.js` when you update them.
- `tests/browser-harness/flaky_test.py` injects failures against the real pages.
