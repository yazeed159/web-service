// escapeHtml()/fmtMoney() moved to utils.js, which now loads first on
// every page (before config.js) -- that fixes the load-order problem
// that kept them stuck here as a copy no other page could safely call
// yet. See utils.js for the canonical forms and what drifted.

// chat-widget.js — floating "AI Chat" launcher, shared by every app-shell
// page. Used to be its own sidebar tab pointing at chat.html; now it's a
// small popup like most normal sites' chat widgets, with a maximize
// button for a bigger view. Injects the launcher button + panel markup
// into the page, then loads chat.js (unmodified) against it -- chat.js
// only ever touches elements by id (#chat-messages, #chat-form, etc.),
// so it works identically whether those ids live on a full page or in
// this floating panel.
(function () {
  "use strict";

  // Login page has no trade data and no sidebar/topbar chrome -- skip.
  if (/\/login(\.html)?\/?$/.test(window.location.pathname)) return;
  if (!document.getElementById("sidebar")) return;

  const OPEN_KEY = "trade.log:chatWidgetOpen";

  const launcher = document.createElement("button");
  launcher.type = "button";
  launcher.id = "chatw-launcher";
  launcher.className = "chatw-launcher";
  launcher.title = "AI Chat";
  launcher.setAttribute("aria-label", "Open AI chat");
  launcher.innerHTML = `
    <svg aria-hidden="true" focusable="false" class="chatw-icon-chat" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
    <svg aria-hidden="true" focusable="false" class="chatw-icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
  `;

  const panel = document.createElement("div");
  panel.id = "chatw-panel";
  panel.className = "chatw-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "AI Chat");
  panel.setAttribute("aria-hidden", "true");
  launcher.setAttribute("aria-expanded", "false");
  launcher.setAttribute("aria-controls", "chatw-panel");
  panel.innerHTML = `
    <div class="chatw-panel-head">
      <span class="chatw-head-icon"><svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l1.9 5.8L20 10l-6.1 2.2L12 18l-1.9-5.8L4 10l6.1-2.2z"></path></svg></span>
      <span class="chatw-panel-title">AI Chat</span>
      <span class="chatw-panel-actions">
        <button type="button" class="chatw-icon-action" id="chatw-hints-btn" title="Suggested questions" aria-label="Show suggested questions" aria-pressed="false">
          <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"></path><path d="M10 22h4"></path><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2.05V17h6v-.25c0-.85.4-1.55 1-2.05A7 7 0 0 0 12 2z"></path></svg>
        </button>
        <button type="button" class="chatw-icon-action" id="chatw-maximize-btn" title="Maximize" aria-label="Maximize chat">
          <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"></path><path d="M21 8V5a2 2 0 0 0-2-2h-3"></path><path d="M3 16v3a2 2 0 0 0 2 2h3"></path><path d="M16 21h3a2 2 0 0 0 2-2v-3"></path></svg>
        </button>
        <button type="button" class="chatw-icon-action" id="chatw-close-btn" title="Close" aria-label="Close chat">
          <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </span>
    </div>
    <div class="chatw-body chat-content">
      <div class="chat-shell">
        <div class="chat-data-status" id="chat-data-status" role="status" aria-live="polite">
          <span class="chat-data-status-dot"></span> Loading your trade data…
        </div>
        <div class="chat-messages" id="chat-messages" role="log" aria-live="polite" aria-relevant="additions" aria-label="Conversation"></div>
        <div class="chat-chips" id="chat-chips" role="group" aria-label="Suggested questions"></div>
        <form class="chat-input-row" id="chat-form">
          <input
            type="text"
            id="chat-input"
            class="chat-input"
            aria-label="Message to AI Chat"
            placeholder="Ask about a trade, setup, or your stats…"
            autocomplete="off"
            disabled
          >
          <button type="submit" class="chat-send-btn" id="chat-send-btn" aria-label="Send message" disabled>
            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
          </button>
        </form>
      </div>
    </div>
  `;

  document.body.appendChild(panel);
  document.body.appendChild(launcher);

  function setOpen(open) {
    panel.setAttribute("aria-hidden", String(!open));
    launcher.setAttribute("aria-expanded", String(open));
    launcher.setAttribute("aria-label", open ? "Close AI chat" : "Open AI chat");
    panel.classList.toggle("open", open);
    launcher.classList.toggle("open", open);
    if (!open) {
      // Reset maximize state on close so the launcher (hidden while
      // maximized, see below) always comes back once the panel isn't
      // covering it anymore, and the panel reopens at its normal size.
      panel.classList.remove("maximized");
      launcher.classList.remove("chatw-launcher-hidden");
    }
    try { sessionStorage.setItem(OPEN_KEY, open ? "1" : "0"); } catch (e) { /* ignore */ }
  }

  launcher.addEventListener("click", () => setOpen(!panel.classList.contains("open")));
  document.getElementById("chatw-close-btn").addEventListener("click", () => setOpen(false));
  document.getElementById("chatw-maximize-btn").addEventListener("click", (e) => {
    const isMax = panel.classList.toggle("maximized");
    // The round launcher button sits fixed at bottom-right in every
    // state, but the maximized panel's own bottom-right corner grows
    // to almost the same spot -- without this it sat directly on top
    // of the input row/send button. The header already has its own
    // close button, so just hide the redundant launcher while maximized.
    launcher.classList.toggle("chatw-launcher-hidden", isMax);
    e.currentTarget.title = isMax ? "Restore" : "Maximize";
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && panel.classList.contains("open")) setOpen(false);
  });

  // Reopen automatically if the person had it open before navigating to
  // this page -- conversation history itself is per-page-load (same as
  // the old chat.html always was), only the open/closed state persists.
  let startOpen = false;
  try { startOpen = sessionStorage.getItem(OPEN_KEY) === "1"; } catch (e) { /* ignore */ }
  if (startOpen) setOpen(true);

  // chat.js expects #chat-messages/#chat-form/etc. to already exist (it
  // looks them up as soon as it runs, not on DOMContentLoaded), so it's
  // only loaded now that the panel markup above is in the DOM.
  // chat-facts.js (the free local stats engine) goes first; dynamically inserted scripts with
  // async=false still run in insertion order. chat.js works without it (plain AI calls only).
  ["js/chat/chat-facts.js", "js/chat/chat.js"].forEach(function (src) {
    const chatScript = document.createElement("script");
    chatScript.src = src;
    chatScript.async = false;
    document.body.appendChild(chatScript);
  });
})();


// nav.js — shared sidebar/mobile-nav wiring for every page, plus a
// shared URL-state helper (see NavState below).
//
// Every page ships the same app-shell sidebar (#sidebar), a desktop
// collapse toggle (#sidebar-toggle), and a mobile hamburger button
// (#mobile-nav-btn) in the topbar. This used to be ~20 lines of
// identical inline <script> duplicated across nine pages, and three
// more pages (practice.html, quiz.html, rewind.html) shipped the
// hamburger button with no wiring at all, so tapping it did nothing.
// This file is the single implementation, loaded by every page.

// ---------------------------------------------------------------------
// NavState — mirrors a page's in-memory UI state (which month/day is
// open, which filters/sort/tab are active, how many rows are shown,
// ...) into that page's own query string, instead of only living in a
// JS variable.
//
// Every page here is a full navigation, not an SPA route -- clicking a
// trade opens trade.html as a real new document, and hitting Back
// reloads THIS page fresh, re-running all its JS from scratch. Any
// state that only ever lived in a `let` variable is gone at that
// point; the page falls back to whatever its hardcoded defaults are
// (today's month, no filters, first page of rows, ...) instead of
// where the person actually was. That's the "back button forgets
// where I was" bug.
//
// The fix: whenever that state changes, write it into the URL with
// history.replaceState (so browsing around doesn't pile up new
// history entries -- there's still exactly one entry for this page,
// it just keeps getting its query string updated). Back navigation
// then reloads this exact URL, and reading the same query string back
// out on boot puts the page back where it was.
window.NavState = (function () {
  "use strict";

  function readParams() {
    return new URLSearchParams(window.location.search);
  }

  // Reads one field back out of the URL. Always returns a string (or
  // `fallback`) -- callers are responsible for parsing numbers/JSON/etc.
  function get(key, fallback) {
    const v = readParams().get(key);
    return v === null ? fallback : v;
  }

  // Merges `updates` into the current query string and replaces the
  // current history entry with the result (hash is left untouched, so
  // this plays nicely with pages like index.html that use the hash for
  // which tab is active). A value of null/undefined/"" removes that key
  // instead of writing it, so optional/default state doesn't clutter
  // every URL.
  function set(updates) {
    const params = readParams();
    Object.keys(updates).forEach((k) => {
      const v = updates[k];
      if (v === null || v === undefined || v === "") params.delete(k);
      else params.set(k, String(v));
    });
    const qs = params.toString();
    const url = window.location.pathname + (qs ? "?" + qs : "") + window.location.hash;
    history.replaceState(history.state, "", url);
  }

  return { get, set };
})();

// Sidebar nav rendering (the Journal/More link lists + active-page
// highlight) used to live here, but ran too late -- see js/core/nav-render.js,
// which now loads right after the sidebar markup on each page instead of
// at the bottom with the rest of this file.


(function () {
  const sidebar = document.getElementById("sidebar");
  const sidebarToggle = document.getElementById("sidebar-toggle");
  if (!sidebar) return; // page doesn't use the app-shell sidebar

  // Every page is a separate load (this isn't an SPA), so without this
  // the collapsed/expanded choice was thrown away and reset to expanded
  // on every single click into a new page -- that's the "collapse
  // never sticks" bug. Applied synchronously, before anything else runs,
  // so the sidebar never flashes expanded-then-collapsed on load.
  const COLLAPSE_KEY = "sidebar-collapsed";
  try {
    if (localStorage.getItem(COLLAPSE_KEY) === "1") {
      sidebar.classList.add("collapsed");
    }
  } catch (e) {
    // localStorage unavailable (private browsing, etc.) -- collapse
    // just won't persist across pages; the toggle itself still works.
  }

  const sidebarBackdrop = document.createElement("div");
  sidebarBackdrop.className = "sidebar-backdrop";
  document.body.appendChild(sidebarBackdrop);

  function closeMobileNav() {
    sidebar.classList.remove("mobile-open");
  }

  sidebarBackdrop.addEventListener("click", closeMobileNav);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMobileNav();
  });

  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      if (window.innerWidth <= 760 && sidebar.classList.contains("mobile-open")) {
        closeMobileNav();
      } else {
        sidebar.classList.toggle("collapsed");
        try {
          localStorage.setItem(COLLAPSE_KEY, sidebar.classList.contains("collapsed") ? "1" : "0");
        } catch (e) {
          // ignore -- see comment above
        }
      }
    });
  }

  // Delegated on document (not bound directly to mobileNavBtn) so it
  // keeps working even if the SPA router (js/core/page-transition.js) ever
  // swaps in a topbar that recreates this button -- a direct binding
  // would go dead the moment its original element is replaced. Not
  // currently exercised (the router keeps the topbar itself out of
  // the swapped region), but costs nothing and removes a footgun for
  // whoever changes that later.
  document.addEventListener("click", (e) => {
    if (e.target.closest("#mobile-nav-btn")) {
      sidebar.classList.toggle("mobile-open");
    }
  });

  // Exposed so pages with their own tab-switching logic (index.html)
  // can close the mobile drawer on navigation without re-implementing it.
  window.closeMobileNav = closeMobileNav;

  // Touch swipe for the mobile drawer, so it behaves like any other
  // app's off-screen nav instead of only opening via the topbar button:
  // swipe right from the screen's left edge to open it, swipe left
  // anywhere on the open drawer (or its backdrop) to close it. Bound on
  // `document` (not just the sidebar) so the open-gesture works from
  // wherever the page currently is -- edgeStartMaxX keeps it from
  // hijacking an ordinary left-to-right drag/scroll started elsewhere
  // on the page.
  if (window.bindSwipe) {
    window.bindSwipe(document, {
      edgeStartMaxX: 24,
      onSwipeRight: () => { if (window.innerWidth <= 760) sidebar.classList.add("mobile-open"); },
    });
    window.bindSwipe(sidebar, { onSwipeLeft: closeMobileNav });
    window.bindSwipe(sidebarBackdrop, { onSwipeLeft: closeMobileNav });
  }
})();


/* modern.js — additive interactivity layer.
 * Safe by design: only ever *adds* classes/listeners to elements
 * that already exist. Never touches app.js/trade.js/etc. state. */
(function () {
  'use strict';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 1. Scroll-reveal for panels/cards ---------- */
  function initReveal() {
    if (reduced || !('IntersectionObserver' in window)) return;
    var targets = document.querySelectorAll(
      '.panel-box, .card, .chart-panel, .equity-panel, .day-group, .playbook-card, .highlight-card, .dash-hero, .kpi-card'
    );
    if (!targets.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry, i) {
        if (entry.isIntersecting) {
          var el = entry.target;
          setTimeout(function () { el.classList.add('reveal-in'); }, Math.min(i * 40, 240));
          io.unobserve(el);
        }
      });
    }, { threshold: 0, rootMargin: '0px 0px -40px 0px' });
    targets.forEach(function (el) {
      if (el.dataset.revealBound) return; // boot() can run more than once
      el.dataset.revealBound = '1';
      // Elements that start (or are later toggled) display:none -- like
      // #bt-progress-box, hidden until a backtest starts -- report a 0x0
      // box here and can never satisfy the IntersectionObserver once
      // they're shown, since they aren't "scrolled into view" so much as
      // switched on by other JS. Binding them anyway meant they sat at
      // opacity:0 (from .reveal-init) until the 1800ms safety net caught
      // up -- so clicking "Run Backtest" soon after page load unhid an
      // invisible box, looking like the page had emptied out. Skip
      // reveal-on-scroll for anything not actually laid out right now;
      // it'll just render normally (opacity:1) whenever it's shown.
      if (getComputedStyle(el).display === 'none') return;
      // Tall content (e.g. a 300+ row table inside a panel) can be so much
      // taller than the viewport that it never satisfies an area-based
      // threshold. Only defer elements short enough to plausibly start
      // off-screen; anything else just reveals immediately.
      if (el.getBoundingClientRect().height > window.innerHeight * 1.2) return;
      el.classList.add('reveal-init');
      io.observe(el);
    });
    // Safety net: never leave anything stuck invisible (e.g. content that
    // grows taller than the viewport only after app.js populates it async).
    setTimeout(function () {
      document.querySelectorAll('.reveal-init:not(.reveal-in)').forEach(function (el) {
        el.classList.add('reveal-in');
      });
    }, 1800);
  }

  /* ---------- 2. Ripple on click for buttons ---------- */
  var rippleBound = false;
  function initRipple() {
    if (reduced || rippleBound) return;
    // Delegated on document, so it already covers any element matching
    // the selector that exists NOW or is added later (e.g. by the SPA
    // router swapping in a new page's buttons) -- bind it once, ever.
    // boot() (below) can run more than once (see initReveal's comment),
    // and re-adding this same delegated listener on every call would
    // stack duplicates, firing the ripple effect multiple times per click.
    rippleBound = true;
    // Selector originally covered every clickable control except a
    // handful of "tab" families that happened to ship later
    // (subtab-btn, pr-view-tab, tf-btn, pp-size-mode-btn, calc-chip,
    // chatw-icon-action) -- so pressing those didn't ripple while
    // near-identical toggle buttons elsewhere (toptab-btn, nav-item,
    // quiz-mode-btn) did. Added below so every "press one of these to
    // switch view/mode" control behaves the same everywhere.
    // (qz-move-stop-btn isn't listed separately -- it already matches
    // via its own .btn-advanced class.)
    var selector = '.filter-btn, .icon-btn, .cal-nav-btn, .sidebar-toggle, .nav-item, .btn-advanced, .btn-confirm, .btn-danger, .btn-icon, .sr-run-btn, .toptab-btn, .pp-order-btn, .quiz-answer-btn, .quiz-mode-btn, .quiz-preset-btn, .qz-speed-btn, .quiz-speed-btn, .subtab-btn, .pr-view-tab, .tf-btn, .pp-size-mode-btn, .calc-chip, .chatw-icon-action';
    document.addEventListener('click', function (e) {
      var el = e.target.closest(selector);
      if (!el) return;
      var rect = el.getBoundingClientRect();
      var x = e.clientX - rect.left;
      var y = e.clientY - rect.top;
      // Radius reaches the button's farthest corner from the click point.
      // Using rect.width/height directly (the old approach) blew the
      // ripple way past the button on wide, short controls like the
      // report tab bar -- the circle ballooned way beyond the button.
      var radius = Math.sqrt(Math.pow(Math.max(x, rect.width - x), 2) + Math.pow(Math.max(y, rect.height - y), 2));
      var size = radius * 2;
      var span = document.createElement('span');
      span.className = 'ripple';
      span.style.width = span.style.height = size + 'px';
      span.style.left = (x - radius) + 'px';
      span.style.top = (y - radius) + 'px';
      // Both of these are only ever SET here, temporarily, to contain the
      // ripple circle -- never restored, until now. That was silently
      // breaking flex layouts: a flex item's automatic minimum width is
      // its content width (it won't shrink below its own text) ONLY while
      // overflow stays 'visible'. The moment overflow becomes 'hidden',
      // that floor drops to 0, so any flex container short on space
      // (a horizontally-scrolling tab strip on a phone, e.g. the Reports
      // top tabs, being the tightest case) is then free to squeeze the
      // clicked button down to nothing -- and since the style was never
      // undone, it stayed that way forever after the first tap. Restore
      // both once the ripple animation is done (and only once every
      // ripple on this element has finished, in case of a fast double
      // click) so the element goes back to its normal, protected sizing.
      var addedPosition = false, addedOverflow = false;
      var prevPos = getComputedStyle(el).position;
      if (prevPos === 'static') { el.style.position = 'relative'; addedPosition = true; }
      if (getComputedStyle(el).overflow === 'visible') { el.style.overflow = 'hidden'; addedOverflow = true; }
      el.appendChild(span);
      span.addEventListener('animationend', function () {
        span.remove();
        if (!el.querySelector('.ripple')) {
          if (addedOverflow) el.style.overflow = '';
          if (addedPosition) el.style.position = '';
        }
      });
    }, true);
  }

  /* ---------- 3. Flash numeric values when app.js updates them ---------- */
  function initValueFlash() {
    if (reduced || !('MutationObserver' in window)) return;
    var selector = '.stat .value, .pnl-breakdown .cell .value, .streak-strip .cell .value, ' +
      '.cal-summary-strip .cell .value, .equity-head .value, .score-gauge .num, .pb-value';
    var seen = new WeakMap();
    var mo = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        var el = m.target.nodeType === 3 ? m.target.parentElement : m.target;
        if (!el || !el.matches || !el.matches(selector)) return;
        var text = el.textContent;
        if (seen.get(el) === text) return;
        seen.set(el, text);
        el.classList.remove('value-settled');
        void el.offsetWidth;
        el.classList.add('value-settled');
      });
    });
    document.querySelectorAll(selector).forEach(function (el) {
      seen.set(el, el.textContent);
      mo.observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  /* ---------- 4. Subtle magnetic tilt on stat cards (desktop only) ---------- */
  function initTilt() {
    if (reduced || window.matchMedia('(pointer: coarse)').matches) return;
    document.querySelectorAll('.stat, .highlight-card').forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        var r = card.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5;
        var y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = 'perspective(600px) rotateX(' + (-y * 3) + 'deg) rotateY(' + (x * 3) + 'deg)';
      });
      card.addEventListener('mouseleave', function () { card.style.transform = ''; });
    });
  }

  /* ---------- 5. Glass spotlight: a soft highlight follows the cursor across cards (mouse only) ---------- */
  var spotBound = false;
  function initGlassSpot() {
    if (reduced || spotBound || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    spotBound = true;
    var SEL = '.card, .panel-box, .equity-panel, .chart-panel, .day-group, .stat-grid, .pnl-breakdown, .streak-strip, .cal-summary-cells, .th-card, .calc-box, .ts-card, .rr-strip';
    var last = null, raf = 0, px = 0, py = 0, target = null;
    function paint() {
      raf = 0;
      if (!target) return;
      var r = target.getBoundingClientRect();
      target.style.setProperty('--mx', (px - r.left) + 'px');
      target.style.setProperty('--my', (py - r.top) + 'px');
    }
    function clear(el) { if (el) { el.style.removeProperty('--mx'); el.style.removeProperty('--my'); } }
    document.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      var el = e.target && e.target.closest ? e.target.closest(SEL) : null;
      if (el !== last) { clear(last); last = el; }
      target = el; px = e.clientX; py = e.clientY;
      if (el && !raf) raf = requestAnimationFrame(paint);
    }, { passive: true });
    document.addEventListener('pointerleave', function () { clear(last); last = null; target = null; }, true);
  }

  function boot() {
    initGlassSpot();
    initReveal();
    initRipple();
    initValueFlash();
    initTilt();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Exposed for the SPA router to call after swapping in new content --
  // re-applies scroll-reveal/value-flash/tilt to the freshly-added
  // elements. initRipple() is a no-op past its first call (see above).
  window.__rebootDecor = boot;

  /* Re-run reveal/tilt hookup after tab switches or late DOM insertions
     (app.js renders dashboard content async on load). */
  window.addEventListener('load', function () {
    setTimeout(boot, 250);
  });
})();

// ---------------------------------------------------------------------
// Hover-prefetch for sidebar navigation. Every nav-item is a real
// full-page link (journal.html, stats.html, etc.), so the biggest part
// of the "loading" feeling on navigation is just network wait for the
// next document. Warming the browser's cache for a link as soon as the
// pointer lands on it (people reliably pause on a link for a beat
// before clicking) means that by the time the click actually happens,
// the page is often already cached -- so the loading screen in
// common.css barely has anything left to cover, and the switch reads
// as instant, without changing how any page loads or is built.
(function () {
  "use strict";
  var done = Object.create(null);
  function prefetch(url) {
    if (!url || done[url]) return;
    done[url] = true;
    var link = document.createElement("link");
    link.rel = "prefetch";
    link.href = url;
    document.head.appendChild(link);
  }
  document.addEventListener("pointerenter", function (e) {
    var a = e.target.closest && e.target.closest(".nav-item[href], .sidebar a[href]");
    if (!a) return;
    var href = a.getAttribute("href");
    if (href && !/^(https?:)?\/\//.test(href) && href.indexOf("#") !== 0) prefetch(href);
  }, true);
})();

// ================================================================
// SETUP/TAG STYLING (shared by journal, trade detail, patterns,
// practice, rewind -- anywhere a setup_type or lesson tag is shown).
// Every tag renders in the same single accent color (the app's
// primary/brand color) instead of a different hue per tag -- a
// calmer, more professional look than a rainbow of per-tag colors.
(function () {
  "use strict";
  window.setupTagStyle = function () {
    return {
      bg: "var(--primary-soft)",
      border: "rgba(139,124,246,0.3)",
      fg: "var(--primary)",
    };
  };
  // Inline style-attribute shorthand for a colored pill: background +
  // border + text all in the shared accent color.
  window.setupTagStyleAttr = function () {
    var c = window.setupTagStyle();
    return "background:" + c.bg + ";border-color:" + c.border + ";color:" + c.fg + ";";
  };
  // Just a small dot, for places already showing the label as plain
  // text (table rows, breakdown lists) where a full recolored pill
  // would be too heavy.
  // Readable names for the three rule-based setups (chart-service setups.py)
  // plus "other"; anything else just loses its underscores.
  var SETUP_LABELS = { red_to_green: "Red-to-green", green_over_green_wick: "Green-over-green wick", ema9_dip_buy: "9 EMA dip buy", chase: "Chase", other: "Other" };
  // Behavior tags (chart-service trade_tags.py), stored on trades.behavior_tags.
  window.BEHAVIOR_TAG_LABELS = {
    session_early_premarket: "Early premarket (4–7)", session_pre_open: "Pre-open (7–9:30)", session_open: "Open (9:30–10)",
    session_midday: "Midday (10–15)", session_power_hour: "Power hour (15–16)", session_after_hours: "After hours",
    scaled_in: "Scaled in", scaled_out: "Scaled out", added_to_loser: "Added to loser", revenge_trade: "Revenge trade",
    overtrading: "Overtrading", repeat_symbol: "Repeat symbol", oversized: "Oversized",
    below_vwap: "Entry below VWAP", below_ema9: "Entry below 9 EMA", gave_back_winner: "Gave back winner",
    winner_turned_loser: "Winner turned loser", overstayed: "Overstayed", ran_after_exit: "Ran after exit",
    clean_trade: "Clean trade", extended_entry: "Extended entry", entry_after_spike: "Entry after spike",
    new_high_of_day: "New high of day", premarket_high_break: "Premarket high break", vwap_reclaim: "VWAP reclaim",
    sold_the_low: "Sold the low", sold_near_high: "Sold near the high", deep_drawdown: "Deep drawdown",
    sized_up_after_loss: "Sized up after loss", after_losing_streak: "After 3 losses in a row", rapid_fire: "Rapid-fire re-entry",
    hold_under_1m: "Held < 1 min", hold_1_5m: "Held 1–5 min", hold_5_30m: "Held 5–30 min", hold_30m_plus: "Held 30+ min",
    price_under_2: "Price under $2", price_2_5: "Price $2–5", price_5_10: "Price $5–10", price_10_plus: "Price $10+",
  };
  window.SETUP_TYPES = ["red_to_green", "green_over_green_wick", "ema9_dip_buy", "chase", "other"];
  window.setupLabel = function (v) {
    var k = String(v == null ? "" : v);
    return Object.prototype.hasOwnProperty.call(SETUP_LABELS, k) ? SETUP_LABELS[k] : k.replace(/_/g, " ");
  };
  window.setupTagDot = function () {
    var c = window.setupTagStyle();
    return '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:' + c.fg + ';margin-right:6px;vertical-align:middle;"></span>';
  };
})();

/* ---- UI refresh helpers: collapsible explainers + Settings section nav ---- */
(function () {
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  function enhanceExplainers() {
    var items = document.querySelectorAll(".edge-intro:not([data-xp]), .calc-intro:not([data-xp])");
    items.forEach(function (el) {
      el.setAttribute("data-xp", "1");
      var key = "tl:explainer:" + (el.getAttribute("data-xp-key") || (el.classList.contains("edge-intro") ? "edge" : "calc"));
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "xp-toggle";
      function paint() {
        var collapsed = el.classList.contains("xp-collapsed");
        btn.textContent = collapsed ? "Show intro" : "Hide";
        btn.setAttribute("aria-expanded", collapsed ? "false" : "true");
      }
      btn.addEventListener("click", function () {
        el.classList.toggle("xp-collapsed");
        lsSet(key, el.classList.contains("xp-collapsed") ? "1" : "0");
        paint();
      });
      // First visit shows the intro; once seen, it starts collapsed.
      if (lsGet(key) === "1") el.classList.add("xp-collapsed");
      else if (lsGet(key) === null && "IntersectionObserver" in window) {
        // Mark as seen only once it has actually been on screen for a moment
        // (it may sit inside a tab that is not open yet).
        var io = new IntersectionObserver(function (ents) {
          if (!ents.some(function (e) { return e.isIntersecting; })) return;
          io.disconnect();
          setTimeout(function () { lsSet(key, el.classList.contains("xp-collapsed") ? "1" : "1"); }, 1500);
        });
        io.observe(el);
      }
      el.appendChild(btn);
      paint();
    });
  }

  function buildSettingsNav() {
    var content = document.querySelector(".main .content");
    if (!content || document.getElementById("page-title") == null) return;
    if (document.getElementById("page-title").textContent.trim() !== "Settings") return;
    if (content.querySelector(".set-nav")) return;
    var boxes = content.querySelectorAll(":scope > .panel-box");
    if (boxes.length < 3) return;
    var nav = document.createElement("nav");
    nav.className = "set-nav";
    nav.setAttribute("aria-label", "Settings sections");
    boxes.forEach(function (box, i) {
      var t = box.querySelector(".panel-box-head .title");
      if (!t) return;
      if (!box.id) box.id = "set-sec-" + i;
      var a = document.createElement("a");
      a.href = "#" + box.id;
      a.textContent = t.textContent.trim();
      a.addEventListener("click", function (e) {
        e.preventDefault();
        box.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      nav.appendChild(a);
    });
    content.classList.add("has-set-nav");
    content.insertBefore(nav, content.firstChild);
  }

  function run() { enhanceExplainers(); buildSettingsNav(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", run); else run();
  new MutationObserver(function () { run(); }).observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
document.addEventListener("click", function (e) {
  var b = e.target.closest && e.target.closest(".pr-empty-cta");
  if (!b) return;
  var go = document.getElementById("pf-random-btn");
  if (go) go.click();
});
