// page-transition.js — lightweight SPA router for a subset of pages,
// full-page-navigation bridge for everything else.
//
// Two tiers of navigation live here:
//
// 1. SPA_PAGES (below): the click is intercepted, the destination is
//    fetched as plain HTML, and only the page's OWN content is swapped
//    in -- the sidebar, topbar (including global-search.js's injected
//    search box), loader overlay, and floating chat widget are never
//    touched. No document unload, no blank-white gap, no refetching
//    common.css/fonts. This is what actually removes the flicker.
//
// 2. Every other link: unchanged from before -- a normal full page
//    load, with the loader overlay/progress bar re-armed on click so
//    the outgoing and incoming page both show the same idle screen at
//    the seam (see common.css's "Full-screen loading screen" comment).
//
// Deliberately NOT in SPA_PAGES: stats.html / edge-analysis.html
// (own a lightweight-charts equity/price chart instance),
// backtester.html / rewind.html / practice.html / trade.html (chart +
// canvas), live-trading.html (polling), scanner.html, import-trades.html
// (polls an in-progress import with setInterval). None of those have
// been taught to tear down their chart instance / interval / observer
// before their DOM is replaced -- doing that blind, without a live
// browser + real backend to test against, risks a chart or a poll
// loop that keeps running invisibly against a page that's no longer
// on screen. Moving one of those into SPA_PAGES later means auditing
// that page's own script for exactly that first, then giving it a
// window.__pageTeardown() the swap can call before it goes.
//
// Known page-specific regions of the persistent shell (checklist for
// adding a new one): the shell -- sidebar + topbar chrome -- is built
// on the assumption that it's identical across every page, which is
// what lets swapContent() below leave it alone entirely. Twice now
// that assumption has quietly been false for one small region at a
// time (a bug that looks exactly like "stale label/highlight that
// won't update"), because a per-page difference got hand-written into
// the sidebar's raw HTML instead of being computed at render time:
//   - the sidebar's main nav section (Dashboard/Day View/Reports/
//     Journal) -- fixed by swapSidebarMain() below
//   - the sidebar-bottom "pipeline status" label -- fixed by
//     swapSidebarBottom() below
// Before adding anything new to the sidebar or topbar that varies by
// page (a badge, a count, a per-page tooltip, anything not driven by
// nav-render.js's mount points), either drive it from the mount-point
// pattern (so nav-render.js's re-run after a swap keeps it correct
// for free) or add a swap step here alongside the two above -- don't
// assume swapContent() below will pick it up, since by design it only
// ever touches .main.
(function () {
  "use strict";

  var currentPath = window.location.pathname; // path of the document currently on screen (see popstate below)
  var overlay = document.getElementById("page-loader-overlay");
  var bar = document.getElementById("page-progress-bar");
  if (!overlay && !bar) return;

  // View Transitions. When the browser supports them (Chrome/Android WebView
  // 126+), pages cross-fade with the old page held on screen until the new one
  // has painted, so the loader overlay is not needed at the seam and is skipped:
  //   - CROSS_DOC_VT: full page loads (@view-transition in common.css)
  //   - SAME_DOC_VT:  in-place SPA swaps below (document.startViewTransition)
  // Anything else -- older browsers, or prefers-reduced-motion -- keeps the
  // original loader-overlay behaviour untouched.
  var reducedMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var CROSS_DOC_VT = typeof window.CSSViewTransitionRule !== "undefined" && !reducedMotion;
  var SAME_DOC_VT = typeof document.startViewTransition === "function" && !reducedMotion;

  // Keyed by the normalized destination filename (see normalizeFile
  // below -- matches with or without ".html", so it works whether the
  // link/URL is "journal.html" or the clean "/journal" the Worker
  // actually serves in production).
  //
  //   shared: utility scripts this page needs that are safe to load
  //   ONCE and never touch again (they expose an API / render on
  //   demand -- e.g. window.TradeGrade, window.UIModal -- rather than
  //   binding to specific DOM elements at load time). Injected only if
  //   not already present, so visiting these pages in a different
  //   order than usual (e.g. landing on Settings first) still works.
  //
  //   owned: this page's OWN script(s) -- always given a fresh
  //   <script> element on every visit, because their init code has to
  //   run again against the freshly-swapped DOM (the browser only
  //   RE-EXECUTES a script when a new element for it is inserted; it
  //   won't re-run just because the URL matches one already on the
  //   page). Same-URL re-insertion still comes out of the browser's
  //   HTTP cache, so this doesn't mean a fresh network request.
  //
  // Each page's inline <script> block(s) (if any) are handled
  // automatically below -- always re-run, in document order, no need
  // to list them here.
  var SPA_PAGES = {
    // app.js was split into four files (shared/dashboard/dayview/reports --
    // see the comment at the top of app-shared.js). All four are "owned":
    // each needs a fresh re-run against the freshly-swapped DOM, and this
    // array's order is load order -- app-shared.js MUST come first, since
    // it builds window.App and the other three register onto it.
    // today-strip.js (dashboard "Today" card) sits between shared and dashboard so
    // App.tabs.dashboard.renderToday exists before the first data render.
    index: { shared: ["js/trade/grade.js", "js/trade/trade-notes.js", "js/daily/daily-notes.js", "js/daily/loss-limit.js"], owned: ["js/dashboard/app-shared.js", "js/dashboard/today-strip.js", "js/dashboard/app-dashboard.js", "js/dashboard/app-dayview.js"] },
    journal: { shared: ["js/trade/grade.js"], owned: ["js/trade/share-export.js"] },
    patterns: { shared: [], owned: [] },
    calculator: { shared: [], owned: ["js/tools/calculator.js"] },
    settings: { shared: ["js/core/ui-modal.js"], owned: [] }
  };

  // Self-heal for the "skeleton that never resolves until I refresh" failure, on EVERY page.
  // After a page has had 12s to load, if a visible loading skeleton is STILL sitting in the
  // content, reload (the same cure as the manual refresh, minus the manual part: a fresh load
  // gets a fresh connection and a fresh session check). Guarded: at most twice per page per
  // 5 minutes (so a genuinely down backend can't cause a reload loop), and never while the tab
  // is hidden. Long-running tool pages are left out on purpose -- their spinners are legitimate.
  var NO_WATCHDOG = { "backtester": 1, "live-trading": 1, "scanner": 1, "import-trades": 1, "login": 1 };
  function armSkeletonWatchdog() {
    var path = currentPath;
    if (NO_WATCHDOG[keyFor(path)]) return;
    function stuck() {
      return Array.prototype.some.call(document.querySelectorAll(".main .loading-line"), function (el) {
        return el.offsetParent !== null;
      });
    }
    function check() {
      if (currentPath !== path) return;
      if (document.hidden) {
        document.addEventListener("visibilitychange", function once() {
          if (document.hidden) return;
          document.removeEventListener("visibilitychange", once);
          setTimeout(check, 4000);
        });
        return;
      }
      if (!stuck()) return;
      try {
        var log = JSON.parse(sessionStorage.getItem("tl:skel-reload") || "{}");
        var now = Date.now();
        var hits = (log[path] || []).filter(function (t) { return now - t < 300000; });
        if (hits.length >= 2) return;
        hits.push(now); log[path] = hits;
        sessionStorage.setItem("tl:skel-reload", JSON.stringify(log));
      } catch (e) { /* storage blocked: reload anyway, once per page view */ }
      window.location.reload();
    }
    setTimeout(check, 12000);
  }

  function normalizeFile(name) {
    try {
      return decodeURIComponent(name || "").toLowerCase().replace(/\/+$/, "").replace(/\.html$/, "");
    } catch (e) {
      return String(name || "").toLowerCase().replace(/\.html$/, "");
    }
  }
  function keyFor(pathname) {
    return normalizeFile(pathname.split("/").pop()) || "index";
  }

  function showLoader() {
    // Both re-shows happen with transitions/animations forced off and
    // a synchronous reflow in between, so the "covered" state is what
    // paints on the very next frame -- not something that eases in
    // over a couple hundred ms while the page underneath is still
    // visible and about to be torn down anyway.
    if (overlay) {
      overlay.style.transition = "none";
      overlay.classList.remove("done");
      void overlay.offsetHeight;
      overlay.style.transition = "";
    }
    if (bar) {
      bar.classList.remove("done");
      bar.style.animation = "none";
      void bar.offsetWidth;
      bar.style.animation = "";
    }
  }

  function hideLoader() {
    if (window.__renderSidebarNav) {
      // nav-render.js's tail is what normally fades these back out
      // once a fresh page's shell is ready -- reuse the exact same
      // path here instead of duplicating its fade timing.
      window.__renderSidebarNav();
    } else {
      if (bar) bar.classList.add("done");
      if (overlay) overlay.classList.add("done");
    }
  }

  function loadScriptOnce(src) {
    if (document.querySelector('script[src="' + src + '"]')) return Promise.resolve();
    return new Promise(function (resolve) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = resolve; // one missing/broken utility shouldn't stall the whole swap
      document.body.appendChild(s);
    });
  }

  function loadScriptFresh(src) {
    return new Promise(function (resolve) {
      var s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = resolve;
      document.body.appendChild(s);
    });
  }

  // Runs a page's scripts against the DOM that was just swapped in:
  // shared utilities first (only if missing), then this page's own
  // external script(s) in order, then its inline block(s) in order.
  //
  // `stale()` reports that a newer navigation has started since this one
  // did. Clicking two sidebar links quickly used to run BOTH swaps to the end
  // in whatever order their fetches happened to finish, so the slower, older
  // page could land last and sit on screen under the wrong URL/title -- the
  // "have to refresh to get the right page" behaviour. A stale swap now stops
  // before it touches the DOM or runs another script.
  function runPageScripts(cfg, newDoc, stale) {
    var chain = Promise.resolve();
    stale = stale || function () { return false; };
    (cfg.shared || []).forEach(function (src) {
      chain = chain.then(function () { return stale() ? null : loadScriptOnce(src); });
    });
    (cfg.owned || []).forEach(function (src) {
      chain = chain.then(function () { return stale() ? null : loadScriptFresh(src); });
    });
    return chain.then(function () {
      if (stale()) return;
      var inline = newDoc.querySelectorAll("body > script:not([src])");
      inline.forEach(function (old) {
        var s = document.createElement("script");
        s.textContent = old.textContent;
        document.body.appendChild(s);
      });
    });
  }

  // Swaps in the new page's content while leaving the topbar element
  // itself in place (only its #page-title text changes) -- the topbar
  // is where global-search.js self-mounts its search box exactly
  // once, on first load. Replacing the whole topbar element on every
  // navigation would take that search box with it, since it's DOM
  // that script injected, not markup that exists in the raw HTML.
  // Page-specific <style> blocks live in each page's <head>, which a swap
  // never touches -- so arriving at Settings/Calculator via the sidebar left
  // their inline CSS behind and the page rendered completely unstyled (every
  // .int-card expanded, no layout) until a hard refresh. Sync them here:
  // drop styles a previous swap injected, then add the destination's own
  // unless an identical block is already in the document.
  function syncPageStyles(newDoc) {
    Array.prototype.slice.call(document.head.querySelectorAll("style[data-spa-style]")).forEach(function (el) {
      el.remove();
    });
    Array.prototype.slice.call(newDoc.head.querySelectorAll("style")).forEach(function (st) {
      var css = st.textContent;
      var exists = Array.prototype.some.call(document.head.querySelectorAll("style"), function (el) {
        return el.textContent === css;
      });
      if (exists) return;
      var copy = document.createElement("style");
      copy.setAttribute("data-spa-style", "");
      copy.textContent = css;
      document.head.appendChild(copy);
    });
  }

  // Linked stylesheets: the same problem as the inline <style> blocks above, but
  // worse. dashboard.css (the hero, KPI cards, calendar...) is only <link>ed by
  // index.html/stats.html, ui-modal.css only by a few others -- so arriving at the
  // Dashboard from Journal/Reports/etc. via the sidebar swapped in the dashboard
  // markup with its stylesheet missing, and the top of the page rendered as an
  // unstyled, half-built version until a hard refresh. Here every destination
  // <link rel="stylesheet"> not already in the document is added, and the swap
  // WAITS for them to load (the old page stays on screen meanwhile), so the new
  // content never paints without its CSS. Links are kept once added (they're cached
  // and harmless to later pages), and a slow/failed sheet can't block more than 4s.
  function absHref(href) {
    try { var u = new URL(href, document.baseURI); u.hash = ""; return u.href; } catch (e) { return href; }
  }
  // Same-origin stylesheet links of a document, in source order. Third-party sheets
  // (Google Fonts) are shared by every page and left alone.
  function localSheets(doc) {
    return Array.prototype.filter.call(doc.head.querySelectorAll('link[rel~="stylesheet"][href]'), function (l) {
      return !/^(https?:)?\/\//.test(l.getAttribute("href"));
    });
  }
  function ensureStylesheets(newDoc) {
    var have = {};
    localSheets(document).forEach(function (l) { have[absHref(l.getAttribute("href"))] = l; });
    var waits = [], prev = null;
    localSheets(newDoc).forEach(function (l) {
      var href = l.getAttribute("href"), key = absHref(href);
      if (have[key]) { prev = have[key]; return; }
      var link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      have[key] = link;
      waits.push(new Promise(function (resolve) {
        var timer = setTimeout(resolve, 4000);
        link.onload = link.onerror = function () { clearTimeout(timer); resolve(); };
      }));
      // Keep the destination's own source order (cascade order matters: e.g. ui-modal.css
      // comes after mobile.css on Journal) by slotting each new sheet after the sheet that
      // precedes it in the destination's <head>.
      if (prev && prev.parentNode) prev.parentNode.insertBefore(link, prev.nextSibling);
      else document.head.insertBefore(link, document.head.querySelector('link[rel~="stylesheet"][href]') || null);
      prev = link;
    });
    return waits.length ? Promise.all(waits) : Promise.resolve();
  }
  // After the swap: drop page-specific sheets the destination doesn't use, so each page
  // ends up with exactly the stylesheets a fresh load of it would have (dashboard.css
  // restyling Journal, or page A's rules leaking onto page B, is the mirror-image bug).
  function pruneStylesheets(newDoc) {
    var want = {};
    localSheets(newDoc).forEach(function (l) { want[absHref(l.getAttribute("href"))] = true; });
    localSheets(document).forEach(function (l) {
      if (!want[absHref(l.getAttribute("href"))]) l.remove();
    });
  }

  function swapContent(newDoc) {
    var curMain = document.querySelector(".main");
    var newMain = newDoc.querySelector(".main");
    syncPageStyles(newDoc);
    if (!curMain || !newMain) throw new Error("no .main to swap");

    var curTopbar = curMain.querySelector(".topbar");
    var newTopbar = newMain.querySelector(".topbar");
    var newTitleEl = newMain.querySelector("#page-title");
    if (curTopbar && newTitleEl) {
      var curTitleEl = curTopbar.querySelector("#page-title");
      if (curTitleEl) curTitleEl.textContent = newTitleEl.textContent;
    }
    // .topbar-left is the ONLY part of the topbar that differs by page: it
    // holds the title plus page-specific pills (index.html's #date-range,
    // backtester's #bt-api-pill, report's #rpt-range-pill). The topbar stays
    // in place across navigations (see above), so those pills used to be
    // whatever the PREVIOUS page had -- meaning a page script that looks
    // one up (app-shared.js sets #date-range) found null and threw. That
    // was the "Couldn't load this section... until I refresh" bug: it only
    // happened when you arrived via the sidebar from another page, and a
    // full refresh (which loads the page's own topbar) always fixed it.
    // Resync .topbar-left from the fetched page. .topbar-right and the
    // search box are identical everywhere / injected by script, so they are
    // left alone.
    if (curTopbar && newTopbar) {
      var curLeft = curTopbar.querySelector(".topbar-left");
      var newLeft = newTopbar.querySelector(".topbar-left");
      if (curLeft && newLeft) {
        curLeft.innerHTML = "";
        Array.prototype.slice.call(newLeft.childNodes).forEach(function (node) {
          curLeft.appendChild(document.importNode(node, true));
        });
      }
    }

    Array.prototype.slice.call(curMain.children).forEach(function (el) {
      if (el !== curTopbar) el.remove();
    });
    Array.prototype.slice.call(newMain.children).forEach(function (el) {
      if (!el.classList || !el.classList.contains("topbar")) {
        curMain.appendChild(document.importNode(el, true));
      }
    });
  }

  // The sidebar's "Journal" section (Dashboard/Day View/Reports/Journal)
  // is the one part of the persistent sidebar whose markup differs by
  // page: index.html hand-writes real <button data-tab> elements there
  // (app.js needs to bind to actual elements, not ones nav-render.js
  // templates in later), while every other page just holds an empty
  // <div id="sidebar-main-section"> for nav-render.js to fill in.
  //
  // Because swapContent() above only ever touches .main -- the sidebar
  // itself is left alone on purpose, to avoid re-flashing it -- leaving
  // index.html's page controlled this region never got reconciled when
  // navigating to/from index.html: nav-render.js's renderNav() (which
  // hideLoader() calls) looks for #sidebar-main-section to update, and
  // on index.html that id doesn't exist, so the stale buttons (with
  // whatever "active" class they had before we left) just sat there
  // through every subsequent SPA page. Explicitly swapping this one
  // region to match the destination page -- before hideLoader()'s
  // renderNav() call -- fixes that for both directions: landing on a
  // normal page gets a fresh empty mount for renderNav() to fill
  // correctly, and landing back on index.html gets its real buttons
  // back for app.js's owned re-run to bind and set correctly.
  function swapSidebarMain(newDoc) {
    var curMoreMount = document.getElementById("sidebar-more-section");
    var newMoreMount = newDoc.getElementById("sidebar-more-section");
    if (!curMoreMount || !newMoreMount) return; // unexpected shape -- leave sidebar alone rather than guess

    // Walk backward from the (stable, always-present) More mount to the
    // section label that starts this region, in the freshly-fetched doc.
    var newNodes = [];
    var n = newMoreMount.previousSibling;
    while (n) {
      if (n.nodeType === 1 && n.classList && n.classList.contains("nav-section-label")) break;
      newNodes.unshift(n);
      n = n.previousSibling;
    }

    // Remove the current document's equivalent range.
    var c = curMoreMount.previousSibling;
    while (c) {
      var prev = c.previousSibling;
      if (c.nodeType === 1 && c.classList && c.classList.contains("nav-section-label")) break;
      c.remove();
      c = prev;
    }

    // Insert clones of the destination's nodes in its place.
    newNodes.forEach(function (node) {
      curMoreMount.parentNode.insertBefore(document.importNode(node, true), curMoreMount);
    });
  }

  // The sidebar's bottom "pipeline status" strip has exactly the same
  // problem as the main nav section above, for the same underlying
  // reason (the sidebar lives outside .main and is never swapped): every
  // page hardcodes its OWN name there as static text -- "Journal",
  // "Scanner", "Settings", etc. -- except index.html, which instead
  // holds a <span id="last-updated"> that app.js fills in dynamically
  // (last trade date / "Loading…" / "No data"). Whichever page's label
  // happened to be there when the SPA router last ran just sat there
  // unchanged through every subsequent swap -- e.g. leaving scanner.html
  // (not itself an SPA page, but still whatever the sidebar last showed)
  // for journal.html left the strip reading \"Scanner\" while every panel
  // above it was clearly Journal's. Resyncing it from the freshly
  // fetched document on every swap, the same way as the main nav
  // section, fixes it for both the static-label pages and index.html
  // (whose own app.js re-run then fills the restored placeholder in, as
  // it does on a normal full load).
  function swapSidebarBottom(newDoc) {
    var curBottom = document.querySelector(".sidebar-bottom");
    var newBottom = newDoc.querySelector(".sidebar-bottom");
    if (!curBottom || !newBottom) return; // unexpected shape -- leave it alone rather than guess
    curBottom.innerHTML = "";
    Array.prototype.slice.call(newBottom.childNodes).forEach(function (node) {
      curBottom.appendChild(document.importNode(node, true));
    });
  }

  if (document.readyState === "complete") armSkeletonWatchdog();
  else window.addEventListener("load", armSkeletonWatchdog, { once: true });

  var navSeq = 0; // bumped by every swap; a swap whose number is no longer current is stale

  function swapTo(url, cfg, push) {
    var mySeq = ++navSeq;
    function stale() { return mySeq !== navSeq; }
    // A page whose own script wired up a window.__<page>Teardown() hook
    // (currently just app.js's window.__appTeardown, guarding index.html's
    // trade-data fetch/render pass and its nav/hashchange listeners) gets
    // torn down here, before its DOM is swapped out from under it -- not
    // just when a fresh copy of the same script reloads itself. Without
    // this, leaving index.html for a different SPA page still left its
    // listeners live and pointed at DOM that no longer exists.
    if (window.__appTeardown) window.__appTeardown();
    if (!SAME_DOC_VT) showLoader();
    fetch(url.href, { credentials: "same-origin" })
      .then(function (res) {
        if (!res.ok) throw new Error("bad response");
        return res.text();
      })
      .then(function (html) {
        if (stale()) return; // a newer click superseded this one while it was in flight
        var newDoc = new DOMParser().parseFromString(html, "text/html");
        // Make sure the destination's stylesheets are loaded BEFORE anything is swapped.
        return ensureStylesheets(newDoc).then(function () { return newDoc; });
      })
      .then(function (newDoc) {
        if (stale()) return;

        // Everything that mutates the live page. With view transitions this
        // runs inside document.startViewTransition(): the browser snapshots the
        // old page, waits for this to finish (including the destination's
        // scripts), then cross-fades to the result -- no loader overlay.
        function apply() {
          if (push) history.pushState({ spa: true }, "", url.href);
          currentPath = url.pathname;
          // mobile-extras.js: ScrollMemory only restores on Back/Forward arrivals,
          // and a pull-to-refresh handler belongs to the page that's leaving.
          window.__navKind = push ? "push" : "pop";
          if (window.PullRefresh) window.PullRefresh.set(null);
          document.title = newDoc.title || document.title;
          swapContent(newDoc);
          pruneStylesheets(newDoc);
          swapSidebarMain(newDoc);
          swapSidebarBottom(newDoc);
          return runPageScripts(cfg, newDoc, stale).then(function () {
            if (stale()) return; // the newer swap owns the scroll position, decor and loader now
            window.scrollTo(0, 0);
            if (window.__rebootDecor) window.__rebootDecor();
            hideLoader();
            armSkeletonWatchdog();
          });
        }

        if (SAME_DOC_VT) {
          var vt = document.startViewTransition(apply);
          return vt.updateCallbackDone.then(function () { return vt.finished; });
        }
        return apply();
      })
      .catch(function () {
        if (stale()) return; // a newer click already took over; don't hijack it
        // Any failure (network, parse, missing .main) falls back to a
        // real navigation instead of leaving the page stuck mid-swap.
        window.location.href = url.href;
      });
  }

  document.addEventListener(
    "click",
    function (e) {
      if (e.defaultPrevented || e.button !== 0) return;
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

      var a = e.target.closest("a");
      if (!a || !a.getAttribute("href")) return;
      if (a.target && a.target !== "_self") return;
      if (a.hasAttribute("download")) return;

      var href = a.getAttribute("href");
      if (
        href.charAt(0) === "#" ||
        href.indexOf("javascript:") === 0 ||
        href.indexOf("mailto:") === 0 ||
        href.indexOf("tel:") === 0
      ) {
        return;
      }

      var url;
      try {
        url = new URL(a.href, window.location.href);
      } catch (err) {
        return;
      }
      if (url.origin !== window.location.origin) return;

      // A same-document hash jump (in-page anchors, or the hash-based
      // tab switching some pages do in JS) never unloads this page,
      // so there's nothing here for the loader/router to bridge.
      if (url.pathname === window.location.pathname && url.hash) return;

      var cfg = SPA_PAGES[keyFor(url.pathname)];
      // Only swap in place when the page we're LEAVING is an SPA page too.
      // Leaving scanner/live-trading/stats/backtester/etc. by swapping their
      // DOM out from under them leaves their timers, polls and chart
      // instances running against elements that no longer exist (errors
      // like "Cannot set properties of null"), which is why those pages
      // are deliberately not in SPA_PAGES. From them, do a normal full load.
      var fromCfg = SPA_PAGES[keyFor(window.location.pathname)];
      if (cfg && fromCfg) {
        e.preventDefault();
        swapTo(url, cfg, true);
        return;
      }

      // Full page load. Where cross-document view transitions exist the old
      // page simply stays on screen until the new one paints; otherwise cover
      // the seam with the loader overlay as before.
      if (!CROSS_DOC_VT) showLoader();
    },
    true
  );

  // Back/forward between two SPA-swapped entries replays the same
  // in-place swap; anything else (e.g. the entry predates this page's
  // own load, or points at a non-SPA page) falls back to a real
  // reload, since there's no fetched document to diff against here.
  window.addEventListener("popstate", function (e) {
    // Fragment-only navigation (index.html's tab buttons set location.hash)
    // also fires popstate in Chrome. That is not a page change: this
    // handler used to answer it with location.replace(sameUrl), which is
    // itself a fragment navigation -> popstate again -> infinite recursion
    // ("Maximum call stack size exceeded"). Same path = same document:
    // leave it to the page's own hashchange handling.
    if (window.location.pathname === currentPath) return;
    var cfg = SPA_PAGES[keyFor(window.location.pathname)];
    if (cfg && e.state && e.state.spa) {
      swapTo(new URL(window.location.href), cfg, false);
    } else if (CROSS_DOC_VT) {
      // Not a reload, so the browser can cross-fade it like any other
      // navigation; the URL is already the destination's after popstate.
      window.location.replace(window.location.href);
    } else {
      window.location.reload();
    }
  });

  // A back/forward navigation can restore this exact document from the
  // browser's bfcache mid-fade from whenever the loader was last shown
  // -- make sure a restored page always comes back clear instead of
  // possibly stuck on the loading screen.
  window.addEventListener("pageshow", function (e) {
    if (!e.persisted) return;
    if (overlay) overlay.classList.add("done");
    if (bar) bar.classList.add("done");
  });
})();
