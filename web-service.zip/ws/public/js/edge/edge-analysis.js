// edge-analysis.js — edge-analysis page logic (bucket breakdowns, regret
// analysis, drill-down detail fetches). Used to be an inline <script>
// block in edge-analysis.html; pulled out into its own file, same reason
// as calculator.js -- it was the other of the two remaining pages still
// doing this, and it's exactly where the leaking-chart bug (chart
// instances built inside repeated drill-down calls with no teardown)
// turned up, which is easier to spot and lint in a real .js file.
(function () {
  "use strict";

  const content = document.getElementById("edge-content");
  const REGRET_MAX = 100; // cap on how many detail files a bar-level run will fetch

  let allSorted = [];
  let regretResults = [];
  let excursionResults = []; // {row, exc:{mae,mfe,bars}} -- filled by the same bar-level run as regretResults
  let shuffleSeed = 987654;
  let rowSeq = 0;
  let explainSeq = 0;
  const summaryState = { totalTrades: 0, baseline: 0, flaggedSetups: 0, totalSetups: 0, sizingTellActive: null, regretCapture: null, pValue: null, streak95: null };
  let decayGroups = {};
  let decayRows = [];
  let decaySort = { key: "n", dir: -1 };

  // Auto-recovering load (same idea as app-shared.js): a failed FETCH (network
  // blip, token that expired while the tab slept) retries by itself with a
  // backoff, immediately when the network returns or the tab is refocused, and
  // offers a Retry button. A failure while DRAWING is a real bug, so it is
  // reported once and never loops.
  let loadTries = 0;
  let retryTimer = null;
  const MAX_AUTO_RETRIES = 6;
  function load() {
    clearTimeout(retryTimer);
    return window.fetchTradesIndex().then(
      (rows) => {
        loadTries = 0;
        try { render(Array.isArray(rows) ? rows : []); }
        catch (err) {
          console.error("[edge-analysis] render failed:", err);
          content.innerHTML = `<div class="empty-state">Something went wrong drawing this page (${escapeHtml(String(err.message))}). Your data loaded fine. <button type="button" class="btn-advanced" onclick="location.reload()">Reload</button></div>`;
        }
      },
      (err) => {
        loadTries++;
        const willRetry = loadTries <= MAX_AUTO_RETRIES;
        content.innerHTML = `<div class="empty-state">Couldn't load your trades (${escapeHtml(String((err && err.message) || err))}). ${willRetry ? "Retrying automatically…" : "Automatic retries used up."} <button type="button" class="btn-advanced" data-retry>Retry now</button></div>`;
        const btn = content.querySelector("[data-retry]");
        if (btn) btn.addEventListener("click", () => { loadTries = 0; load(); });
        if (willRetry) retryTimer = setTimeout(load, Math.min(3000 * Math.pow(2, loadTries - 1), 30000));
      }
    );
  }
  load();
  window.addEventListener("online", () => { if (loadTries > 0) { loadTries = 0; load(); } });
  document.addEventListener("visibilitychange", () => { if (!document.hidden && loadTries > 0) { loadTries = 0; load(); } });
  // Picks up trades that landed while this tab sat in the background
  // (see app-shared.js's identical call for the full reasoning) --
  // this page isn't an SPA page (see page-transition.js), so it only
  // ever loads once and the listener never needs teardown.
  window.refreshOnFocus(load);
  // mobile-extras.js loads after this script, so register once the page has finished parsing.
  (function () {
    const reg = () => { if (window.PullRefresh) window.PullRefresh.set(load); };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", reg); else reg();
  })();

  // See app.js's identical helper for why this exists: renderDecay /
  // renderVolume / renderSizing each own a totally different section of
  // this page, so one throwing on some edge-case field shouldn't stop
  // the others from rendering or leave their "Loading…" placeholder
  // stuck forever.
  function safeRender(fn, label) {
    try { fn(); } catch (err) { console.error(`[edge-analysis] ${label} failed:`, err); }
  }
  function clearStrandedLoadingStates() {
    content.querySelectorAll(".loading-line").forEach((el) => {
      const container = el.parentElement || el;
      container.innerHTML = '<div class="empty-state small">Couldn\'t load this section — check the console for details.</div>';
    });
  }

  // ---------- shared helpers (same conventions as stats.html / journal.html) ----------
// escapeHtml() now in utils.js (loads first on every page).
// fmtMoney() now in utils.js (loads first on every page).
  function avg(arr) {
    if (!arr.length) return 0;
    return arr.reduce((s, v) => s + v, 0) / arr.length;
  }
  function pctWin(trades) {
    if (!trades.length) return 0;
    return Math.round((trades.filter((t) => t.win).length / trades.length) * 1000) / 10;
  }
  function groupBy(rows, keyFn) {
    const g = {};
    for (const r of rows) { const k = keyFn(r); (g[k] = g[k] || []).push(r); }
    return g;
  }
  // Rendered TRADE_LIST_PAGE_SIZE at a time with a "Load more" button --
  // see the identical comment in app.js -- rather than dumping every
  // trade behind a breakdown row into the DOM at once.
  // tradeListItemHtml/tradeListMoreHtml/tradeListHtml/
  // TRADE_LIST_PAGE_SIZE/tradeListState now in utils.js. The
  // toggle/load-more behavior itself is also shared via
  // window.bindTradeToggles -- this file's own copy just needed to
  // additionally track openUids + call syncUrlState, so that's passed
  // through as the onChange(uid, isOpen) callback instead.
  function bindTradeToggles(container) {
    window.bindTradeToggles(container, (uid, isOpen) => {
      if (isOpen === true) openUids.add(uid);
      else if (isOpen === false) openUids.delete(uid);
      syncUrlState();
    });
  }

  // ---------- URL state (see NavState in nav.js) ----------
  // edge-trades-N uids come from a counter that resets to 0 each render
  // and is handed out in a fixed order (decay rows, then volume/float
  // rows, then sizing rows -- see the render() call order below), so
  // for the same trade data and the same decay-table sort they come out
  // identical from one page load to the next. That's what makes it safe
  // to persist which uids are open across a reload.
  const openUids = new Set();
  function syncUrlState() {
    const shownObj = {};
    openUids.forEach((uid) => {
      const state = tradeListState.get(uid);
      if (state && state.shown > TRADE_LIST_PAGE_SIZE) shownObj[uid] = state.shown;
    });
    const decaySel = document.getElementById("decay-setup-select");
    NavState.set({
      dsort: (decaySort.key !== "n" || decaySort.dir !== -1) ? `${decaySort.key}:${decaySort.dir}` : null,
      dsel: (decaySel && decaySel.value) || null,
      open: openUids.size ? JSON.stringify(Array.from(openUids)) : null,
      shown: Object.keys(shownObj).length ? JSON.stringify(shownObj) : null,
    });
  }
  // Re-opens whichever breakdown rows were expanded (and re-loads
  // however many rows had been paged into them). Called once at the end
  // of render(), after decay/volume/sizing have all populated
  // tradeListState for this page load -- and after decaySort has
  // already been restored (below), so the decay rows' uids land in the
  // same order they did last time.
  function restoreTradeListState() {
    let openArr = [];
    let shownObj = {};
    try { openArr = JSON.parse(NavState.get("open", "[]")) || []; } catch (e) { /* malformed/old URL, ignore */ }
    try { shownObj = JSON.parse(NavState.get("shown", "{}")) || {}; } catch (e) { /* malformed/old URL, ignore */ }
    openArr.forEach((uid) => {
      const list = document.getElementById(uid);
      const state = tradeListState.get(uid);
      if (!list || !state) return;
      list.classList.add("open");
      openUids.add(uid);
      const desired = shownObj[uid];
      if (desired && desired > state.shown) {
        const nextShown = Math.min(desired, state.rows.length);
        const newItemsHtml = state.rows.slice(state.shown, nextShown).map(tradeListItemHtml).join("");
        state.shown = nextShown;
        const moreLi = list.querySelector(".tag-trade-list-more");
        if (moreLi) {
          moreLi.insertAdjacentHTML("beforebegin", newItemsHtml);
          if (state.shown < state.rows.length) {
            const btn = moreLi.querySelector("[data-load-more]");
            if (btn) btn.textContent = `Load more (${state.rows.length - state.shown} left)`;
          } else {
            moreLi.remove();
          }
        }
      }
    });
  }
  function makeChart(el, height, extraOpts) {
    // Every caller (renderDecayChart, renderRegretTradeChart,
    // renderSizingChart) re-runs against the same container on ordinary
    // interaction -- switching the "setup" or "trade" dropdown re-renders
    // its chart every time. Each caller does el.innerHTML = "" first, but
    // that only clears the DOM; it doesn't dispose the previous
    // LightweightCharts instance or the window resize listener below, so
    // without this, every dropdown change orphaned another chart engine
    // (still running internally, invisible, forever) plus another resize
    // listener stacked on top of the last. Track both on the container
    // itself (innerHTML = "" doesn't touch JS properties on the node) and
    // tear down whatever was there before building the new one.
    if (el._chart) { try { el._chart.remove(); } catch (e) {} }
    if (el._chartResizeHandler) { window.removeEventListener("resize", el._chartResizeHandler); }
    const edgeCt = window.chartThemeColors ? window.chartThemeColors() : { text: "#8b8fa3", grid: "#1b1e26", border: "#262a34" };
    const chart = LightweightCharts.createChart(el, Object.assign({
      width: el.clientWidth,
      height,
      layout: { background: { color: "transparent" }, textColor: edgeCt.text },
      grid: { vertLines: { color: edgeCt.grid }, horzLines: { color: edgeCt.grid } },
      rightPriceScale: { borderColor: edgeCt.border },
      timeScale: { borderColor: edgeCt.border },
    }, (window.ChartIndicators ? window.ChartIndicators.touchChartOpts() : {}), extraOpts || {}));
    const onResize = () => chart.applyOptions({ width: el.clientWidth });
    window.addEventListener("resize", onResize);
    el._chart = chart;
    el._chartResizeHandler = onResize;
    return chart;
  }

  // Bars render at width:0 with their real target stashed in data-w, so
  // they can grow in instead of just appearing already-filled -- called
  // right after any bar-row markup is dropped into the DOM.
  function animateBarFills(root) {
    if (!root) return;
    const bars = root.querySelectorAll(".bar-fill[data-w]");
    if (!bars.length) return;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        bars.forEach((b) => { b.style.width = b.dataset.w + "%"; });
      });
    });
  }

  // ---------- explainer: short blurb + expandable deep-dive, one per section ----------
  function explainBlock(blurb, deepDiveHtml) {
    const uid = `edge-explain-${explainSeq++}`;
    return `
      <div class="edge-explain">
        <p class="edge-explain-blurb">${blurb}</p>
        <button type="button" class="edge-explain-toggle" data-explain-toggle="${uid}" aria-expanded="false">
          <span>How this works</span>
          <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </button>
        <div class="edge-explain-body" id="${uid}" hidden>${deepDiveHtml}</div>
      </div>`;
  }
  function bindExplainToggles(root) {
    (root || document).querySelectorAll("[data-explain-toggle]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const body = document.getElementById(btn.getAttribute("data-explain-toggle"));
        const wasOpen = btn.getAttribute("aria-expanded") === "true";
        btn.setAttribute("aria-expanded", String(!wasOpen));
        if (body) body.hidden = wasOpen;
      });
    });
  }
  function sectionIcon(pathsSvg) {
    return `<span class="edge-section-icon">${pathsSvg}</span>`;
  }
  const ICON_DECAY = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 8-8"></path><path d="M15 7h6v6"></path></svg>`;
  const ICON_VOLUME = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="20" x2="4" y2="10"></line><line x1="10" y1="20" x2="10" y2="4"></line><line x1="16" y1="20" x2="16" y2="14"></line><line x1="22" y1="20" x2="22" y2="8"></line></svg>`;
  const ICON_REGRET = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>`;
  const ICON_SIZING = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="12" width="4" height="9"></rect><rect x="10" y="7" width="4" height="14"></rect><rect x="17" y="3" width="4" height="18"></rect></svg>`;

  const ICON_CONF = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="4" x2="12" y2="20"></line><line x1="8" y1="4" x2="16" y2="4"></line><line x1="8" y1="20" x2="16" y2="20"></line><circle cx="12" cy="12" r="2"></circle></svg>`;
  const ICON_EXCURSION = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18"></path><path d="M8 7l4-4 4 4"></path><path d="M8 17l4 4 4-4"></path></svg>`;
  const ICON_SHUFFLE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 3 21 3 21 8"></polyline><line x1="4" y1="20" x2="21" y2="3"></line><polyline points="21 16 21 21 16 21"></polyline><line x1="15" y1="15" x2="21" y2="21"></line><line x1="4" y1="4" x2="9" y2="9"></line></svg>`;

  // ---------- edge-health summary strip ----------
  function statIcon(pathsSvg) { return `<svg class="label-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${pathsSvg}</svg>`; }
  function renderEdgeHealthSummary() {
    const el = document.getElementById("edge-health");
    if (!el) return;
    const flagPct = summaryState.totalSetups ? Math.round((summaryState.flaggedSetups / summaryState.totalSetups) * 100) : null;
    const sizingLabel = summaryState.sizingTellActive === null ? "—" : (summaryState.sizingTellActive ? "Active" : "Clean");
    const sizingCls = summaryState.sizingTellActive === true ? "down" : (summaryState.sizingTellActive === false ? "up" : "");
    const regretLabel = summaryState.regretCapture === null ? "Not run yet" : `${Math.round(summaryState.regretCapture * 100)}%`;
    const regretCls = summaryState.regretCapture === null ? "" : (summaryState.regretCapture >= 0.6 ? "up" : "down");
    const pLabel = summaryState.pValue === null ? "—" : (summaryState.pValue < 0.001 ? "p < 0.001" : "p = " + summaryState.pValue.toFixed(3));
    const pCls = summaryState.pValue === null ? "" : (summaryState.pValue < 0.05 ? "up" : "");
    const streakLabel = summaryState.streak95 === null ? "—" : summaryState.streak95 + " in a row";
    el.innerHTML = `
      <div class="stat" title="Every synced trade in your account">
        <div class="label-row"><span class="label">Trades Analyzed</span>${statIcon('<rect x="3" y="3" width="7" height="9" rx="1.5"></rect><rect x="14" y="3" width="7" height="5" rx="1.5"></rect><rect x="14" y="12" width="7" height="9" rx="1.5"></rect><rect x="3" y="16" width="7" height="5" rx="1.5"></rect>')}</div>
        <div class="value">${summaryState.totalTrades}</div>
        <div class="sub-value">${summaryState.baseline}% overall win rate</div>
      </div>
      <div class="stat" title="Setups whose win rate is fading or looks driven by a recent hot streak — see Edge Decay below">
        <div class="label-row"><span class="label">Setups Flagged</span>${statIcon('<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line>')}</div>
        <div class="value ${summaryState.flaggedSetups > 0 ? "down" : "up"}">${summaryState.flaggedSetups} / ${summaryState.totalSetups}</div>
        <div class="sub-value">${flagPct === null ? "—" : flagPct + "%"} fading or recency-driven</div>
      </div>
      <div class="stat" title="Whether you tend to size up right before a losing stretch — see Position Sizing below">
        <div class="label-row"><span class="label">Sizing Tell</span>${statIcon('<rect x="3" y="12" width="4" height="9"></rect><rect x="10" y="7" width="4" height="14"></rect><rect x="17" y="3" width="4" height="18"></rect>')}</div>
        <div class="value ${sizingCls}">${sizingLabel}</div>
        <div class="sub-value">sizing up before a bad stretch</div>
      </div>
      <div class="stat" title="How much of each trade's best available price you actually captured — run the Regret Curve below to fill this in">
        <div class="label-row"><span class="label">Best-Bar Capture</span>${statIcon('<circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline>')}</div>
        <div class="value ${regretCls}">${regretLabel}</div>
        <div class="sub-value">avg. of best bar-close, when run</div>
      </div>
      <div class="stat" title="t-test of average P&L per trade against zero — see Confidence Ranges below">
        <div class="label-row"><span class="label">Edge vs. Zero</span>${statIcon('<line x1="12" y1="4" x2="12" y2="20"></line><line x1="8" y1="4" x2="16" y2="4"></line><line x1="8" y1="20" x2="16" y2="20"></line><circle cx="12" cy="12" r="2"></circle>')}</div>
        <div class="value ${pCls}">${pLabel}</div>
        <div class="sub-value">${summaryState.pValue !== null && summaryState.pValue < 0.05 ? "avg. P&amp;L is distinguishable from zero" : "can't yet rule out zero edge"}</div>
      </div>
      <div class="stat" title="Longest losing streak that shows up in 1 of 20 shuffled orderings of your trades — see Losing Streaks &amp; Drawdown below">
        <div class="label-row"><span class="label">Streak to Plan For</span>${statIcon('<polyline points="16 3 21 3 21 8"></polyline><line x1="4" y1="20" x2="21" y2="3"></line><polyline points="21 16 21 21 16 21"></polyline><line x1="15" y1="15" x2="21" y2="21"></line><line x1="4" y1="4" x2="9" y2="9"></line>')}</div>
        <div class="value">${streakLabel}</div>
        <div class="sub-value">losing streak, 95th pct of shuffles</div>
      </div>
    `;
  }

  // ---------- sticky jump-nav with scrollspy ----------
  function initJumpnav() {
    const nav = document.getElementById("edge-jumpnav");
    if (!nav) return;
    const pills = Array.from(nav.querySelectorAll(".pill[data-section]"));
    pills.forEach((pill) => {
      pill.addEventListener("click", () => {
        const target = document.getElementById(pill.dataset.section);
        if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
    if (!("IntersectionObserver" in window)) return;
    const sections = pills.map((p) => document.getElementById(p.dataset.section)).filter(Boolean);
    const setActive = (id) => {
      pills.forEach((p) => p.classList.toggle("active", p.dataset.section === id));
    };
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: "-30% 0px -60% 0px", threshold: 0 });
    sections.forEach((s) => io.observe(s));
  }

  // ---------- page shell ----------
  function render(rows) {
    if (!rows.length) {
      content.innerHTML = window.emptyStateHtml({
        icon: "target",
        title: "No trades yet",
        message: "Edge analysis — decay, regret trades, sizing quality, and the rest — needs published trades to work from.",
        actionHref: "import-trades.html", actionLabel: "Import trades",
      });
      return;
    }
    allSorted = rows.slice().sort((a, b) => ((a.trade_date || "") + (a.entry_time || "")).localeCompare((b.trade_date || "") + (b.entry_time || "")));
    const baseline = pctWin(allSorted);

    // Restored once per boot from the URL (see NavState in nav.js), and
    // before renderDecay() runs below, so the decay table's row order
    // (and therefore the uids trade-list toggles get restored against
    // further down) matches whatever sort was active last time instead
    // of resetting to the n-desc default.
    const dsortParam = NavState.get("dsort");
    if (dsortParam) {
      const [dsortKey, dsortDir] = dsortParam.split(":");
      if (dsortKey && (dsortDir === "1" || dsortDir === "-1")) decaySort = { key: dsortKey, dir: Number(dsortDir) };
    }

    content.innerHTML = `
      <div class="edge-intro">
        <div class="edge-intro-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l7 7-4 11L21 3 10 14l11 7-7-4"></path></svg></div>
        <div>
          <h2>Is your edge real, or did you get lucky?</h2>
          <p>Skeptical checks against your synced trades — built to try to break your stats, not flatter them: whether each setup's win rate is holding up or fading, whether a volume/float tag beats baseline by more than noise, how wide the uncertainty around your averages really is, how much money your exit timing is leaving on the table, how far trades ran against and for you (and where stops and targets would have landed), whether you size up right before your worst stretches, and how bad losing streaks and drawdowns could plausibly get. Each section below has a plain summary and a "How this works" toggle for the exact math.</p>
        </div>
      </div>

      <div class="stat-grid" id="edge-health" style="margin-bottom:18px;"></div>

      <div class="edge-jumpnav" id="edge-jumpnav">
        <span class="pill active" data-section="section-decay"><span class="dot"></span>Edge Decay</span>
        <span class="pill" data-section="section-scorecards"><span class="dot"></span>Setup Scorecards</span>
        <span class="pill" data-section="section-volume"><span class="dot"></span>Volume &amp; Float</span>
        <span class="pill" data-section="section-confidence"><span class="dot"></span>Confidence</span>
        <span class="pill" data-section="section-regret"><span class="dot"></span>Regret Curve</span>
        <span class="pill" data-section="section-excursion"><span class="dot"></span>MAE / MFE</span>
        <span class="pill" data-section="section-sizing"><span class="dot"></span>Position Sizing</span>
        <span class="pill" data-section="section-shuffle"><span class="dot"></span>Streaks &amp; Drawdown</span>
      </div>

      <div class="panel-box" id="section-decay" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_DECAY)}<span class="title">Setup Edge Decay</span></div>
        ${explainBlock(
          `Checks whether each setup's win rate is holding up as more trades come in — or whether it's fading, improving, or mostly a recent hot streak. Click a row to see the trades behind it.`,
          `<p>Every setup's trades are split, in date order, into an earlier half and a later half, and win rate is compared between them. Separately, the <b>last 3 trades</b> for that setup are compared against everything before them.</p>
           <p>A setup gets flagged as:</p>
           <ul>
             <li><b>too early — n&lt;10</b> — not enough trades yet to say anything reliable</li>
             <li><b>fading</b> — win rate dropped 20+ points from the first half to the second half</li>
             <li><b>improving</b> — win rate rose 20+ points from the first half to the second half</li>
             <li><b>recency-driven</b> — the last 3 trades are running 30+ points hotter than everything before them, so the win rate you're seeing may mostly be a hot streak, not the setup itself</li>
             <li><b>stable</b> — none of the above triggered</li>
           </ul>
           <p>The chart plots a rolling win rate as the selected setup's trades accumulate in order — a real edge should settle down as the sample grows, not keep swinging with every new trade.</p>`
        )}
        <div class="decay-head">
          <span class="sortable" data-sort="setup">Setup <span class="sort-arrow">▲</span></span>
          <span></span>
          <span class="sortable c-num" data-sort="overall">Win % <span class="sort-arrow">▲</span></span>
          <span class="c-half">1st → 2nd half</span>
          <span class="sortable c-num" data-sort="n">N <span class="sort-arrow">▲</span></span>
          <span></span>
        </div>
        <div id="decay-body"></div>
        <div class="filters" style="margin:18px 0 10px;"><select id="decay-setup-select"></select></div>
        <div id="decay-chart" style="height:220px;"></div>
        <p style="color:var(--text-faint); font-size:12px; margin-top:8px;">Rolling win rate as each setup's trades accumulate in order.</p>
      </div>

      <div class="panel-box" id="section-scorecards" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_DECAY)}<span class="title">Setup Scorecards</span></div>
        ${explainBlock(
          `Your three setups side by side: win rate, expectancy (average $ per trade), profit factor and average hold time &mdash; then the same numbers split by the time of day you entered. Time slots with fewer than 10 trades are greyed out: too few to trust.`
        )}
        <div id="scorecards"></div>
      </div>

      <div class="panel-box" id="section-volume" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_VOLUME)}<span class="title">Volume &amp; Float Edge Check</span></div>
        ${explainBlock(
          `Tests whether relative volume and float tags actually predict wins, beyond your overall baseline win rate of <b>${baseline}%</b> — or whether they're just noise riding along with a setup that already works.`,
          `<p>Every tag (relative volume, float, and the combination of the two) is compared against your overall baseline win rate. A tag only means something if its win rate clears that baseline by a real margin — rows with under 5 trades are marked <code>n=X</code> so a coin-flip-sized sample doesn't get mistaken for a pattern.</p>
           <p>The <b>quintile</b> chart buckets every trade with a relative-volume reading into 5 equal-sized groups, lowest to highest, and shows each bucket's win rate. If Q5 (highest) doesn't clearly beat Q1 (lowest), relative volume by itself probably isn't doing the work.</p>`
        )}
        <div style="margin-bottom:16px;"><div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">Relative Volume Tag</div><div id="rvol-breakdown"></div></div>
        <div style="margin-bottom:16px;"><div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">Float Tag</div><div id="float-breakdown"></div></div>
        <div style="margin-bottom:16px;"><div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">Float × Relative Volume</div><div id="combo-breakdown"></div></div>
        <div style="margin-bottom:16px;"><div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">Issuer Country (from your broker)</div><div id="country-breakdown"></div></div>
        <div style="margin-bottom:16px;"><div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">ADR vs Common Stock</div><div id="subtype-breakdown"></div></div>
        <div>
          <div class="group-label" style="font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:0.05em; margin:0 0 6px;">Relative Volume Quintiles (continuous)</div>
          <div id="rvol-quintiles"></div>
        </div>
      </div>

      <div class="panel-box" id="section-confidence" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_CONF)}<span class="title">Confidence Ranges</span></div>
        ${explainBlock(
          `An average P&amp;L or win rate from a limited number of trades is an estimate, not a fact. These ranges show how far each number could plausibly move if you'd simply drawn a different sample of trades from the same underlying edge.`,
          `<p><b>Expectancy</b> (average P&amp;L per trade, after commission) gets two ranges: a <b>t-test</b> range (assumes averages behave roughly normally) and a <b>bootstrap</b> range, which re-draws your trades with replacement 5,000 times and reads the 2.5th and 97.5th percentiles of the results — no normality assumption. The <b>profit factor</b> range comes from the same resamples. <b>Win rate</b> uses a Wilson score interval, which stays sensible at low win rates.</p>
           <p>The <b>p-value</b> is the t-test's two-sided probability of seeing an average this far from zero if the true average were zero. It's approximate: it treats trades as independent and P&amp;L as roughly bell-shaped, which flatters a strategy whose profit sits in a few large winners. If the bootstrap and t-test ranges disagree, trust the wider one.</p>
           <p>The Reports tab's "Probability of Random Chance" is the same test with a normal approximation; this one uses the t distribution, which is a bit more conservative when trades are few.</p>`
        )}
        <div id="confidence-body"></div>
      </div>

      <div class="panel-box" id="section-regret" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_REGRET)}<span class="title">Regret Curve — Exit Timing</span></div>
        ${explainBlock(
          `Replays the bar-by-bar price action after your entry and compares your actual exit to the best price that was available — the shape of your exit mistakes, not just a dollar total. Pulls each trade's detail file on demand (capped at the most recent ${REGRET_MAX} trades), so run it manually below.`,
          `<p>For each trade, this replays every price bar from your entry onward and finds the best bar-close price that was ever available, then compares it to where you actually exited. It's an approximation of what was achievable — it can only judge bar-close prices, not the full intrabar range.</p>
           <ul>
             <li><b>Capture %</b> — actual P&amp;L ÷ best available P&amp;L, capped between −100% and 200% so one outlier trade doesn't skew the average</li>
             <li><b>Gave Back Profit</b> — you exited after the best bar close had already passed, so some of that profit slipped away</li>
             <li><b>Left Early</b> — you exited before the best bar close arrived; you might have been able to hold longer</li>
             <li><b>Bar-Perfect Gap</b> — total dollars between your actual result and exiting every trade at its best bar close</li>
           </ul>`
        )}
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px; flex-wrap:wrap;">
          <button class="btn-confirm" id="regret-run-btn" data-bar-run>Run bar-level exit analysis</button>
          <span id="regret-status" data-bar-status style="color:var(--text-faint); font-size:12px;"></span>
        </div>
        <div id="regret-progress" data-bar-progress style="display:none; margin-bottom:14px;"><div class="progress-track"><div class="progress-fill" id="regret-progress-fill" data-bar-fill style="width:0%;"></div></div></div>
        <div id="regret-summary"></div>
        <div id="regret-histogram"></div>
        <div class="edge-section-head" style="margin-top:22px;"><span class="title">Regret Curve for One Trade</span></div>
        <div class="filters" style="margin:8px 0 10px;"><select id="regret-trade-select"><option value="">Run the analysis above first…</option></select></div>
        <div id="regret-trade-chart" style="height:240px;"></div>
        <div id="regret-trade-note" style="color:var(--text-faint); font-size:12px; margin-top:8px;"></div>
      </div>

      <div class="panel-box" id="section-excursion" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_EXCURSION)}<span class="title">MAE / MFE — Stops &amp; Targets From Your Own Trades</span></div>
        ${explainBlock(
          `For each trade: how far price went <b>against</b> you (MAE, maximum adverse excursion) and <b>for</b> you (MFE, maximum favorable excursion) between entry and exit. Winners' MAE tells you how much room a good trade actually needed, which is where a stop belongs. It uses the same on-demand bar-level run as the Regret Curve (most recent ${REGRET_MAX} trades) — run either button and both sections fill in.`,
          `<p>MAE and MFE are measured from your fill price using each bar's <b>high and low</b> from the bar containing your entry through the bar containing your exit, in price per share. Longs: MAE = entry − lowest low, MFE = highest high − entry. Shorts are mirrored. Trades whose bars are missing highs or lows are skipped rather than approximated from closes.</p>
           <p>Bars are 1-minute candles, so the first and last bar can include prices from before your fill or after your exit. On very short scalps that makes both numbers slightly generous (a bit more adverse <i>and</i> a bit more favorable than you truly saw).</p>
           <p><b>Stop sweep:</b> for each candidate stop distance, any trade whose MAE reached it is assumed to stop out at exactly that distance; every other trade keeps its real result. The table shows how many winners that would have killed, how many losers it would have cut shorter, and the change in total P&amp;L (before commission, size held constant). <b>Target sweep</b> works the same way with MFE: a trade whose MFE reached the target is assumed to exit at exactly that target, which also caps bigger winners.</p>
           <p>Read these as hypotheses, not rules: they're in-sample, assume you'd have been filled at the level, and can't tell what order the high and low happened in inside one bar — which is why stops and targets are swept separately, never together. With few winners the percentiles are noisy; the counts shown are the sample size behind each number.</p>`
        )}
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px; flex-wrap:wrap;">
          <button class="btn-confirm" id="mae-run-btn" data-bar-run>Run bar-level analysis</button>
          <span id="mae-status" data-bar-status style="color:var(--text-faint); font-size:12px;"></span>
        </div>
        <div data-bar-progress style="display:none; margin-bottom:14px;"><div class="progress-track"><div class="progress-fill" data-bar-fill style="width:0%;"></div></div></div>
        <div id="excursion-summary"><div class="empty-state small">Run the bar-level analysis to fill this in.</div></div>
        <div id="excursion-stops"></div>
        <div id="excursion-targets"></div>
      </div>

      <div class="panel-box" id="section-sizing" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_SIZING)}<span class="title">Position Sizing</span></div>
        ${explainBlock(
          `Buckets trades by position size to see if win rate holds at bigger size, and flags the classic tell of sizing up right before a losing stretch.`,
          `<p>Trades are sorted by share count and split into four equal-sized buckets, smallest to largest, so you can see whether your win rate holds up — or falls off — as you size up.</p>
           <p>Separately, a trade counts as a <b>size-up</b> if its share count is 1.5× or more above the trailing 5-trade average size at that point in your history. The two stats below compare the win rate on those size-up trades, and on the 3 trades immediately following one, against your overall baseline.</p>
           <p>The chart plots one bar per trade in chronological order — height is share size, color is win (green) or loss (red). A run of tall bars turning red is the pattern worth watching for.</p>`
        )}
        <div id="sizing-body" style="margin-bottom:18px;"></div>
        <div id="sizing-tell" style="margin-bottom:18px;"></div>
        <div id="sizing-chart" style="height:220px;"></div>
      </div>

      <div class="panel-box" id="section-shuffle" style="margin-bottom:16px;">
        <div class="edge-section-head">${sectionIcon(ICON_SHUFFLE)}<span class="title">Losing Streaks &amp; Drawdown — Trade-Shuffle Simulation</span></div>
        ${explainBlock(
          `Your total P&amp;L doesn't depend on the order of your trades, but drawdowns and losing streaks do. This reshuffles your real trades thousands of times to show how deep a drawdown and how long a losing streak your <i>same</i> edge could plausibly hand you.`,
          `<p>Each of the 5,000 runs randomly reorders all of your trades (using their actual after-commission P&amp;L, so your real sizing is included) and records the deepest peak-to-trough drop in dollars, measured from a running peak that starts at zero, and the longest run of losing trades. A "losing" trade is any trade not counted as a win, so scratches extend a streak — the same rule as Max Consecutive Losses in Reports.</p>
           <p>"Yours" is your real sequence, and the percentage beside it is how many shuffled orderings were <i>at least as bad</i>. If your real order is much worse than most shuffles, your losses were clumped more than luck alone predicts (a regime change, tilt, or a setup going stale). If it's much better, you may have been fortunate with sequencing and shouldn't expect that to repeat.</p>
           <p>The fan chart shows the 5th–95th percentile band of equity paths. Every path ends at the same total, so the spread in the middle is pure path risk.</p>
           <p><b>Limits:</b> shuffling assumes trades are independent of each other, which is false if your results cluster by market regime or by your own state. It also can't create a drawdown worse than the trades you've already taken can produce, so treat the 99th percentile as a floor on tail risk, not a ceiling.</p>`
        )}
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px; flex-wrap:wrap;">
          <button class="btn-confirm" id="shuffle-run-btn">Re-shuffle</button>
          <span id="shuffle-status" style="color:var(--text-faint); font-size:12px;"></span>
        </div>
        <div id="shuffle-summary"></div>
        <div id="shuffle-streaks"></div>
        <div class="edge-section-head" style="margin-top:22px;"><span class="title">Equity Paths (5th–95th percentile) vs. Your Actual Order</span></div>
        <div id="shuffle-fan" style="height:260px;"></div>
      </div>
    `;

    summaryState.totalTrades = allSorted.length;
    summaryState.baseline = baseline;

    safeRender(() => renderDecay(allSorted), "renderDecay");
    safeRender(() => renderScorecards(allSorted), "renderScorecards");
    safeRender(() => renderVolume(allSorted, baseline), "renderVolume");
    safeRender(() => renderSizing(allSorted), "renderSizing");
    safeRender(() => renderConfidence(allSorted), "renderConfidence");
    safeRender(() => renderShuffle(allSorted), "renderShuffle");
    safeRender(renderEdgeHealthSummary, "renderEdgeHealthSummary");
    safeRender(initJumpnav, "initJumpnav");
    safeRender(() => bindExplainToggles(content), "bindExplainToggles");
    clearStrandedLoadingStates();
    content.querySelectorAll("[data-bar-run]").forEach((b) => b.addEventListener("click", runBarAnalysis));
    const shuffleBtn = document.getElementById("shuffle-run-btn");
    if (shuffleBtn) shuffleBtn.addEventListener("click", () => {
      shuffleSeed = (shuffleSeed * 1664525 + 1013904223) >>> 0; // fresh seed each click
      safeRender(() => renderShuffle(allSorted), "renderShuffle");
      renderEdgeHealthSummary();
    });
    restoreTradeListState();
  }

  // ================= 1. SETUP EDGE DECAY =================
  function renderDecay(sorted) {
    const groups = groupBy(sorted, (r) => r.setup_type || "unlabeled");
    decayGroups = groups;

    decayRows = Object.entries(groups).map(([setup, trades]) => {
      const n = trades.length;
      const overall = pctWin(trades);
      const half = Math.floor(n / 2);
      const firstRate = n >= 4 ? pctWin(trades.slice(0, half)) : null;
      const secondRate = n >= 4 ? pctWin(trades.slice(half)) : null;
      const last3 = trades.slice(-3);
      const priorRest = trades.slice(0, Math.max(0, n - 3));
      const last3Rate = last3.length === 3 ? pctWin(last3) : null;
      const restRate = priorRest.length ? pctWin(priorRest) : null;

      let flag = "stable", flagCls = "";
      if (n < 10) { flag = "too early — n<10"; flagCls = ""; }
      else if (last3Rate !== null && restRate !== null && (last3Rate - restRate) >= 30) { flag = "recency-driven"; flagCls = "loss"; }
      else if (firstRate !== null && secondRate !== null && (secondRate - firstRate) <= -20) { flag = "fading"; flagCls = "loss"; }
      else if (firstRate !== null && secondRate !== null && (secondRate - firstRate) >= 20) { flag = "improving"; flagCls = "win"; }

      return { setup, trades, n, overall, firstRate, secondRate, flag, flagCls };
    });

    summaryState.totalSetups = decayRows.length;
    summaryState.flaggedSetups = decayRows.filter((r) => r.flagCls === "loss").length;

    document.querySelectorAll(".decay-head .sortable").forEach((headEl) => {
      headEl.addEventListener("click", () => {
        const key = headEl.dataset.sort;
        if (decaySort.key === key) decaySort.dir *= -1;
        else decaySort = { key, dir: key === "setup" ? 1 : -1 };
        renderDecayRows();
        syncUrlState();
      });
    });
    renderDecayRows();

    const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
    const sel = document.getElementById("decay-setup-select");
    sel.innerHTML = entries.map(([s]) => `<option value="${escapeHtml(s)}">${escapeHtml(s.replace(/_/g, " "))} (${groups[s].length}x)</option>`).join("");
    // Restored from the URL if the person had a different setup's trend
    // chart open last time; falls back to the biggest-sample setup
    // (entries[0], same as before) otherwise.
    const dselParam = NavState.get("dsel");
    const initialSetup = (dselParam && groups[dselParam]) ? dselParam : (entries.length ? entries[0][0] : null);
    if (initialSetup) sel.value = initialSetup;
    sel.onchange = () => { renderDecayChart(groups[sel.value] || []); syncUrlState(); };
    if (initialSetup) renderDecayChart(groups[initialSetup]);
  }

  // ================= SETUP SCORECARDS =================
  function renderScorecards(rows) {
    const el = document.getElementById("scorecards");
    const SC = window.SetupScorecards;
    if (!el || !SC) return;
    const MINE = ["red_to_green", "green_over_green_wick", "ema9_dip_buy"];
    const all = SC.build(rows);
    if (!all.length) { el.innerHTML = `<div class="empty-state small">No setup_type data yet.</div>`; return; }
    const ordered = MINE.map((k) => all.find((r) => r.setup === k)).filter(Boolean).concat(all.filter((r) => MINE.indexOf(r.setup) === -1));
    const money = (v) => (v === null || v === undefined ? "\u2014" : fmtMoney(v));
    const cls = (v) => (v === null || v === undefined ? "" : v >= 0 ? "win" : "loss");
    const pct = (v) => (v === null ? "\u2014" : Math.round(v * 1000) / 10 + "%");
    const pf = (v) => (v === null ? "\u2014" : v === Infinity ? "\u221e" : v.toFixed(2));
    const hold = (v) => (v === null ? "\u2014" : v < 1 ? Math.round(v * 60) + "s" : v.toFixed(1) + "m");
    el.innerHTML = ordered.map((r) => `
      <div class="sc-card${MINE.indexOf(r.setup) === -1 ? " sc-other" : ""}">
        <div class="sc-head"><span class="sc-name">${escapeHtml(window.setupLabel ? window.setupLabel(r.setup) : r.setup.replace(/_/g, " "))}</span><span class="sc-n">${r.n} trades${r.n < 10 ? " \u00b7 too early" : ""}</span></div>
        <div class="sc-kpis">
          <div><i>Win rate</i><b>${pct(r.winRate)}</b></div>
          <div><i>Expectancy</i><b class="${cls(r.expectancy)}">${money(r.expectancy)}</b></div>
          <div><i>Profit factor</i><b>${pf(r.profitFactor)}</b></div>
          <div><i>Avg hold</i><b>${hold(r.avgHoldMin)}</b></div>
          <div><i>Total</i><b class="${cls(r.total)}">${money(r.total)}</b></div>
        </div>
        <div class="sc-time">
          ${r.byTime.map((b) => `<div class="sc-slot${b.n === 0 ? " empty" : b.n < 10 ? " thin" : ""}"><i>${b.label}</i><b class="${b.n ? cls(b.expectancy) : ""}">${b.n ? money(b.expectancy) : "\u2014"}</b><span>${b.n ? pct(b.winRate) + " \u00b7 " + b.n + "x" : "no trades"}</span></div>`).join("")}
        </div>
      </div>`).join("");
  }

  function renderDecayRows() {
    const el = document.getElementById("decay-body");
    const { key, dir } = decaySort;
    const rows = decayRows.slice().sort((a, b) => {
      if (key === "setup") return dir * String(a.setup).localeCompare(String(b.setup));
      return dir * (a[key] - b[key]);
    });

    el.innerHTML = rows.map((r) => {
      const uid = `edge-trades-${rowSeq++}`;
      return `
        <div class="edge-row decay-row" data-trade-toggle="${uid}" data-clickable>
          <div class="c-label">${escapeHtml(r.setup.replace(/_/g, " "))}</div>
          <div class="c-bar bar-track"><div class="bar-fill" data-w="${r.overall}" style="width:0%; background:${r.overall >= 50 ? "var(--green)" : "var(--red)"};"></div></div>
          <div class="c-num">${r.overall}%</div>
          <div class="c-num c-half" style="color:var(--text-faint);">${r.firstRate === null ? "—" : r.firstRate + "%"} → ${r.secondRate === null ? "—" : r.secondRate + "%"}</div>
          <div class="c-num" style="color:var(--text-faint);">${r.n}x</div>
          <div class="c-flag"><span class="pill ${r.flagCls}">${r.flag}</span></div>
        </div>
        ${tradeListHtml(r.trades, uid)}
      `;
    }).join("") || `<div class="empty-state small">No setup_type data yet.</div>`;
    bindTradeToggles(el);
    animateBarFills(el);

    document.querySelectorAll(".decay-head .sortable").forEach((headEl) => {
      const active = headEl.dataset.sort === key;
      headEl.classList.toggle("sort-active", active);
      const arrow = headEl.querySelector(".sort-arrow");
      if (arrow) arrow.textContent = active ? (dir === 1 ? "▲" : "▼") : "▲";
    });
  }

  function renderDecayChart(trades) {
    const el = document.getElementById("decay-chart");
    el.innerHTML = "";
    if (trades.length < 2) { el.innerHTML = `<div class="empty-state small">Not enough trades yet to plot a trend.</div>`; return; }
    const chart = makeChart(el, 220, { timeScale: { borderColor: "#262a34", tickMarkFormatter: (t) => "#" + t }, localization: { timeFormatter: (t) => "Trade #" + t } });
    const series = chart.addLineSeries({ color: "#8b7cf6", lineWidth: 2 });
    let wins = 0;
    const data = trades.map((t, i) => {
      if (t.win) wins++;
      return { time: i + 1, value: Math.round((wins / (i + 1)) * 1000) / 10 };
    });
    series.setData(data);
    chart.timeScale().fitContent();
  }

  // ================= 2. VOLUME / FLOAT EDGE CHECK =================
  function renderVolume(sorted, baseline) {
    renderTagBreakdown("rvol-breakdown", groupBy(sorted.filter((r) => r.rvol_tag), (r) => r.rvol_tag), baseline);
    renderTagBreakdown("float-breakdown", groupBy(sorted.filter((r) => r.float_tag), (r) => r.float_tag), baseline);
    renderTagBreakdown("combo-breakdown", groupBy(sorted.filter((r) => r.rvol_tag && r.float_tag), (r) => `${r.float_tag} float · ${r.rvol_tag} rvol`), baseline);
    const countryName = (c) => { try { return new Intl.DisplayNames(undefined, { type: "region" }).of(String(c).toUpperCase()) || c; } catch (e) { return c; } };
    renderTagBreakdown("country-breakdown", groupBy(sorted.filter((r) => r.issuer_country), (r) => countryName(r.issuer_country)), baseline);
    renderTagBreakdown("subtype-breakdown", groupBy(sorted.filter((r) => r.sub_category), (r) => (r.sub_category === "COMMON" ? "Common stock" : r.sub_category)), baseline);
    renderRvolQuintiles(sorted.filter((r) => typeof r.relative_volume === "number" && isFinite(r.relative_volume)));
  }

  function renderTagBreakdown(elId, groups, baseline) {
    const el = document.getElementById(elId);
    const entries = Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
    if (!entries.length) { el.innerHTML = `<div class="empty-state small">No tagged trades yet.</div>`; return; }
    el.innerHTML = entries.map(([tag, trades]) => {
      const n = trades.length;
      const rate = pctWin(trades);
      const pnl = trades.reduce((s, r) => s + (r.pnl_after_comm || 0), 0);
      const delta = Math.round((rate - baseline) * 10) / 10;
      const uid = `edge-trades-${rowSeq++}`;
      return `<div class="edge-row tag-row" data-trade-toggle="${uid}" data-clickable>
        <div class="c-label" style="text-transform:none;">${escapeHtml(tag.replace(/_/g, " "))}${n < 5 ? ` <span class="pill" title="Fewer than 5 trades — treat as a rough signal, not a verdict.">n=${n}</span>` : ""}</div>
        <div class="c-bar bar-track"><div class="bar-fill" data-w="${rate}" style="width:0%; background:${rate >= 50 ? "var(--green)" : "var(--red)"};"></div></div>
        <div class="c-num">${rate}%</div>
        <div class="c-num c-delta" style="color:${delta >= 0 ? "var(--green)" : "var(--red)"};">${delta >= 0 ? "+" : ""}${delta}pt</div>
        <div class="c-num c-pnl" style="color:${pnl >= 0 ? "var(--green)" : "var(--red)"};">${fmtMoney(pnl)}</div>
        <div class="c-num" style="color:var(--text-faint);">${n}x</div>
      </div>
      ${tradeListHtml(trades, uid)}`;
    }).join("");
    bindTradeToggles(el);
    animateBarFills(el);
  }

  function renderRvolQuintiles(rows) {
    const el = document.getElementById("rvol-quintiles");
    if (rows.length < 10) { el.innerHTML = `<div class="empty-state small">Need at least 10 trades with relative_volume to bucket into quintiles (have ${rows.length}).</div>`; return; }
    const byRvol = rows.slice().sort((a, b) => a.relative_volume - b.relative_volume);
    const size = Math.ceil(byRvol.length / 5);
    const labels = ["Q1 — lowest rvol", "Q2", "Q3", "Q4", "Q5 — highest rvol"];
    let html = "";
    for (let i = 0; i < 5; i++) {
      const bucket = byRvol.slice(i * size, (i + 1) * size);
      if (!bucket.length) continue;
      const rate = pctWin(bucket);
      const lo = bucket[0].relative_volume.toFixed(2), hi = bucket[bucket.length - 1].relative_volume.toFixed(2);
      html += `<div class="edge-row quint-row">
        <div class="c-label">${labels[i]}</div>
        <div class="c-bar bar-track"><div class="bar-fill" data-w="${rate}" style="width:0%; background:${rate >= 50 ? "var(--green)" : "var(--red)"};"></div></div>
        <div class="c-num">${rate}%</div>
        <div class="c-num c-range" style="color:var(--text-faint);">${lo}x–${hi}x</div>
        <div class="c-num" style="color:var(--text-faint);">${bucket.length}x</div>
      </div>`;
    }
    el.innerHTML = html;
    animateBarFills(el);
  }

  // ================= 3. REGRET CURVE (bar-level) =================
  function computeRegretForTrade(row, detail) {
    const bars = detail && Array.isArray(detail.bars) ? detail.bars : null;
    if (!bars || !bars.length || typeof row.entry_price !== "number" || typeof row.exit_price !== "number") return null;
    const entryKey = `${row.trade_date}T${row.entry_time}`;
    const exitKey = `${row.trade_date}T${row.exit_time}`;
    let entryIdx = bars.findIndex((b) => b.t >= entryKey);
    if (entryIdx === -1) entryIdx = 0;
    let exitIdx = bars.findIndex((b) => b.t >= exitKey);
    if (exitIdx === -1) exitIdx = bars.length - 1;
    const sign = row.side === "short" ? -1 : 1;
    const path = [];
    let bestIdx = entryIdx, bestPnl = -Infinity;
    for (let i = entryIdx; i < bars.length; i++) {
      if (typeof bars[i].c !== "number") continue;
      const pnl = (bars[i].c - row.entry_price) * sign;
      path.push({ i, t: bars[i].t, pnl });
      if (pnl > bestPnl) { bestPnl = pnl; bestIdx = i; }
    }
    if (!path.length || bestPnl === -Infinity) return null;
    const actualPnl = (row.exit_price - row.entry_price) * sign;
    const gaveBackBars = exitIdx - bestIdx; // >0 held past the best bar close, <0 exited before reaching it
    const capture = bestPnl > 0 ? actualPnl / bestPnl : null;
    return { path, entryIdx, exitIdx, bestIdx, bestPnl, actualPnl, gaveBackBars, capture };
  }

  // One shared bar-level run feeds BOTH the Regret Curve and MAE/MFE
  // sections (same detail fetches, two computations per trade), so either
  // section's button triggers it and both sections' controls stay in sync.
  async function runBarAnalysis() {
    const btns = Array.from(content.querySelectorAll("[data-bar-run]"));
    const statuses = Array.from(content.querySelectorAll("[data-bar-status]"));
    const progWraps = Array.from(content.querySelectorAll("[data-bar-progress]"));
    const progFills = Array.from(content.querySelectorAll("[data-bar-fill]"));
    if (btns.some((b) => b.disabled)) return; // already running
    btns.forEach((b) => { b.disabled = true; });
    progWraps.forEach((w) => { w.style.display = "block"; });
    progFills.forEach((f) => { f.style.width = "0%"; });

    const candidates = allSorted.slice()
      .sort((a, b) => ((b.trade_date || "") + (b.entry_time || "")).localeCompare((a.trade_date || "") + (a.entry_time || "")))
      .slice(0, REGRET_MAX);

    regretResults = [];
    excursionResults = [];
    let done = 0;
    let idx = 0;
    const CONCURRENCY = 6;
    async function worker() {
      while (idx < candidates.length) {
        const row = candidates[idx++];
        try {
          const detail = await window.fetchTradeDetail(row.id);
          if (detail) {
            const computed = computeRegretForTrade(row, detail);
            if (computed) regretResults.push({ row, computed });
            const exc = computeExcursionForTrade(row, detail);
            if (exc) excursionResults.push({ row, exc });
          }
        } catch (e) { /* skip this trade, keep going */ }
        done++;
        progFills.forEach((f) => { f.style.width = Math.round((done / candidates.length) * 100) + "%"; });
        statuses.forEach((st) => { st.textContent = `Loaded ${done} / ${candidates.length}`; });
      }
    }
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, candidates.length) }, worker));

    progWraps.forEach((w) => { w.style.display = "none"; });
    btns.forEach((b) => { b.disabled = false; });
    const regretBtn = document.getElementById("regret-run-btn");
    const maeBtn = document.getElementById("mae-run-btn");
    if (regretBtn) regretBtn.textContent = "Re-run bar-level exit analysis";
    if (maeBtn) maeBtn.textContent = "Re-run bar-level analysis";
    const regretStatus = document.getElementById("regret-status");
    const maeStatus = document.getElementById("mae-status");
    if (regretStatus) regretStatus.textContent = `${regretResults.length} of ${candidates.length} checked trades had usable bar data.`;
    if (maeStatus) maeStatus.textContent = `${excursionResults.length} of ${candidates.length} checked trades had bars with highs and lows.`;

    safeRender(renderRegretSummary, "renderRegretSummary");
    safeRender(renderRegretTradeSelect, "renderRegretTradeSelect");
    safeRender(renderExcursion, "renderExcursion");
  }

  function renderRegretSummary() {
    const summaryEl = document.getElementById("regret-summary");
    const histEl = document.getElementById("regret-histogram");
    if (!regretResults.length) {
      summaryEl.innerHTML = `<div class="empty-state small">No usable bar data in the trades checked.</div>`;
      histEl.innerHTML = "";
      summaryState.regretCapture = null;
      renderEdgeHealthSummary();
      return;
    }
    const withCapture = regretResults.filter((r) => r.computed.capture !== null);
    const avgCapture = withCapture.length ? avg(withCapture.map((r) => Math.max(-1, Math.min(2, r.computed.capture)))) : null;
    const gaveBack = withCapture.filter((r) => r.computed.gaveBackBars > 0).length;
    const exitedEarly = withCapture.filter((r) => r.computed.gaveBackBars < 0).length;
    const moneyLeft = withCapture.reduce((s, r) => s + Math.max(0, r.computed.bestPnl - r.computed.actualPnl) * (r.row.shares || 0), 0);

    summaryState.regretCapture = avgCapture;
    renderEdgeHealthSummary();

    summaryEl.innerHTML = `
      <div class="stat-grid" style="margin-bottom:16px;">
        <div class="stat">
          <div class="label-row"><span class="label">Avg. Capture of Best Bar</span></div>
          <div class="value ${avgCapture !== null && avgCapture >= 0.6 ? "up" : "down"}">${avgCapture === null ? "—" : Math.round(avgCapture * 100) + "%"}</div>
          <div class="sub-value">${withCapture.length} trades that were ever favorable</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Gave Back Profit</span></div>
          <div class="value down">${withCapture.length ? Math.round((gaveBack / withCapture.length) * 100) : 0}%</div>
          <div class="sub-value">exited after the best bar-close had passed</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Left Early</span></div>
          <div class="value">${withCapture.length ? Math.round((exitedEarly / withCapture.length) * 100) : 0}%</div>
          <div class="sub-value">exited before the best bar-close arrived</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Bar-Perfect Gap</span></div>
          <div class="value down">${fmtMoney(-moneyLeft)}</div>
          <div class="sub-value">vs. exiting at each trade's best bar close</div>
        </div>
      </div>
    `;

    const buckets = [
      { label: "Gave it all back (< 0%)", test: (c) => c < 0 },
      { label: "0–50% captured", test: (c) => c >= 0 && c < 0.5 },
      { label: "50–90% captured", test: (c) => c >= 0.5 && c < 0.9 },
      { label: "90–110% (near bar-perfect)", test: (c) => c >= 0.9 && c < 1.1 },
      { label: "> 110% (fill beat every bar close)", test: (c) => c >= 1.1 },
    ];
    const total = withCapture.length;
    histEl.innerHTML = total ? `<div class="edge-section-head" style="margin-top:6px;"><span class="title">Exit Efficiency Distribution</span></div>` +
      buckets.map((b) => {
        const rows = withCapture.filter((r) => b.test(r.computed.capture));
        const pct = total ? Math.round((rows.length / total) * 1000) / 10 : 0;
        return `<div class="edge-row" style="grid-template-columns: 240px minmax(60px,1fr) 50px 40px;">
          <div class="c-label" style="text-transform:none;">${b.label}</div>
          <div class="c-bar bar-track"><div class="bar-fill" data-w="${pct}" style="width:0%; background:var(--blue);"></div></div>
          <div class="c-num">${pct}%</div>
          <div class="c-num" style="color:var(--text-faint);">${rows.length}x</div>
        </div>`;
      }).join("") : "";
    animateBarFills(histEl);
  }

  function renderRegretTradeSelect() {
    const sel = document.getElementById("regret-trade-select");
    const sortedResults = regretResults.slice().sort((a, b) => (b.row.trade_date || "").localeCompare(a.row.trade_date || ""));
    if (!sortedResults.length) {
      sel.innerHTML = `<option value="">No trades available</option>`;
      document.getElementById("regret-trade-chart").innerHTML = "";
      document.getElementById("regret-trade-note").textContent = "";
      return;
    }
    sel.innerHTML = sortedResults.map((r) => `<option value="${escapeHtml(r.row.id)}">${escapeHtml(r.row.symbol)} — ${escapeHtml(r.row.trade_date)} (${r.row.win ? "WIN" : "LOSS"})</option>`).join("");
    sel.onchange = () => {
      const found = regretResults.find((r) => r.row.id === sel.value);
      if (found) renderRegretTradeChart(found);
    };
    sel.value = sortedResults[0].row.id;
    renderRegretTradeChart(sortedResults[0]);
  }

  function renderRegretTradeChart(entry) {
    const el = document.getElementById("regret-trade-chart");
    el.innerHTML = "";
    const { row, computed } = entry;
    const chart = makeChart(el, 240);
    const series = chart.addLineSeries({ color: "#5b93f0", lineWidth: 2 });
    const shares = row.shares || 1;
    const toTime = (t) => Math.floor(new Date(String(t).replace(" ", "T") + "Z").getTime() / 1000);
    const data = computed.path.map((p) => ({ time: toTime(p.t), value: Math.round(p.pnl * shares * 100) / 100 }));
    series.setData(data);

    const markers = [];
    const bestPoint = computed.path.find((p) => p.i === computed.bestIdx);
    if (bestPoint) markers.push({ time: toTime(bestPoint.t), position: "aboveBar", color: "#e8a94c", shape: "circle", text: "Best bar" });
    const exitPoint = computed.path.find((p) => p.i >= computed.exitIdx) || computed.path[computed.path.length - 1];
    if (exitPoint) markers.push({ time: toTime(exitPoint.t), position: "belowBar", color: row.win ? "#2fd08a" : "#f2555a", shape: "arrowDown", text: "Actual exit" });
    markers.sort((a, b) => a.time - b.time);
    series.setMarkers(markers);
    chart.timeScale().fitContent();

    const capPct = computed.capture === null ? "never favorable on a bar close" : `${Math.round(computed.capture * 100)}% of the best bar-close captured`;
    document.getElementById("regret-trade-note").innerHTML =
      `Best possible (bar-close) P&amp;L: <b>${fmtMoney(computed.bestPnl * shares)}</b> · Actual: <b>${fmtMoney(computed.actualPnl * shares)}</b> · ${capPct}. ` +
      `<a href="trade.html?id=${encodeURIComponent(row.id)}" target="_blank">Open trade →</a>`;
  }

  // ================= 4. POSITION SIZING =================
  function renderSizing(sorted) {
    const bySize = sorted.filter((r) => typeof r.shares === "number" && r.shares > 0);
    const bodyEl = document.getElementById("sizing-body");
    const tellEl = document.getElementById("sizing-tell");
    if (bySize.length < 8) {
      bodyEl.innerHTML = `<div class="empty-state small">Need more trades with share counts to bucket by size (have ${bySize.length}).</div>`;
      tellEl.innerHTML = "";
      document.getElementById("sizing-chart").innerHTML = "";
      summaryState.sizingTellActive = null;
      renderEdgeHealthSummary();
      return;
    }

    const byShares = bySize.slice().sort((a, b) => a.shares - b.shares);
    const q = Math.ceil(byShares.length / 4);
    const labels = ["Smallest 25%", "2nd quartile", "3rd quartile", "Largest 25%"];
    let html = "";
    for (let i = 0; i < 4; i++) {
      const bucket = byShares.slice(i * q, (i + 1) * q);
      if (!bucket.length) continue;
      const rate = pctWin(bucket);
      const pnl = bucket.reduce((s, r) => s + (r.pnl_after_comm || 0), 0);
      const lo = Math.min(...bucket.map((r) => r.shares)), hi = Math.max(...bucket.map((r) => r.shares));
      html += `<div class="edge-row size-row">
        <div class="c-label">${labels[i]}</div>
        <div class="c-bar bar-track"><div class="bar-fill" data-w="${rate}" style="width:0%; background:${rate >= 50 ? "var(--green)" : "var(--red)"};"></div></div>
        <div class="c-num">${rate}%</div>
        <div class="c-num c-range" style="color:var(--text-faint);">${lo}–${hi} sh</div>
        <div class="c-num c-pnl" style="color:${pnl >= 0 ? "var(--green)" : "var(--red)"};">${fmtMoney(pnl)}</div>
        <div class="c-num" style="color:var(--text-faint);">${bucket.length}x</div>
      </div>`;
    }
    bodyEl.innerHTML = html;
    animateBarFills(bodyEl);

    // "size-up tell": trades sized 1.5x+ the trailing 5-trade average share count,
    // and the win rate of whatever immediately follows one.
    const chrono = bySize; // already in chronological order (sorted upstream)
    const baseline = pctWin(chrono);
    const sizeUpTrades = [];
    const followSet = new Set();
    for (let i = 5; i < chrono.length; i++) {
      const trailing = avg(chrono.slice(i - 5, i).map((r) => r.shares));
      if (trailing > 0 && chrono[i].shares > trailing * 1.5) {
        sizeUpTrades.push(chrono[i]);
        chrono.slice(i + 1, i + 4).forEach((r) => followSet.add(r));
      }
    }
    const followTrades = Array.from(followSet);
    const sizeUpRate = sizeUpTrades.length ? pctWin(sizeUpTrades) : null;
    const followRate = followTrades.length ? pctWin(followTrades) : null;

    // Same "meaningfully worse, not just noise" margin used for the decay
    // flags elsewhere on this page -- inconclusive (null) until there's
    // at least a handful of size-up follow-through trades to judge from.
    summaryState.sizingTellActive = followTrades.length < 3 ? null : (followRate <= baseline - 15);
    renderEdgeHealthSummary();

    tellEl.innerHTML = `
      <div class="stat-grid" style="margin-bottom:0;">
        <div class="stat">
          <div class="label-row"><span class="label">Win Rate — Size-Up Trades</span></div>
          <div class="value ${sizeUpRate === null ? "" : (sizeUpRate >= baseline ? "up" : "down")}">${sizeUpRate === null ? "—" : sizeUpRate + "%"}</div>
          <div class="sub-value">${sizeUpTrades.length} trades sized 1.5×+ the trailing 5-trade avg, vs ${baseline}% baseline</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Win Rate — Next 3 After a Size-Up</span></div>
          <div class="value ${followRate === null ? "" : (followRate >= baseline ? "up" : "down")}">${followRate === null ? "—" : followRate + "%"}</div>
          <div class="sub-value">${followTrades.length} trades immediately following a size-up</div>
        </div>
      </div>
    `;

    renderSizingChart(chrono);
  }

  function renderSizingChart(chrono) {
    const el = document.getElementById("sizing-chart");
    el.innerHTML = "";
    const chart = makeChart(el, 220, { timeScale: { borderColor: "#262a34", tickMarkFormatter: (t) => "#" + t }, localization: { timeFormatter: (t) => "Trade #" + t } });
    const series = chart.addHistogramSeries({ priceFormat: { type: "volume" } });
    series.setData(chrono.map((r, i) => ({ time: i + 1, value: r.shares, color: r.win ? "rgba(47,208,138,0.75)" : "rgba(242,85,90,0.75)" })));
    chart.timeScale().fitContent();
  }

  // ================= 5. CONFIDENCE RANGES =================
  // Small formatting helpers for the three sections below.
  function fmtPx(v) { return Number.isFinite(v) ? (v < 0 ? "-$" : "$") + Math.abs(v).toFixed(Math.abs(v) < 1 ? 3 : 2) : "—"; }
  function fmtShare(x) { return (x * 100).toFixed(x < 0.1 && x > 0 ? 1 : 0) + "%"; }
  function fmtPf(v) { return v === Infinity ? "∞" : (Number.isFinite(v) ? v.toFixed(2) : "—"); }
  function statsOrMessage(el) {
    if (window.EdgeStats) return window.EdgeStats;
    if (el) el.innerHTML = `<div class="empty-state small">Couldn't load js/edge/edge-stats.js — refresh the page.</div>`;
    return null;
  }

  function renderConfidence(rows) {
    const el = document.getElementById("confidence-body");
    if (!el) return;
    const ES = statsOrMessage(el);
    if (!ES) return;
    const pnls = rows.map((r) => r.pnl_after_comm).filter((v) => typeof v === "number" && isFinite(v));
    const winCount = rows.filter((r) => r.win).length;
    const tt = ES.tTest(pnls);
    const bs = ES.bootstrapTradeStats(pnls, { iterations: 5000, seed: 20260921 });
    const wr = ES.wilson(winCount, rows.length);
    if (!tt || !bs || !wr) {
      summaryState.pValue = null;
      el.innerHTML = `<div class="empty-state small">Needs at least 5 trades with P&amp;L that isn't all identical.</div>`;
      return;
    }
    summaryState.pValue = tt.p;

    const e = bs.expectancy, pf = bs.profitFactor;
    const pStr = tt.p < 0.001 ? "&lt; 0.001" : tt.p.toFixed(3);
    // Trust the wider of the two ranges (the explainer says so): that's the
    // conservative read of "could the true average be zero?".
    const lo = Math.min(tt.ci[0], e.lo), hi = Math.max(tt.ci[1], e.hi);
    let verdict;
    if (lo > 0) {
      verdict = `Both ranges sit above zero: on this sample, an average loss per trade isn't a plausible explanation. That's evidence the edge is real <i>so far</i>, not a promise it persists — check Edge Decay above.`;
    } else if (hi < 0) {
      verdict = `Both ranges sit below zero: on this sample, the average trade is losing money, and luck alone is an unlikely explanation.`;
    } else {
      verdict = `The plausible average runs from <b>${fmtMoney(lo)}</b> to <b>${fmtMoney(hi)}</b> per trade, so this record can't yet separate your edge from zero. As a rule of thumb, about 4× as many trades would halve that width.`;
    }
    if (tt.n < 30) verdict += ` With only ${tt.n} trades, every range here rests on very little data.`;
    if (pf.infiniteShare > 0.01 && Number.isFinite(pf.point)) verdict += ` About ${fmtShare(pf.infiniteShare)} of resamples drew no losing trade at all, so the top of the profit-factor range is unbounded.`;

    el.innerHTML = `
      <div class="stat-grid" style="margin-bottom:14px;">
        <div class="stat">
          <div class="label-row"><span class="label">Expectancy / Trade</span></div>
          <div class="value ${e.point >= 0 ? "up" : "down"}">${fmtMoney(e.point)}</div>
          <div class="sub-value">bootstrap 95%: ${fmtMoney(e.lo)} to ${fmtMoney(e.hi)}</div>
          <div class="sub-value">t-test 95%: ${fmtMoney(tt.ci[0])} to ${fmtMoney(tt.ci[1])}</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Profit Factor</span></div>
          <div class="value ${pf.point >= 1 ? "up" : "down"}">${fmtPf(pf.point)}</div>
          <div class="sub-value">bootstrap 95%: ${fmtPf(pf.lo)} to ${fmtPf(pf.hi)}</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">Win Rate</span></div>
          <div class="value">${(wr.p * 100).toFixed(1)}%</div>
          <div class="sub-value">Wilson 95%: ${(wr.lo * 100).toFixed(1)}% to ${(wr.hi * 100).toFixed(1)}%</div>
        </div>
        <div class="stat">
          <div class="label-row"><span class="label">P-value (avg. P&amp;L ≠ 0)</span></div>
          <div class="value ${tt.p < 0.05 ? "up" : ""}">${pStr}</div>
          <div class="sub-value">t = ${tt.t.toFixed(2)} · n = ${tt.n} · df = ${tt.df}</div>
        </div>
      </div>
      <p class="edge-explain-blurb" style="margin:0;">${verdict}</p>`;
  }

  // ================= 6. MAE / MFE =================
  // Runs off the same detail fetches as the Regret Curve (see
  // runBarAnalysis). Returns null when this trade's bars can't support it.
  function computeExcursionForTrade(row, detail) {
    if (!window.EdgeStats) return null;
    const bars = detail && Array.isArray(detail.bars) ? detail.bars : null;
    if (!bars || !bars.length || !row.trade_date || !row.entry_time || !row.exit_time) return null;
    if (typeof row.entry_price !== "number" || typeof row.exit_price !== "number") return null;
    const entryTs = toUnix(`${row.trade_date} ${row.entry_time}`);
    const exitTs = toUnix(`${row.trade_date} ${row.exit_time}`);
    const exc = window.EdgeStats.computeExcursion(bars, entryTs, exitTs, row.entry_price, row.side, toUnix);
    if (!exc) return null;
    const sign = row.side === "short" ? -1 : 1;
    return Object.assign(exc, { pnl: (row.exit_price - row.entry_price) * sign });
  }

  function sweepTableHtml(headers, cols, rowsHtml) {
    const tpl = `grid-template-columns:${cols};`;
    return `<div style="overflow-x:auto;"><div style="min-width:560px;">
      <div class="decay-head" style="${tpl}">${headers.map((h, i) => `<span class="${i ? "c-num" : ""}" style="${i ? "text-align:right;" : ""}">${h}</span>`).join("")}</div>
      ${rowsHtml}
    </div></div>`;
  }
  function deltaCell(v) {
    return `<div class="c-num" style="color:${v > 0.005 ? "var(--green)" : (v < -0.005 ? "var(--red)" : "var(--text-faint)")};">${fmtMoney(v)}</div>`;
  }

  function renderExcursion() {
    const sumEl = document.getElementById("excursion-summary");
    const stopEl = document.getElementById("excursion-stops");
    const tgtEl = document.getElementById("excursion-targets");
    if (!sumEl) return;
    const ES = statsOrMessage(sumEl);
    if (!ES) return;
    const rows = excursionResults.map(({ row, exc }) => ({
      mae: exc.mae, mfe: exc.mfe, pnl: exc.pnl, win: !!row.win,
      shares: typeof row.shares === "number" && row.shares > 0 ? row.shares : 0,
    }));
    if (!rows.length) {
      sumEl.innerHTML = `<div class="empty-state small">None of the checked trades had bars with both highs and lows around the trade.</div>`;
      stopEl.innerHTML = ""; tgtEl.innerHTML = "";
      return;
    }
    const winners = rows.filter((r) => r.win);
    const losers = rows.filter((r) => !r.win);
    const asc = (arr, k) => arr.map((r) => r[k]).sort((a, b) => a - b);
    const med = (arr, k) => (arr.length ? ES.percentile(asc(arr, k), 0.5) : NaN);
    const p = (arr, k, q) => (arr.length ? ES.percentile(asc(arr, k), q) : NaN);
    const avgPnl = (arr) => (arr.length ? ES.mean(arr.map((r) => r.pnl)) : NaN);
    const sized = rows.filter((r) => r.shares > 0);
    const avgMaeUsd = sized.length ? ES.mean(sized.map((r) => r.mae * r.shares)) : NaN;
    const avgMfeUsd = sized.length ? ES.mean(sized.map((r) => r.mfe * r.shares)) : NaN;

    const card = (label, value, sub, cls) => `<div class="stat"><div class="label-row"><span class="label">${label}</span></div><div class="value ${cls || ""}">${value}</div><div class="sub-value">${sub}</div></div>`;
    sumEl.innerHTML = `
      <div class="stat-grid" style="margin-bottom:16px;">
        ${card("Winners' MAE (median)", fmtPx(med(winners, "mae")), `90th pct ${fmtPx(p(winners, "mae", 0.9))} · n = ${winners.length}`)}
        ${card("Winners' MFE (median)", fmtPx(med(winners, "mfe")), `avg. realized ${fmtPx(avgPnl(winners))} / share`)}
        ${card("Losers' MAE (median)", fmtPx(med(losers, "mae")), `avg. realized ${fmtPx(avgPnl(losers))} / share · n = ${losers.length}`)}
        ${card("Losers' MFE (median)", fmtPx(med(losers, "mfe")), "how far losers went your way first")}
        ${card("Avg. Position MAE", sized.length ? "$" + avgMaeUsd.toFixed(2) : "—", "per trade, all checked trades")}
        ${card("Avg. Position MFE", sized.length ? "$" + avgMfeUsd.toFixed(2) : "—", "per trade, all checked trades")}
      </div>
      ${winners.length < 15 ? `<p class="edge-explain-blurb" style="margin:0 0 6px;">Only ${winners.length} winning trade${winners.length === 1 ? "" : "s"} in the checked sample — winner percentiles are rough at this size.</p>` : ""}
      <p class="edge-explain-blurb" style="margin:0 0 4px;">All figures are price per share unless marked $; the two "Avg. Position" cards multiply by share count.</p>`;

    const sweepRows = rows.filter((r) => r.shares > 0);
    if (!sweepRows.length) { stopEl.innerHTML = ""; tgtEl.innerHTML = ""; return; }

    // ---- stop sweep: candidate stops just beyond winners' MAE percentiles ----
    const stopQs = [[0.5, "50th"], [0.75, "75th"], [0.9, "90th"], [0.95, "95th"]];
    const stopLevels = [], stopLabels = {};
    if (winners.length >= 2) {
      stopQs.forEach(([q, lab]) => {
        const lvl = Math.ceil(p(winners, "mae", q) * 100 - 1e-9) / 100; // round UP to the cent
        if (lvl > 0 && !(lvl in stopLabels)) { stopLevels.push(lvl); stopLabels[lvl] = `Beyond winners' ${lab} pct MAE`; }
      });
    }
    if (stopLevels.length) {
      const res = ES.stopSweep(sweepRows, stopLevels);
      const cols = "minmax(170px,1.5fr) 84px 118px 92px 96px";
      stopEl.innerHTML = `
        <div class="edge-section-head" style="margin-top:20px;"><span class="title">Stop Sweep</span></div>
        <p class="edge-explain-blurb" style="margin:0 0 8px;">What a fixed per-share stop would have done to these ${sweepRows.length} trades — fills assumed at the stop, before commission, size unchanged.</p>
        ${sweepTableHtml(["Stop placed", "Stop", "Winners stopped", "Losers cut", "Δ total P&amp;L"], cols, res.map((r) => `
          <div class="edge-row" style="grid-template-columns:${cols};">
            <div class="c-label" style="text-transform:none;">${stopLabels[r.level]}</div>
            <div class="c-num">${fmtPx(r.level)}</div>
            <div class="c-num">${fmtShare(r.winnerShare)} <span style="color:var(--text-faint);">(${r.winnersStopped})</span></div>
            <div class="c-num">${r.losersImproved}</div>
            ${deltaCell(r.delta)}
          </div>`).join(""))}`;
    } else {
      stopEl.innerHTML = "";
    }

    // ---- target sweep: targets at MFE percentiles across all trades ----
    const tgtQs = [[0.25, 75], [0.5, 50], [0.75, 25], [0.9, 10]];
    const tgtLevels = [], tgtLabels = {};
    tgtQs.forEach(([q, reachedPct]) => {
      const lvl = Math.floor(p(sweepRows, "mfe", q) * 100 + 1e-9) / 100; // round DOWN to the cent
      if (lvl > 0 && !(lvl in tgtLabels)) { tgtLevels.push(lvl); tgtLabels[lvl] = `Reached by ~${reachedPct}% of trades`; }
    });
    if (tgtLevels.length) {
      const res = ES.targetSweep(sweepRows, tgtLevels);
      const cols = "minmax(170px,1.5fr) 84px 118px 96px";
      tgtEl.innerHTML = `
        <div class="edge-section-head" style="margin-top:20px;"><span class="title">Target Sweep</span></div>
        <p class="edge-explain-blurb" style="margin:0 0 8px;">What taking profit at a fixed per-share target would have done — fills assumed at the target, which also caps bigger winners.</p>
        ${sweepTableHtml(["Target placed", "Target", "Trades reaching it", "Δ total P&amp;L"], cols, res.map((r) => `
          <div class="edge-row" style="grid-template-columns:${cols};">
            <div class="c-label" style="text-transform:none;">${tgtLabels[r.level]}</div>
            <div class="c-num">${fmtPx(r.level)}</div>
            <div class="c-num">${fmtShare(r.reachedShare)}</div>
            ${deltaCell(r.delta)}
          </div>`).join(""))}`;
    } else {
      tgtEl.innerHTML = "";
    }
  }

  // ================= 7. LOSING STREAKS & DRAWDOWN (trade-shuffle) =================
  function renderShuffle(rows) {
    const sumEl = document.getElementById("shuffle-summary");
    const streakEl = document.getElementById("shuffle-streaks");
    const fanEl = document.getElementById("shuffle-fan");
    const statusEl = document.getElementById("shuffle-status");
    if (!sumEl) return;
    const ES = statsOrMessage(sumEl);
    if (!ES) return;
    const pnls = [], lose = [];
    rows.forEach((r) => {
      if (typeof r.pnl_after_comm === "number" && isFinite(r.pnl_after_comm)) { pnls.push(r.pnl_after_comm); lose.push(r.win ? 0 : 1); }
    });
    const sim = ES.shuffleSimulation(pnls, lose, { runs: 5000, seed: shuffleSeed });
    if (!sim) {
      summaryState.streak95 = null;
      sumEl.innerHTML = `<div class="empty-state small">Needs at least 5 trades to shuffle.</div>`;
      streakEl.innerHTML = ""; fanEl.innerHTML = ""; if (statusEl) statusEl.textContent = "";
      return;
    }
    summaryState.streak95 = Math.ceil(sim.streak.p95);
    if (statusEl) statusEl.textContent = `${sim.runs.toLocaleString()} shuffles of ${sim.n} trades`;

    const card = (label, value, sub, cls) => `<div class="stat"><div class="label-row"><span class="label">${label}</span></div><div class="value ${cls || ""}">${value}</div><div class="sub-value">${sub}</div></div>`;
    const dd = (v) => fmtMoney(-v);
    sumEl.innerHTML = `
      <div class="stat-grid" style="margin-bottom:16px;">
        ${card("Losing Streak — Typical", `${Math.round(sim.streak.median)} in a row`, `95th pct: ${Math.ceil(sim.streak.p95)} · 99th: ${Math.ceil(sim.streak.p99)}`)}
        ${card("Losing Streak — Yours", `${sim.actual.streak} in a row`, `${fmtShare(sim.actualStreakShare)} of shuffles were this long or longer`)}
        ${card("Max Drawdown — Typical", dd(sim.maxDD.median), `95th pct: ${dd(sim.maxDD.p95)} · 99th: ${dd(sim.maxDD.p99)}`, "down")}
        ${card("Max Drawdown — Yours", dd(sim.actual.maxDD), `${fmtShare(sim.actualDDShare)} of shuffles were at least this deep`, "down")}
      </div>`;

    // P(longest losing streak >= k), a few values either side of typical.
    const kStart = Math.max(1, Math.round(sim.streak.median) - 3);
    const kEnd = Math.min(Math.ceil(sim.streak.p99) + 2, kStart + 24);
    let below = 0;
    for (let j = 0; j < kStart; j++) below += sim.streakCounts[j] || 0;
    let barsHtml = "";
    for (let k = kStart; k <= kEnd; k++) {
      const share = (sim.runs - below) / sim.runs;
      below += sim.streakCounts[k] || 0;
      const pct = Math.round(share * 1000) / 10;
      const mine = k === sim.actual.streak;
      barsHtml += `<div class="edge-row" style="grid-template-columns: 190px minmax(60px,1fr) 56px;">
        <div class="c-label" style="text-transform:none;${mine ? "color:var(--primary); font-weight:700;" : ""}">${k}+ in a row${mine ? " ← yours" : ""}</div>
        <div class="c-bar bar-track"><div class="bar-fill" data-w="${pct}" style="width:0%; background:${mine ? "var(--primary)" : "var(--red)"};"></div></div>
        <div class="c-num">${fmtShare(share)}</div>
      </div>`;
    }
    streakEl.innerHTML = `<div class="edge-section-head" style="margin-top:6px;"><span class="title">Chance the Longest Losing Streak Reaches…</span></div>
      <p class="edge-explain-blurb" style="margin:4px 0 8px;">Share of shuffled orderings of your ${sim.n} trades containing a losing streak at least this long.</p>${barsHtml}`;
    animateBarFills(streakEl);

    // Equity fan vs. actual order.
    fanEl.innerHTML = "";
    const chart = makeChart(fanEl, 260, { timeScale: { borderColor: "#262a34", tickMarkFormatter: (t) => "#" + t }, localization: { timeFormatter: (t) => "Trade #" + t } });
    const addLine = (arr, color, width, style) => {
      const series = chart.addLineSeries({ color, lineWidth: width, lineStyle: style || 0, priceLineVisible: false, lastValueVisible: false });
      series.setData(arr.map((v, i) => ({ time: i + 1, value: Math.round(v * 100) / 100 })));
    };
    addLine(sim.bands.p5, "rgba(242,85,90,0.85)", 1);
    addLine(sim.bands.p25, "rgba(139,143,163,0.7)", 1, 2);
    addLine(sim.bands.p50, "#8b7cf6", 2);
    addLine(sim.bands.p75, "rgba(139,143,163,0.7)", 1, 2);
    addLine(sim.bands.p95, "rgba(47,208,138,0.85)", 1);
    let cum = 0;
    addLine(pnls.map((v) => (cum += v)), "#e8a94c", 2);
    chart.timeScale().fitContent();
  }

})();
