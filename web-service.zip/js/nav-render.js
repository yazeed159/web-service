// nav-render.js — renders the sidebar's Journal/More/Work-in-Progress
// nav links and highlights the active page.
//
// Split out of common.js and loaded right after the sidebar markup
// (instead of at the bottom of the page with the rest of common.js).
// The mount points (#sidebar-main-section / #sidebar-more-section /
// #sidebar-wip-section) used to sit empty until common.js ran as the
// very last <script> on the page -- on any page with a lot of markup/
// inline scripts above it, that meant a visibly empty nav (just the
// logo, no links) for a beat on every single page load, which on top
// of the full page navigation browsers already do made every click
// look like it had landed on a broken/different site. Running this
// immediately after the sidebar's HTML exists removes that gap
// entirely -- the nav is complete before the browser even gets to the
// rest of the page.
(function () {
  "use strict";

  // Single source of truth for the sidebar's "Journal" section -- the
  // first four items (Dashboard/Day View/Reports/Journal) used to be
  // hand-copied into every page's sidebar markup individually (16 files
  // carried an identical copy), rather than generated like the "More"
  // section below. Folded into the same mount-point pattern so a future
  // nav change (add/reorder/tooltip) is one edit here instead of a sweep
  // across every page.
  //
  // index.html is deliberately NOT part of this: its first three items
  // are <button data-tab> elements wired to in-page tab switching by
  // app.js (not links to other pages), and app.js's click-binding for
  // them runs *before* common.js on that page, so templating them here
  // would leave them unbound. They stay hand-written in index.html.
  const SIDEBAR_MAIN_ITEMS = [
    {
      href: "index.html", title: "Dashboard",
      icon: '<rect x="3" y="3" width="7" height="9" rx="1.5"></rect><rect x="14" y="3" width="7" height="5" rx="1.5"></rect><rect x="14" y="12" width="7" height="9" rx="1.5"></rect><rect x="3" y="16" width="7" height="5" rx="1.5"></rect>',
      label: "Dashboard",
    },
    {
      href: "index.html#dayview", title: "Day View",
      icon: '<rect x="3" y="4.5" width="18" height="16" rx="2"></rect><line x1="3" y1="9.5" x2="21" y2="9.5"></line><line x1="8" y1="2.5" x2="8" y2="6.5"></line><line x1="16" y1="2.5" x2="16" y2="6.5"></line>',
      label: "Day View",
    },
    {
      href: "index.html#reports", title: "Reports",
      icon: '<line x1="5" y1="21" x2="5" y2="10"></line><line x1="12" y1="21" x2="12" y2="4"></line><line x1="19" y1="21" x2="19" y2="14"></line>',
      label: "Reports",
    },
    {
      href: "journal.html", title: "Journal",
      icon: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>',
      label: "Journal",
      // trade.html (a single trade's detail view) is conceptually part
      // of the Journal section, so it lights this up too even though
      // its own filename doesn't match "journal.html".
      extraActiveFiles: ["trade.html"],
    },
    {
      href: "daily.html", title: "Daily plan and review",
      icon: '<polyline points="9 11 12 14 22 4"></polyline><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>',
      label: "Daily",
    },
  ];

  // Single source of truth for the sidebar's "More" section -- every
  // page used to carry its own copy of this exact list (label, href,
  // and icon), hand-copied page to page. In practice that's already
  // drifted twice: quiz.html was the only page whose sidebar linked to
  // itself (added when the Quiz page shipped, never back-filled onto
  // the other 14 pages), and report.html's Import Trades tooltip picked
  // up extra wording ("...into your real journal") that never made it
  // back to the other copies. Both are folded into this single list
  // below, so every page shows the same items and the same wording,
  // and adding a page here is the only place it needs adding.
  //
  // Quiz itself has been removed (it duplicated Rewind's setup-quiz-
  // history-play flow) -- quiz.html, css/quiz.css and js/quiz.js are
  // gone. css/quiz-shared.css stays: Practice and Rewind's quiz-style
  // screens still use those classes.
  const SIDEBAR_MORE_ITEMS = [
    {
      // Real target is user-configurable (window.N8N_IMPORT_URL, set by
      // config.js) -- resolved at render time below, not hardcoded here,
      // since config.js hasn't run yet the first time this file executes
      // (it loads later in every page's <script> order) and this item's
      // HTML gets rebuilt from scratch on every SPA navigation, not just
      // once on initial page load. "import-trades.html" is just the
      // fallback for the (in-practice-unreachable) case config.js hasn't
      // set it yet.
      id: "import-trades-link", title: "Upload a CSV of past trades to import into your real journal",
      icon: '<path d="M12 3v12"></path><path d="M7 8l5-5 5 5"></path><path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"></path>',
      label: "Import Trades",
    },
    {
      href: "stats.html",
      icon: '<path d="M3 3v18h18"></path><path d="M18.4 8.6 12 15l-3-3-4 4"></path>',
      label: "Performance",
    },
    {
      href: "edge-analysis.html",
      icon: '<path d="M3 3l7 7-4 11L21 3 10 14l11 7-7-4"></path><circle cx="3" cy="3" r="1.4" fill="currentColor" stroke="none"></circle>',
      label: "Edge Analysis",
    },
    {
      href: "patterns.html",
      icon: '<circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"></line><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"></line>',
      label: "Patterns",
    },
    {
      href: "calculator.html",
      icon: '<rect x="4" y="2" width="16" height="20" rx="2"></rect><line x1="8" y1="7" x2="16" y2="7"></line><line x1="8" y1="12" x2="8.01" y2="12"></line><line x1="12" y1="12" x2="12.01" y2="12"></line><line x1="16" y1="12" x2="16.01" y2="12"></line><line x1="8" y1="16" x2="8.01" y2="16"></line><line x1="12" y1="16" x2="12.01" y2="16"></line><line x1="16" y1="16" x2="16.01" y2="16"></line>',
      label: "Calculator",
    },
    {
      href: "backtester.html",
      icon: '<polyline points="3 17 9 11 13 15 21 6"></polyline><polyline points="15 6 21 6 21 12"></polyline>',
      label: "Backtester",
    },
    {
      href: "rewind.html",
      icon: '<polygon points="11 19 2 12 11 5 11 19"></polygon><polygon points="22 19 13 12 22 5 22 19"></polygon>',
      label: "Rewind",
    },
    {
      href: "practice.html",
      icon: '<circle cx="12" cy="12" r="10"></circle><polygon points="10 8 16 12 10 16 10 8"></polygon>',
      label: "Practice",
    },
    {
      href: "accounts.html", title: "Real accounts, deposits/periods and paper-trading attempts",
      icon: '<path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h14a2 2 0 0 1 2 2v3"></path><path d="M3 7v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3"></path><path d="M17 14h4v4h-4a2 2 0 0 1 0-4z"></path>',
      label: "Accounts",
    },
    {
      href: "settings.html",
      icon: '<circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>',
      label: "Settings",
    },
  ];

  // Sidebar's third section, for pages that are live in the nav but
  // not finished yet -- kept visually separate (its own "Work in
  // Progress" label) rather than mixed into "More" so it doesn't read
  // as a finished feature.
  const SIDEBAR_WIP_ITEMS = [
    {
      href: "live-trading.html",
      icon: '<circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"></circle>',
      label: "Live Trading",
    },
    {
      href: "scanner.html",
      icon: '<path d="M3 11l18-8-8 18-2-8-8-2z"></path>',
      label: "Scanner",
    },
  ];

  // Wrapped in a named, re-callable function (instead of running once
  // inline) so the SPA router (js/page-transition.js) can call this
  // again after swapping in a new page's content -- the mount points
  // below live in the persistent sidebar, which the router never
  // touches, so re-running this is just "recompute the active item
  // for wherever we are now", safe to call as many times as needed.
  function renderNav() {
  const mainMount = document.getElementById("sidebar-main-section");
  const moreMount = document.getElementById("sidebar-more-section");
  const wipMount = document.getElementById("sidebar-wip-section");
  if (!mainMount && !moreMount && !wipMount) return; // page has no app-shell sidebar, or hasn't adopted the mount points yet

  // The active item is whichever page we're actually on -- compared by
  // filename only (not the full href), since deep links can carry a
  // hash or query string (e.g. a filtered edge-analysis.html?setup=...).
  // Normalized (decoded + lowercased + trailing-slash-stripped) so a
  // trailing slash, URL-encoded character, or case difference from how
  // a link/bookmark was typed doesn't silently break the match.
  // Also strips a trailing ".html" so this matches regardless of
  // whether the page is reached via its raw filename (journal.html)
  // or via the clean URL the Worker actually serves in production
  // (…/journal, no extension) -- without this, currentFile ("journal")
  // never matched any item's hrefFile ("journal.html") and the active
  // state silently never lit up on ANY page.
  function normalizeFile(name) {
    try {
      return decodeURIComponent(name || "").toLowerCase().replace(/\/+$/, "").replace(/\.html$/, "");
    } catch (e) {
      return String(name || "").toLowerCase().replace(/\.html$/, "");
    }
  }
  const currentFile = normalizeFile(window.location.pathname.split("/").pop()) || "index";

  // Dashboard / Day View / Reports are all index.html, distinguished
  // only by #hash -- stripping the hash before comparing (as the
  // generic filename check below does) collapses all three to the
  // same "index" identifier and lights all three up together whenever
  // we're anywhere on index.html. Only index.html's own tab hashes are
  // compared this way; every other item keeps the filename-only check.
  const currentHash = (window.location.hash || "").replace(/^#/, "");
  if (mainMount) {
    // No section heading above this first block of links (it used to say
    // "Journal" on every page, including ones that live under "More").
    mainMount.innerHTML =
      SIDEBAR_MAIN_ITEMS.map((item) => {
        const hrefFile = normalizeFile(item.href.split("?")[0].split("#")[0]);
        const hrefHash = (item.href.split("#")[1] || "");
        const isActive =
          (hrefFile === currentFile && (hrefFile !== "index" || hrefHash === currentHash)) ||
          (item.extraActiveFiles || []).some((f) => normalizeFile(f) === currentFile);
        return (
          `<a class="nav-item${isActive ? " active" : ""}" href="${item.href}" title="${item.title}">` +
          `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${item.icon}</svg>` +
          `<span class="nav-label">${item.label}</span>` +
          `</a>`
        );
      }).join("");
  }

  // Shared renderer for the "More" and "Work in Progress" sections --
  // same item shape, same markup, just a different label and list.
  function renderSection(mount, label, items) {
    if (!mount) return;
    mount.innerHTML =
      `<div class="nav-section-label">${label}</div>` +
      items.map((item) => {
        const href = item.href || window.N8N_IMPORT_URL || "import-trades.html";
        const isActive = href !== "#" && normalizeFile(href.split("?")[0]) === currentFile;
        const idAttr = item.id ? ` id="${item.id}"` : "";
        // Every item gets a title tooltip (falling back to its label) so
        // hovering an icon identifies the page even when the sidebar is
        // collapsed and the text label is hidden -- previously only the
        // "Import Trades" item had one, so every other icon was unlabeled
        // once collapsed.
        const titleAttr = ` title="${item.title || item.label}"`;
        return (
          `<a class="nav-item${isActive ? " active" : ""}"${idAttr} href="${href}"${titleAttr}>` +
          `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${item.icon}</svg>` +
          `<span class="nav-label">${item.label}</span>` +
          `</a>`
        );
      }).join("");
  }
  renderSection(moreMount, "More", SIDEBAR_MORE_ITEMS);
  renderSection(wipMount, "Work in Progress", SIDEBAR_WIP_ITEMS);

  // The shell (this nav + the topbar/page skeleton around it) is now
  // fully in place -- fade out the top progress bar and the full-screen
  // loading screen from common.css together. Data inside the page may
  // still be fetching, but that's this page's own "Loading…"
  // placeholder to show, not this bar/overlay's job.
  //
  // Both elements are only *hidden* here (the "done" class), never
  // removed from the document. page-transition.js re-arms them the
  // instant someone clicks a link to leave this page -- if they'd been
  // torn out of the DOM already (as an earlier version of this file
  // did, via removeChild on a timeout), that re-arm would be flipping
  // a class on a detached node nobody can see, and the departing page
  // would flash its raw content with nothing covering it right up
  // until the browser actually unloads it. Leaving them in place is
  // what makes them reusable for that split second.
  var bar = document.getElementById("page-progress-bar");
  var loader = document.getElementById("page-loader-overlay");
  requestAnimationFrame(function () {
    if (bar) bar.classList.add("done");
    if (loader) loader.classList.add("done");
  });
  } // end renderNav()

  // ---- Phone bottom tab bar ------------------------------------------
  // The sidebar is a hidden drawer on phones, so every page change cost
  // two taps (hamburger, then link). This is a thumb-reach tab bar with the
  // four most-used pages plus "More", which opens that same drawer. It's
  // hidden above 760px by CSS (.bottom-nav), so desktop is unchanged.
  const BOTTOM_ITEMS = [
    { href: "index.html", file: "index", label: "Home", icon: '<rect x="3" y="3" width="7" height="9" rx="1.5"></rect><rect x="14" y="3" width="7" height="5" rx="1.5"></rect><rect x="14" y="12" width="7" height="9" rx="1.5"></rect><rect x="3" y="16" width="7" height="5" rx="1.5"></rect>' },
    { href: "journal.html", file: "journal", label: "Journal", icon: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"></path><line x1="9" y1="9" x2="15" y2="9"></line><line x1="9" y1="13" x2="15" y2="13"></line>' },
    { href: "daily.html", file: "daily", label: "Daily", icon: '<rect x="3" y="4.5" width="18" height="16" rx="2"></rect><line x1="3" y1="9.5" x2="21" y2="9.5"></line><line x1="8" y1="2.5" x2="8" y2="6.5"></line><line x1="16" y1="2.5" x2="16" y2="6.5"></line>' },
    { href: "practice.html", file: "practice", label: "Practice", icon: '<polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="15 7 21 7 21 13"></polyline>' },
  ];
  function bottomNav() {
    if (!document.getElementById("sidebar")) return; // not an app-shell page (login etc.)
    let nav = document.getElementById("bottom-nav");
    if (!nav) {
      nav = document.createElement("nav");
      nav.id = "bottom-nav";
      nav.className = "bottom-nav";
      nav.setAttribute("aria-label", "Primary");
      nav.innerHTML = BOTTOM_ITEMS.map((i) =>
        `<a class="bn-item" data-file="${i.file}" href="${i.href}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${i.icon}</svg><span>${i.label}</span></a>`
      ).join("") +
        `<button type="button" class="bn-item" id="bn-more" aria-label="More pages"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="4" y1="7" x2="20" y2="7"></line><line x1="4" y1="12" x2="20" y2="12"></line><line x1="4" y1="17" x2="20" y2="17"></line></svg><span>More</span></button>`;
      document.body.appendChild(nav);
      nav.querySelector("#bn-more").addEventListener("click", () => {
        const btn = document.getElementById("mobile-nav-btn");
        if (btn) btn.click();
      });
    }
    let cur = "";
    try { cur = decodeURIComponent(location.pathname.split("/").pop() || "index").toLowerCase().replace(/\.html$/, "") || "index"; } catch (e) {}
    nav.querySelectorAll("a.bn-item").forEach((a) => {
      const on = a.getAttribute("data-file") === cur;
      a.classList.toggle("active", on);
      if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
    });
  }

  // Exposed for the SPA router to call after an in-place content swap.
  window.__renderSidebarNav = function () { renderNav(); bottomNav(); };
  renderNav();
  bottomNav();
})();
