// share-export.js — builds a single, fully self-contained static HTML file
// ("shareable mini-page") for either one trade or a filtered set of trades,
// and triggers a browser download of it. No fetch()es of local data files:
// everything the page needs is embedded inline, so the result can be
// opened straight from disk, emailed, or uploaded anywhere as one file.
//
// Used by trade.js (single-trade "Share" button) and journal.html's inline
// script (filtered-set "Share this view" button).
window.TradeLogShare = (function () {
  "use strict";

// escapeHtml() now in utils.js (loads first on every page).
// fmtMoney() now in utils.js (loads first on every page).
// fmtPct() now in utils.js (loads first on every page). NOTE: canonical
// fmtPct() returns "—" for invalid input; this file's old copy coerced to
// 0 and rendered "0.0%" instead -- winRate is always a finite number by
// the time it reaches this call, so the difference is not observable here.
  // toUnix() now in utils.js (loads first on every page). NOTE: the
  // *other* toUnix() further down in this file, inside the
  // scriptExtra template string, is intentionally NOT touched -- that
  // one runs inside the standalone exported HTML file this module
  // generates, which has no access to utils.js and must stay fully
  // self-contained.
  function nowStamp() {
    const d = new Date();
    return d.toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  }

  // Shared dark theme, lifted from core.css's design tokens, kept minimal
  // and inlined so the exported file has zero dependency on this app's
  // stylesheets living at some relative path.
  const BASE_CSS = `
    :root{
      --bg:#0a0b0f; --panel:#14161c; --panel-2:#191c24; --border:#262a34; --border-soft:#1b1e26;
      --text:#eceef2; --text-dim:#8b8fa3; --text-faint:#565a6b;
      --green:#2fd08a; --green-soft:rgba(47,208,138,.12);
      --red:#f2555a; --red-soft:rgba(242,85,90,.12);
      --blue:#5b93f0; --amber:#e8a94c;
      --primary:#8b7cf6; --primary-2:#6e5bf0;
      --mono:'IBM Plex Mono', ui-monospace, 'SF Mono', Menlo, monospace;
      --sans:-apple-system, BlinkMacSystemFont, 'Inter', system-ui, sans-serif;
      --radius:10px;
    }
    *{box-sizing:border-box;}
    body{margin:0; background:var(--bg); color:var(--text); font-family:var(--sans); font-size:14px; line-height:1.5;}
    .wrap{max-width:900px; margin:0 auto; padding:28px 20px 60px;}
    .brand{display:flex; align-items:center; gap:8px; text-decoration:none; color:var(--text); font-weight:700; font-size:15px; margin-bottom:18px;}
    .brand .mark{width:22px; height:22px; border-radius:6px; background:linear-gradient(120deg,var(--primary),var(--blue)); display:flex; align-items:center; justify-content:center; font-size:12px; color:#fff;}
    .muted{color:var(--text-faint); font-weight:500;}
    .card{background:var(--panel); border:1px solid var(--border); border-radius:var(--radius); padding:16px 18px; margin-bottom:16px;}
    h1{font-size:22px; margin:0 0 4px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;}
    h2{font-size:14px; margin:0 0 12px;}
    .badge{font-size:12px; font-weight:700; padding:3px 9px; border-radius:999px; letter-spacing:.02em;}
    .badge.up{background:var(--green-soft); color:var(--green);}
    .badge.down{background:var(--red-soft); color:var(--red);}
    .up{color:var(--green);} .down{color:var(--red);}
    .meta{color:var(--text-dim); font-size:12.5px; margin-bottom:18px;}
    .meta-standout{color:var(--text); font-weight:600;}
    .pnl-grid{display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--border); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; margin-bottom:18px;}
    .pnl-grid .cell{background:var(--panel); padding:12px 14px;}
    .pnl-grid .label{font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:.03em; margin-bottom:4px;}
    .pnl-grid .value{font-size:17px; font-weight:700; font-variant-numeric:tabular-nums;}
    .verdict-text{font-size:13px; line-height:1.6; color:var(--text-dim); margin-bottom:10px;}
    .setup-tag{display:inline-block; font-size:11px; font-weight:600; padding:3px 9px; border-radius:999px; background:rgba(139,124,246,.14); color:var(--primary);}
    .walk-away{margin-top:12px; font-size:12.5px; padding:10px 12px; background:var(--panel-2); border-radius:8px; border:1px solid var(--border-soft);}
    .better-row{display:flex; gap:10px; align-items:baseline; padding:6px 0; border-bottom:1px solid rgba(255,255,255,.06);}
    .better-row .tag{font-size:10px; font-weight:700; letter-spacing:.03em; opacity:.65; min-width:38px; flex-shrink:0;}
    .better-row .price-line{font-size:12.5px; font-weight:600;}
    .better-row .reason{font-size:11.5px; opacity:.75; margin-top:1px;}
    .no-better{font-size:12px; opacity:.7;}
    .lessons-list{margin:0; padding-left:18px;}
    .lessons-list li{margin-bottom:8px; font-size:12.5px;}
    .lesson-tag{display:inline-block; font-size:10px; font-weight:600; letter-spacing:.02em; text-transform:uppercase; padding:1px 6px; border-radius:3px; background:rgba(91,147,240,.15); color:var(--blue); margin-left:6px; vertical-align:middle;}
    .legend{display:flex; flex-wrap:wrap; gap:12px; font-size:11px; color:var(--text-faint); margin-bottom:8px;}
    .legend-item{display:flex; align-items:center; gap:4px;}
    .legend-swatch{width:9px; height:9px; border-radius:2px; display:inline-block;}
    #candle-chart{width:100%; height:380px; position:relative;}
    .chart-info-overlay{position:absolute; top:8px; left:10px; z-index:3; pointer-events:none; display:flex; flex-direction:column; gap:2px; font-family:var(--mono); font-size:11.5px; line-height:1.5;}
    .chart-info-overlay .row{display:flex; gap:6px; align-items:baseline;}
    .chart-info-overlay .k{color:var(--text-faint);}
    .chart-info-overlay .v{color:var(--text); font-weight:600;}
    .chart-info-overlay .v.up{color:var(--green);}
    .chart-info-overlay .v.down{color:var(--red);}
    .footer-note{margin-top:22px; font-size:11.5px; color:var(--text-faint); border-top:1px solid var(--border-soft); padding-top:14px;}
    .stat-row{display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--border); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; margin-bottom:18px;}
    .stat-row .cell{background:var(--panel); padding:12px 14px;}
    .stat-row .label{font-size:11px; color:var(--text-faint); text-transform:uppercase; letter-spacing:.03em; margin-bottom:4px;}
    .stat-row .value{font-size:17px; font-weight:700; font-variant-numeric:tabular-nums;}
    table.data-table{width:100%; border-collapse:collapse; font-size:12.5px;}
    table.data-table th{text-align:left; color:var(--text-faint); font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.02em; padding:8px 10px; border-bottom:1px solid var(--border);}
    table.data-table td{padding:8px 10px; border-bottom:1px solid var(--border-soft);}
    .pill{display:inline-block; font-size:11px; font-weight:700; padding:2px 8px; border-radius:999px;}
    .pill.win{background:var(--green-soft); color:var(--green);}
    .pill.loss{background:var(--red-soft); color:var(--red);}
    .filters-summary{font-size:12.5px; color:var(--text-dim); margin-bottom:18px;}
    svg.equity-svg{width:100%; height:140px; display:block;}

    /* Glass skin (self-contained: this page is exported on its own and can't load the app's CSS) */
    :root{ --g-fill:rgba(30,33,44,.46); --g-fill-strong:rgba(20,22,30,.72); --g-line:rgba(255,255,255,.09); --g-hi:rgba(255,255,255,.14);
      --g-blur:blur(24px) saturate(175%); --g-sheen:linear-gradient(145deg,rgba(255,255,255,.10) 0%,rgba(255,255,255,.03) 30%,rgba(255,255,255,0) 58%); }
    body{ background:#07080c; min-height:100vh; -webkit-font-smoothing:antialiased; }
    body::before{ content:""; position:fixed; inset:0; z-index:-1; pointer-events:none;
      background:
        radial-gradient(38% 46% at 12% 12%, rgba(139,124,246,.34), transparent 70%),
        radial-gradient(34% 40% at 90% 8%, rgba(34,211,238,.18), transparent 70%),
        radial-gradient(40% 44% at 92% 70%, rgba(242,85,90,.18), transparent 72%),
        radial-gradient(46% 42% at 40% 98%, rgba(47,208,138,.14), transparent 72%); }
    .card, .pnl-grid, .stat-row{ background:var(--g-sheen), var(--g-fill); border:1px solid var(--g-line); border-radius:20px;
      -webkit-backdrop-filter:var(--g-blur); backdrop-filter:var(--g-blur); box-shadow:inset 0 1px 0 var(--g-hi), 0 14px 38px rgba(0,0,0,.34); }
    .pnl-grid, .stat-row{ gap:0; }
    .pnl-grid .cell, .stat-row .cell{ background:transparent; }
    .pnl-grid .cell + .cell, .stat-row .cell + .cell{ box-shadow:-1px 0 0 var(--g-line); }
    .brand .mark{ border-radius:8px; color:#fff; box-shadow:inset 0 1px 0 rgba(255,255,255,.35), 0 6px 18px rgba(139,124,246,.45); }
    .badge{ border:1px solid currentColor; box-shadow:0 0 16px -4px currentColor; }
    .badge.up{ background:rgba(47,208,138,.13); } .badge.down{ background:rgba(242,85,90,.13); }
    .setup-tag, .pill, .lesson-tag{ border-radius:999px; }
    .pill.win{ box-shadow:0 0 12px -4px var(--green); } .pill.loss{ box-shadow:0 0 12px -4px var(--red); }
    .walk-away{ border-radius:14px; background:var(--g-fill); border-color:var(--g-line); }
    .better-row, table.data-table td, .footer-note{ border-color:var(--g-line); }
    table.data-table th{ border-bottom-color:var(--g-line); letter-spacing:.06em; }
    table.data-table tbody tr:hover{ background:rgba(139,124,246,.08); }
    .chart-info-overlay{ background:rgba(20,22,30,.55); -webkit-backdrop-filter:blur(10px); backdrop-filter:blur(10px); border:1px solid var(--g-line); border-radius:12px; padding:6px 10px; }
    @media (max-width:640px){ .pnl-grid, .stat-row{ grid-template-columns:repeat(2,1fr); } .pnl-grid .cell:nth-child(n+3), .stat-row .cell:nth-child(n+3){ box-shadow:0 -1px 0 var(--g-line); } .wrap{ padding:20px 14px 48px; } }
  `;

  function pageShell({ title, headExtra, bodyHtml, scriptExtra }) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title)}</title>
<link rel="icon" href="data:,">
${headExtra || ""}
<style>${BASE_CSS}</style>
</head>
<body>
<div class="wrap">
  <div class="brand"><span class="mark">T</span> trade<span class="muted">.log</span> <span class="muted" style="font-weight:500; font-size:12px;">· static export</span></div>
  ${bodyHtml}
</div>
${scriptExtra || ""}
</body>
</html>`;
  }

  // ---- single trade ---------------------------------------------------

  function betterRowHtml(label, b) {
    if (!b || !b.price) return "";
    return `<div class="better-row">
      <div class="tag">${escapeHtml(label.toUpperCase())}</div>
      <div class="content" style="flex:1; min-width:0;">
        <div class="price-line">$${Number(b.price).toFixed(2)}${b.time ? ` @ ${escapeHtml(String(b.time).split("T").pop())}` : ""}</div>
        ${b.reason ? `<div class="reason">${escapeHtml(b.reason)}</div>` : ""}
      </div>
    </div>`;
  }

  function lessonItemHtml(l) {
    if (typeof l === "string") {
      // Lessons occasionally round-trip as a raw JSON string instead of
      // an object -- parse it back so it renders the same as any other
      // lesson instead of dumping raw JSON text into the shared page.
      try {
        const parsed = JSON.parse(l);
        if (parsed && typeof parsed === "object") l = parsed;
      } catch (e) { /* genuinely plain text -- fall through below */ }
    }
    if (typeof l === "string") return `<li>${escapeHtml(l)}</li>`;
    const tagBadge = l.tag ? `<span class="lesson-tag">${escapeHtml(String(l.tag).replace(/_/g, " "))}</span>` : "";
    return `<li>${escapeHtml(l.lesson || l.text || "")}${tagBadge}</li>`;
  }

  // The trader's own journal entry (trade-notes.js), if that module is on
  // the page. Read here so callers don't have to pass it in.
  function journalFor(trade) {
    try { return window.TradeNotes && trade && trade.id ? window.TradeNotes.get(trade.id) : null; } catch (e) { return null; }
  }
  function journalMetrics(trade, je) {
    try { return window.TradeNotes && je ? window.TradeNotes.metrics(trade, je) : null; } catch (e) { return null; }
  }
  function flagsOf(r) {
    const TC = window.TagCatalog;
    return TC && Array.isArray(r.behavior_tags) ? r.behavior_tags.filter((k) => TC.tone(k) === "watch").map((k) => TC.label(k)) : [];
  }
  function cleanOf(r) { return window.TagCatalog ? window.TagCatalog.isClean(r) : null; }
  function fmtR(v) { return v == null ? "—" : (v >= 0 ? "+" : "") + v.toFixed(2) + "R"; }

  function journalCardHtml(trade) {
    const je = journalFor(trade) || {};
    const TC = window.TagCatalog;
    const flags = TC && Array.isArray(trade.behavior_tags) ? trade.behavior_tags.filter((k) => TC.tone(k) === "watch").map((k) => TC.label(k)) : [];
    const clean = TC ? TC.isClean(trade) : null;
    if (!Object.keys(je).length && !flags.length && clean === null) return "";
    const m = journalMetrics(trade, je) || {};
    const cleanTxt = clean === true ? "Yes" : clean === false ? "No" : "—";
    const chips = (arr) => arr.map((x) => `<span class="setup-tag" style="margin-right:6px;">${escapeHtml(x)}</span>`).join("");
    return `
      <div class="card">
        <h2>Trader's journal</h2>
        <div class="meta" style="margin-bottom:10px;">
          ${trade.setup_type ? `Setup <span class="meta-standout">${escapeHtml(window.setupLabel ? window.setupLabel(trade.setup_type) : String(trade.setup_type).replace(/_/g, " "))}</span> &nbsp;·&nbsp; ` : ""}
          Clean trade <span class="meta-standout">${cleanTxt}</span>
          ${je.plan_stop ? ` &nbsp;·&nbsp; planned stop <span class="meta-standout">$${Number(je.plan_stop).toFixed(2)}</span>` : ""}
          ${je.no_stop ? ` &nbsp;·&nbsp; planned stop <span class="meta-standout">none</span>` : ""}
          ${je.plan_target ? ` &nbsp;·&nbsp; planned target <span class="meta-standout">$${Number(je.plan_target).toFixed(2)}</span>` : ""}
          ${je.no_target ? ` &nbsp;·&nbsp; planned target <span class="meta-standout">none</span>` : ""}
          ${m.planned_rr != null ? ` &nbsp;·&nbsp; planned R:R <span class="meta-standout">${m.planned_rr.toFixed(2)}</span>` : ""}
          ${m.r_multiple != null ? ` &nbsp;·&nbsp; result <span class="meta-standout ${m.r_multiple >= 0 ? "up" : "down"}">${fmtR(m.r_multiple)}</span>` : ""}
        </div>
        ${flags.length ? `<div style="margin-bottom:10px;"><span class="muted" style="font-size:12px;">Flags:</span> ${chips(flags)}</div>` : ""}
        ${(je.notes || "").trim() ? `<div class="verdict-text" style="white-space:pre-wrap;">${escapeHtml(je.notes)}</div>` : ""}
      </div>`;
  }

  // Real commission split / fees + the executions, same facts as the trade page (see trade.js).
  function commissionSubline(trade) {
    const ok = (v) => v != null && Number.isFinite(Number(v));
    const fills = Array.isArray(trade.fills) ? trade.fills : [];
    let inn = null, out = null;
    if (ok(trade.commission_in) && ok(trade.commission_out)) { inn = Number(trade.commission_in); out = Number(trade.commission_out); }
    else if (fills.length && fills.every((f) => ok(f.commission_entry) && ok(f.commission_exit))) {
      inn = fills.reduce((n, f) => n + Number(f.commission_entry), 0); out = fills.reduce((n, f) => n + Number(f.commission_exit), 0);
    }
    const parts = [];
    if (inn != null) parts.push(`in $${inn.toFixed(2)} \u00b7 out $${out.toFixed(2)}`);
    if (Number(trade.fees) > 0) parts.push(`+ fees $${Number(trade.fees).toFixed(2)} (not in net)`);
    return parts.length ? `<div class="label" style="margin-top:2px;font-size:11px;text-transform:none;">${parts.join(" \u00b7 ")}</div>` : "";
  }
  function execCardHtml(trade) {
    const fills = Array.isArray(trade.fills) ? trade.fills : [];
    if (!fills.length) return "";
    const byOrder = fills.every((f) => f.entry_order && f.exit_order);
    const agg = new Map();
    const add = (kind, time, price, qty, comm, order, exch) => {
      if (!time || price == null) return;
      const k = byOrder ? `${kind}|o|${order}` : `${kind}|${time}|${Number(price).toFixed(4)}|${exch || ""}`;
      const c = agg.get(k) || { kind, time: String(time), cost: 0, qty: 0, comm: 0, hasComm: true, exch: new Set(), parts: new Set() };
      c.qty += Number(qty) || 0; c.cost += Number(price) * (Number(qty) || 0);
      if (comm != null && Number.isFinite(Number(comm))) c.comm += Number(comm); else c.hasComm = false;
      if (exch) c.exch.add(exch);
      c.parts.add(`${time}|${Number(price).toFixed(4)}|${exch || ""}`);
      if (String(time) < c.time) c.time = String(time);
      agg.set(k, c);
    };
    fills.forEach((f) => { add("entry", f.entry_time, f.entry_price, f.qty, f.commission_entry, f.entry_order, f.entry_exchange); add("exit", f.exit_time, f.exit_price, f.qty, f.commission_exit, f.exit_order, f.exit_exchange); });
    const list = [...agg.values()].sort((a, b) => (a.time < b.time ? -1 : a.time > b.time ? 1 : a.kind === b.kind ? 0 : a.kind === "entry" ? -1 : 1));
    if (!list.length) return "";
    const rows = list.map((e) => `<tr><td style="color:${e.kind === "entry" ? "var(--green)" : "var(--red)"};font-weight:700;">${e.kind === "entry" ? "Entry" : "Exit"}</td>
      <td>${Number(e.qty).toLocaleString(undefined, { maximumFractionDigits: 2 })} sh @ $${(e.qty ? e.cost / e.qty : 0).toFixed(Number(e.cost / e.qty) < 1 ? 4 : 2)}${e.parts.size > 1 ? ` <span style="opacity:.6;">(${e.parts.size} fills)</span>` : ""}</td>
      <td style="opacity:.7;">${escapeHtml([...e.exch].join(", "))}</td><td style="opacity:.7;">${escapeHtml(e.time)}</td><td style="text-align:right;">${e.hasComm ? "$" + e.comm.toFixed(2) : "\u2014"}</td></tr>`).join("");
    return `<div class="card"><h2>Executions</h2><div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;font-family:var(--mono);">
      <thead><tr style="opacity:.55;text-align:left;"><th></th><th>Shares @ price</th><th>Venue</th><th>Time</th><th style="text-align:right;">Comm.</th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
  }

  function buildTradeSharePage(trade) {
    const win = !!trade.win;
    const bars = Array.isArray(trade.bars) ? trade.bars : [];
    // Trim each bar down to just what the standalone chart needs, so the
    // embedded JSON blob doesn't drag along fields (macd, etc.) unused here.
    const chartBars = bars.map((b) => ({ t: b.t, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v, vwap: b.vwap, ema9: b.ema9, ema20: b.ema20, ema200: b.ema200 }));

    const bodyHtml = `
      <h1>
        ${escapeHtml(trade.symbol)}
        <span class="badge ${win ? "up" : "down"}">${win ? "WIN" : "LOSS"} · ${fmtMoney(trade.pnl_after_comm)}</span>
      </h1>
      <div class="meta">
        ${escapeHtml(trade.trade_date)} &nbsp;·&nbsp; entry ${escapeHtml(trade.entry_time)} @ $${Number(trade.entry_price).toFixed(2)}
        &nbsp;→&nbsp; exit ${escapeHtml(trade.exit_time)} @ $${Number(trade.exit_price).toFixed(2)}
        &nbsp;·&nbsp; <span class="meta-standout">${escapeHtml(trade.shares)} sh</span>
        ${trade.time_in_trade ? ` &nbsp;·&nbsp; held <span class="meta-standout">${escapeHtml(trade.time_in_trade)}</span>` : ""}
      </div>

      <div class="pnl-grid">
        <div class="cell"><div class="label">Gross P&amp;L</div><div class="value ${trade.pnl_before_comm >= 0 ? "up" : "down"}">${fmtMoney(trade.pnl_before_comm)}</div></div>
        <div class="cell"><div class="label">Commission</div><div class="value">-$${Number(trade.commission || 0).toFixed(2)}</div>${commissionSubline(trade)}</div>
        <div class="cell"><div class="label">Net P&amp;L</div><div class="value ${trade.pnl_after_comm >= 0 ? "up" : "down"}">${fmtMoney(trade.pnl_after_comm)}</div></div>
        <div class="cell"><div class="label">Setup</div><div class="value" style="font-size:13px;">${escapeHtml((trade.setup_type || "—").toString().replace(/_/g, " "))}</div></div>
      </div>

      ${execCardHtml(trade)}

      ${chartBars.length ? `
      <div class="card">
        <div class="legend">
          <span class="legend-item"><span class="legend-swatch" style="background:#e8a94c"></span>VWAP</span>
          <span class="legend-item"><span class="legend-swatch" style="background:#9aa8a1"></span>EMA9</span>
          <span class="legend-item"><span class="legend-swatch" style="background:#5b93f0"></span>EMA20</span>
          <span class="legend-item"><span class="legend-swatch" style="background:#b57bee"></span>EMA200</span>
          <span class="legend-item"><span class="legend-swatch" style="background:#2fd08a"></span>entry</span>
          <span class="legend-item"><span class="legend-swatch" style="background:#f2555a"></span>exit</span>
          ${trade.better_entry && trade.better_entry.price ? `<span class="legend-item"><span class="legend-swatch" style="background:#8b7cf6"></span>better entry</span>` : ""}
          ${trade.better_exit && trade.better_exit.price ? `<span class="legend-item"><span class="legend-swatch" style="background:#ec6cad"></span>better exit</span>` : ""}
        </div>
        <div id="candle-chart"></div>
      </div>` : ""}

      <div class="card">
        <h2>Verdict</h2>
        <div class="verdict-text">${escapeHtml(trade.verdict || "No verdict recorded.")}</div>
        ${trade.setup_type ? `<span class="setup-tag">${escapeHtml(String(trade.setup_type).replace(/_/g, " "))}</span>` : ""}
        ${trade.walk_away_rule ? `<div class="walk-away"><b>Walk-away rule:</b> ${escapeHtml(trade.walk_away_rule)}</div>` : ""}
      </div>

      ${journalCardHtml(trade)}

      ${(trade.better_entry && trade.better_entry.price) || (trade.better_exit && trade.better_exit.price) ? `
      <div class="card">
        <h2>What you should've done</h2>
        ${betterRowHtml("Entry", trade.better_entry)}
        ${betterRowHtml("Exit", trade.better_exit)}
      </div>` : ""}

      ${Array.isArray(trade.lessons) && trade.lessons.length ? `
      <div class="card">
        <h2>Lessons from this trade</h2>
        <ul class="lessons-list">${trade.lessons.map(lessonItemHtml).join("")}</ul>
      </div>` : ""}

      <div class="footer-note">
        Static snapshot of trade <span style="font-family:var(--mono);">${escapeHtml(trade.id || "")}</span>, exported from trade.log on ${nowStamp()}.
        This is a read-only copy for sharing — replay, AI chat, and support/resistance analysis aren't included.
      </div>
    `;

    const headExtra = chartBars.length
      ? `<script src="https://unpkg.com/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js"></script>`
      : "";

    const scriptExtra = chartBars.length
      ? `<script>
(function(){
  var bars = ${JSON.stringify(chartBars)};
  var trade = ${JSON.stringify({
        entry_time: trade.entry_time, exit_time: trade.exit_time, trade_date: trade.trade_date,
        entry_price: trade.entry_price, exit_price: trade.exit_price,
        better_entry: trade.better_entry, better_exit: trade.better_exit,
      })};
  function toUnix(t){ return Math.floor(new Date(String(t).replace(" ","T") + "Z").getTime()/1000); }
  function barAt(u){ var best = bars[0]; for (var i=0;i<bars.length;i++){ if (toUnix(bars[i].t) <= u) best = bars[i]; else break; } return best; }
  var el = document.getElementById("candle-chart");
  var chart = LightweightCharts.createChart(el, {
    width: el.clientWidth, height: 380,
    layout: { background: { color: "transparent" }, textColor: "#8b98a5" },
    grid: { vertLines: { color: "#1c2127" }, horzLines: { color: "#1c2127" } },
    rightPriceScale: { borderColor: "#232830" },
    timeScale: { borderColor: "#232830", timeVisible: true, secondsVisible: false },
    crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
  });
  var candleSeries = chart.addCandlestickSeries({ upColor:"#2fd08a", downColor:"#f2555a", borderVisible:false, wickUpColor:"#2fd08a", wickDownColor:"#f2555a" });
  candleSeries.setData(bars.map(function(b){ return { time: toUnix(b.t), open:b.o, high:b.h, low:b.l, close:b.c }; }));
  chart.priceScale("right").applyOptions({ scaleMargins: { top: 0.14, bottom: 0.18 } });
  var volSeries = chart.addHistogramSeries({ priceFormat: { type: "volume" }, priceScaleId: "vol" });
  chart.priceScale("vol").applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
  volSeries.setData(bars.map(function(b){ return { time: toUnix(b.t), value: b.v, color: b.c >= b.o ? "rgba(47,208,138,0.4)" : "rgba(242,85,90,0.4)" }; }));
  var vwapSeries = chart.addLineSeries({ color:"#e8a94c", lineWidth:1, priceLineVisible:false, lastValueVisible:false });
  vwapSeries.setData(bars.map(function(b){ return { time: toUnix(b.t), value: b.vwap }; }));
  var ema9Series = chart.addLineSeries({ color:"#9aa8a1", lineWidth:1, priceLineVisible:false, lastValueVisible:false });
  ema9Series.setData(bars.map(function(b){ return { time: toUnix(b.t), value: b.ema9 }; }));
  var ema20Series = chart.addLineSeries({ color:"#5b93f0", lineWidth:1, priceLineVisible:false, lastValueVisible:false });
  ema20Series.setData(bars.map(function(b){ return { time: toUnix(b.t), value: b.ema20 }; }));
  var ema200Series = chart.addLineSeries({ color:"#b57bee", lineWidth:1, priceLineVisible:false, lastValueVisible:false });
  ema200Series.setData(bars.map(function(b){ return { time: toUnix(b.t), value: b.ema200 }; }));

  // Top-left info overlay: live volume/VWAP/EMA9/EMA20/EMA200 readout that
  // tracks the crosshair, same as the interactive trade.js chart this
  // snapshot was exported from. Falls back to the last bar's values
  // when nothing is hovered.
  var infoOverlay = document.createElement("div");
  infoOverlay.className = "chart-info-overlay";
  el.appendChild(infoOverlay);
  function volRowHtml(vol, color){ return '<div class="row"><span class="k">Vol</span><span class="v' + (color ? (" " + color) : "") + '">' + (vol == null ? "—" : Number(vol).toLocaleString()) + '</span></div>'; }
  function indicatorRowsHtml(vwap, ema9, ema20, ema200){
    return '<div class="row"><span class="k">VWAP</span><span class="v" style="color:#e8a94c">' + fmtPrice(vwap) + '</span></div>'
      + '<div class="row"><span class="k">EMA9</span><span class="v" style="color:#9aa8a1">' + fmtPrice(ema9) + '</span></div>'
      + '<div class="row"><span class="k">EMA20</span><span class="v" style="color:#5b93f0">' + fmtPrice(ema20) + '</span></div>'
      + '<div class="row"><span class="k">EMA200</span><span class="v" style="color:#b57bee">' + fmtPrice(ema200) + '</span></div>';
  }
  var lastBar = bars.length ? bars[bars.length - 1] : null;
  function renderOverlay(vol, upDown, vwap, ema9, ema20, ema200){ infoOverlay.innerHTML = volRowHtml(vol, upDown) + indicatorRowsHtml(vwap, ema9, ema20, ema200); }
  renderOverlay(lastBar ? lastBar.v : null, "", lastBar ? lastBar.vwap : null, lastBar ? lastBar.ema9 : null, lastBar ? lastBar.ema20 : null, lastBar ? lastBar.ema200 : null);
  chart.subscribeCrosshairMove(function(param){
    var volBar = param.seriesData && param.seriesData.get(volSeries);
    var vwapBar = param.seriesData && param.seriesData.get(vwapSeries);
    var ema9Bar = param.seriesData && param.seriesData.get(ema9Series);
    var ema20Bar = param.seriesData && param.seriesData.get(ema20Series);
    var ema200Bar = param.seriesData && param.seriesData.get(ema200Series);
    var upDown = volBar ? (volBar.color && volBar.color.indexOf("47,208,138") !== -1 ? "up" : "down") : "";
    renderOverlay(
      volBar ? volBar.value : (lastBar ? lastBar.v : null), upDown,
      vwapBar ? vwapBar.value : (lastBar ? lastBar.vwap : null),
      ema9Bar ? ema9Bar.value : (lastBar ? lastBar.ema9 : null),
      ema20Bar ? ema20Bar.value : (lastBar ? lastBar.ema20 : null),
      ema200Bar ? ema200Bar.value : (lastBar ? lastBar.ema200 : null)
    );
  });

  var markers = [];
  var entryUnix = toUnix(barAt(toUnix(trade.trade_date + " " + trade.entry_time)).t);
  var exitUnix = toUnix(barAt(toUnix(trade.trade_date + " " + trade.exit_time)).t);
  markers.push({ time: entryUnix, position: "belowBar", color: "#2fd08a", shape: "arrowUp", text: "entry $" + Number(trade.entry_price).toFixed(2) });
  markers.push({ time: exitUnix, position: "aboveBar", color: "#f2555a", shape: "arrowDown", text: "exit $" + Number(trade.exit_price).toFixed(2) });
  if (trade.better_entry && trade.better_entry.price) {
    markers.push({ time: entryUnix, position: "belowBar", color: "#8b7cf6", shape: "circle", text: "better entry $" + Number(trade.better_entry.price).toFixed(2) });
  }
  if (trade.better_exit && trade.better_exit.price) {
    markers.push({ time: exitUnix, position: "aboveBar", color: "#ec6cad", shape: "circle", text: "better exit $" + Number(trade.better_exit.price).toFixed(2) });
  }
  markers.sort(function(a,b){ return a.time - b.time; });
  candleSeries.setMarkers(markers);
  chart.timeScale().fitContent();
  window.addEventListener("resize", function(){ chart.applyOptions({ width: el.clientWidth }); });
})();
</script>`
      : "";

    return pageShell({ title: `${trade.symbol} ${win ? "win" : "loss"} — trade.log`, headExtra, bodyHtml, scriptExtra });
  }

  // ---- filtered set -----------------------------------------------------

  // Small inline SVG equity-curve sparkline (no chart library dependency,
  // so the multi-trade export works completely offline, unlike the
  // single-trade page which needs the lightweight-charts CDN for its
  // candlesticks).
  function equitySvg(points) {
    if (points.length < 2) return "";
    const w = 860, h = 140, pad = 6;
    const ys = points.map((p) => p.cum);
    const min = Math.min(0, ...ys), max = Math.max(0, ...ys);
    const range = max - min || 1;
    const x = (i) => pad + (i / (points.length - 1)) * (w - pad * 2);
    const y = (v) => h - pad - ((v - min) / range) * (h - pad * 2);
    const zeroY = y(0);
    const path = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(p.cum).toFixed(1)}`).join(" ");
    const last = points[points.length - 1].cum;
    const stroke = last >= 0 ? "#2fd08a" : "#f2555a";
    return `<svg class="equity-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
      <line x1="0" y1="${zeroY.toFixed(1)}" x2="${w}" y2="${zeroY.toFixed(1)}" stroke="#262a34" stroke-width="1"/>
      <path d="${path}" fill="none" stroke="${stroke}" stroke-width="2"/>
    </svg>`;
  }

  function buildSetSharePage(trades, opts) {
    opts = opts || {};
    const title = opts.title || `${trades.length} trade${trades.length === 1 ? "" : "s"} — trade.log`;
    const filtersSummary = opts.filtersSummary || "";

    const netPnl = trades.reduce((s, r) => s + (Number(r.pnl_after_comm) || 0), 0);
    const wins = trades.filter((r) => r.win);
    const losses = trades.filter((r) => !r.win);
    const winRate = trades.length ? (wins.length / trades.length) * 100 : 0;
    const avgWin = wins.length ? wins.reduce((s, r) => s + (Number(r.pnl_after_comm) || 0), 0) / wins.length : 0;
    const avgLoss = losses.length ? losses.reduce((s, r) => s + (Number(r.pnl_after_comm) || 0), 0) / losses.length : 0;

    // Cumulative P&L for just this filtered set, in chronological order --
    // deliberately recomputed rather than reusing each row's `equity_after`
    // (that field is the running account balance across ALL trades, which
    // would be misleading to show as "the curve for this subset").
    const chrono = trades.slice().sort((a, b) => (a.trade_date + (a.entry_time || "")).localeCompare(b.trade_date + (b.entry_time || "")));
    let cum = 0;
    const curvePoints = chrono.map((r) => { cum += Number(r.pnl_after_comm) || 0; return { cum, row: r }; });

    const sorted = trades.slice().sort((a, b) => (b.trade_date + (b.entry_time || "")).localeCompare(a.trade_date + (a.entry_time || "")));

    const bodyHtml = `
      <h1>${escapeHtml(title)}</h1>
      ${filtersSummary ? `<div class="filters-summary">${escapeHtml(filtersSummary)}</div>` : ""}

      <div class="stat-row">
        <div class="cell"><div class="label">Net P&amp;L</div><div class="value ${netPnl >= 0 ? "up" : "down"}">${fmtMoney(netPnl)}</div></div>
        <div class="cell"><div class="label">Win rate</div><div class="value">${fmtPct(winRate)}</div></div>
        <div class="cell"><div class="label">Avg win</div><div class="value up">${wins.length ? fmtMoney(avgWin) : "—"}</div></div>
        <div class="cell"><div class="label">Avg loss</div><div class="value down">${losses.length ? fmtMoney(avgLoss) : "—"}</div></div>
      </div>

      ${curvePoints.length > 1 ? `<div class="card"><h2>Cumulative P&amp;L (this set, chronological)</h2>${equitySvg(curvePoints)}</div>` : ""}

      <div class="card" style="padding:0;">
        <div style="padding:14px 18px 0;"><h2 style="margin:0;">${trades.length} trade${trades.length === 1 ? "" : "s"}</h2></div>
        <div style="overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>Date</th><th>Symbol</th><th>Setup</th><th>Flags</th><th>Clean</th><th>Entry</th><th>Exit</th><th>Net P&amp;L</th><th>R</th><th>Result</th></tr></thead>
          <tbody>
            ${sorted.map((r) => {
              const je = journalFor(r);
              const m = journalMetrics(r, je);
              return `
              <tr>
                <td>${escapeHtml(r.trade_date)}</td>
                <td>${escapeHtml(r.symbol)}</td>
                <td>${escapeHtml((r.setup_type || "—").toString().replace(/_/g, " "))}</td>
                <td>${escapeHtml(flagsOf(r).join(", ") || "—")}</td>
                <td>${cleanOf(r) === true ? "yes" : cleanOf(r) === false ? '<span class="down">no</span>' : "—"}</td>
                <td>$${Number(r.entry_price).toFixed(2)}</td>
                <td>$${Number(r.exit_price).toFixed(2)}</td>
                <td class="${r.pnl_after_comm >= 0 ? "up" : "down"}">${fmtMoney(r.pnl_after_comm)}</td>
                <td>${m ? fmtR(m.r_multiple) : "—"}</td>
                <td><span class="pill ${r.win ? "win" : "loss"}">${r.win ? "WIN" : "LOSS"}</span></td>
              </tr>`; }).join("")}
          </tbody>
        </table>
        </div>
      </div>

      <div class="footer-note">Static snapshot of ${trades.length} filtered trade${trades.length === 1 ? "" : "s"}, exported from trade.log on ${nowStamp()}. Fully self-contained — no data files or internet connection required to view it.</div>
    `;

    return pageShell({ title, bodyHtml });
  }

  // ---- download ----------------------------------------------------------

  function download(filename, htmlString) {
    const blob = new Blob([htmlString], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function slug(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  }

  return { buildTradeSharePage, buildSetSharePage, download, slug };
})();
