// escapeHtml()/fmtMoney() moved to utils.js, which now loads first on
// every page (before config.js) -- that fixes the load-order problem
// that kept them stuck here as a copy no other page could safely call
// yet. See utils.js for the canonical forms and what drifted.

// chat-widget.js — floating "AI Chat" launcher, shared by every app-shell
// page. Used to be its own sidebar tab pointing at chat.html; now it's a
// small popup like most normal sites' chat widgets, with a maximize
// button for a bigger view. Injects the launcher button + panel markup
// into the page, then loads chat.js (unmodified) against it -- chat.js
// only ever touches elements by id (#chat-messages, #chat-form, etc.),
// so it works identically whether those ids live on a full page or in
// this floating panel.
(function () {
  "use strict";

  // Login page has no trade data and no sidebar/topbar chrome -- skip.
  if (/\/login(\.html)?\/?$/.test(window.location.pathname)) return;
  if (!document.getElementById("sidebar")) return;

  const OPEN_KEY = "trade.log:chatWidgetOpen";

  const launcher = document.createElement("button");
  launcher.type = "button";
  launcher.id = "chatw-launcher";
  launcher.className = "chatw-launcher";
  launcher.title = "AI Chat";
  launcher.setAttribute("aria-label", "Open AI chat");
  launcher.innerHTML = `
    <svg class="chatw-icon-chat" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
    <svg class="chatw-icon-close" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
  `;

  const panel = document.createElement("div");
  panel.id = "chatw-panel";
  panel.className = "chatw-panel";
  panel.innerHTML = `
    <div class="chatw-panel-head">
      <span class="chatw-head-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l1.9 5.8L20 10l-6.1 2.2L12 18l-1.9-5.8L4 10l6.1-2.2z"></path></svg></span>
      <span class="chatw-panel-title">AI Chat</span>
      <span class="chatw-panel-actions">
        <button type="button" class="chatw-icon-action" id="chatw-hints-btn" title="Suggested questions" aria-label="Show suggested questions" aria-pressed="false">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"></path><path d="M10 22h4"></path><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2.05V17h6v-.25c0-.85.4-1.55 1-2.05A7 7 0 0 0 12 2z"></path></svg>
        </button>
        <button type="button" class="chatw-icon-action" id="chatw-maximize-btn" title="Maximize" aria-label="Maximize chat">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"></path><path d="M21 8V5a2 2 0 0 0-2-2h-3"></path><path d="M3 16v3a2 2 0 0 0 2 2h3"></path><path d="M16 21h3a2 2 0 0 0 2-2v-3"></path></svg>
        </button>
        <button type="button" class="chatw-icon-action" id="chatw-close-btn" title="Close" aria-label="Close chat">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </span>
    </div>
    <div class="chatw-body chat-content">
      <div class="chat-shell">
        <div class="chat-data-status" id="chat-data-status">
          <span class="chat-data-status-dot"></span> Loading your trade data…
        </div>
        <div class="chat-messages" id="chat-messages"></div>
        <div class="chat-chips" id="chat-chips"></div>
        <form class="chat-input-row" id="chat-form">
          <input
            type="text"
            id="chat-input"
            class="chat-input"
            placeholder="Ask about a trade, setup, or your stats…"
            autocomplete="off"
            disabled
          >
          <button type="submit" class="chat-send-btn" id="chat-send-btn" disabled>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
          </button>
        </form>
      </div>
    </div>
  `;

  document.body.appendChild(panel);
  document.body.appendChild(launcher);

  function setOpen(open) {
    panel.classList.toggle("open", open);
    launcher.classList.toggle("open", open);
    if (!open) {
      // Reset maximize state on close so the launcher (hidden while
      // maximized, see below) always comes back once the panel isn't
      // covering it anymore, and the panel reopens at its normal size.
      panel.classList.remove("maximized");
      launcher.classList.remove("chatw-launcher-hidden");
    }
    try { sessionStorage.setItem(OPEN_KEY, open ? "1" : "0"); } catch (e) { /* ignore */ }
  }

  launcher.addEventListener("click", () => setOpen(!panel.classList.contains("open")));
  document.getElementById("chatw-close-btn").addEventListener("click", () => setOpen(false));
  document.getElementById("chatw-maximize-btn").addEventListener("click", (e) => {
    const isMax = panel.classList.toggle("maximized");
    // The round launcher button sits fixed at bottom-right in every
    // state, but the maximized panel's own bottom-right corner grows
    // to almost the same spot -- without this it sat directly on top
    // of the input row/send button. The header already has its own
    // close button, so just hide the redundant launcher while maximized.
    launcher.classList.toggle("chatw-launcher-hidden", isMax);
    e.currentTarget.title = isMax ? "Restore" : "Maximize";
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && panel.classList.contains("open")) setOpen(false);
  });

  // Reopen automatically if the person had it open before navigating to
  // this page -- conversation history itself is per-page-load (same as
  // the old chat.html always was), only the open/closed state persists.
  let startOpen = false;
  try { startOpen = sessionStorage.getItem(OPEN_KEY) === "1"; } catch (e) { /* ignore */ }
  if (startOpen) setOpen(true);

  // chat.js expects #chat-messages/#chat-form/etc. to already exist (it
  // looks them up as soon as it runs, not on DOMContentLoaded), so it's
  // only loaded now that the panel markup above is in the DOM.
  const chatScript = document.createElement("script");
  chatScript.src = "js/chat.js";
  document.body.appendChild(chatScript);
})();


// theme-toggle.js — light/dark switch, shared by every app-shell page.
// The actual theme is applied as early as possible by a tiny inline
// script at the very top of each page's <head> (reads THEME_KEY and
// sets data-theme="light" on <html> before css/common.css's light-
// theme block ever gets matched against the DOM, so there's no flash
// of the wrong theme on load) -- this file just renders the button
// that changes it and keeps the status-bar color (meta theme-color)
// and other pages' tabs in sync.
//
// Switching reloads the page rather than live-patching every color in
// place: several charts on this site (the candlestick chart, MACD,
// equity curve) hand raw hex colors to a canvas-based charting library
// at creation time, not CSS custom properties a stylesheet swap would
// reach, so a reload is what actually guarantees every chart, gradient
// and inline style on the page reflects the new theme correctly,
// instead of some of them silently staying dark. A toggle is
// infrequent enough that this is a fine trade.
(function () {
  "use strict";
  const THEME_KEY = "trade.log:theme";
  const topbarRight = document.querySelector(".topbar-right");
  if (!topbarRight || document.getElementById("mobile-nav-btn") === null) return;

  function currentTheme() {
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  }
  // Every page's <meta name="theme-color"> is hardcoded to the dark
  // --bg value in its <head> (the inline early-theme script runs
  // before that tag exists, so it can't fix this up itself) -- true it
  // up here instead, once common.js runs. Mobile browsers use this to
  // tint the address bar/status bar, so left dark it would visually
  // clash with a light page.
  function syncMetaThemeColor() {
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", currentTheme() === "light" ? "#f5f6f9" : "#0a0b0f");
  }
  syncMetaThemeColor();

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "icon-btn icon-btn-visible theme-toggle-btn";
  btn.id = "theme-toggle-btn";
  btn.title = "Switch to light theme";
  btn.setAttribute("aria-label", "Switch to light theme");
  btn.innerHTML = `
    <svg class="theme-icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4.2"></circle><line x1="12" y1="2.5" x2="12" y2="5"></line><line x1="12" y1="19" x2="12" y2="21.5"></line><line x1="4.2" y1="4.2" x2="6" y2="6"></line><line x1="18" y1="18" x2="19.8" y2="19.8"></line><line x1="2.5" y1="12" x2="5" y2="12"></line><line x1="19" y1="12" x2="21.5" y2="12"></line><line x1="4.2" y1="19.8" x2="6" y2="18"></line><line x1="18" y1="6" x2="19.8" y2="4.2"></line></svg>
    <svg class="theme-icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 14.2A8.5 8.5 0 1 1 9.8 3.5a7 7 0 0 0 10.7 10.7z"></path></svg>
  `;
  topbarRight.insertBefore(btn, document.getElementById("mobile-nav-btn"));

  function updateTitle() {
    const next = currentTheme() === "light" ? "dark" : "light";
    btn.title = `Switch to ${next} theme`;
    btn.setAttribute("aria-label", `Switch to ${next} theme`);
  }
  updateTitle();

  btn.addEventListener("click", () => {
    const next = currentTheme() === "light" ? "dark" : "light";
    try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* ignore -- toggle just won't persist */ }
    location.reload();
  });
})();

// nav.js — shared sidebar/mobile-nav wiring for every page, plus a
// shared URL-state helper (see NavState below).
//
// Every page ships the same app-shell sidebar (#sidebar), a desktop
// collapse toggle (#sidebar-toggle), and a mobile hamburger button
// (#mobile-nav-btn) in the topbar. This used to be ~20 lines of
// identical inline <script> duplicated across nine pages, and three
// more pages (practice.html, quiz.html, rewind.html) shipped the
// hamburger button with no wiring at all, so tapping it did nothing.
// This file is the single implementation, loaded by every page.

// ---------------------------------------------------------------------
// NavState — mirrors a page's in-memory UI state (which month/day is
// open, which filters/sort/tab are active, how many rows are shown,
// ...) into that page's own query string, instead of only living in a
// JS variable.
//
// Every page here is a full navigation, not an SPA route -- clicking a
// trade opens trade.html as a real new document, and hitting Back
// reloads THIS page fresh, re-running all its JS from scratch. Any
// state that only ever lived in a `let` variable is gone at that
// point; the page falls back to whatever its hardcoded defaults are
// (today's month, no filters, first page of rows, ...) instead of
// where the person actually was. That's the "back button forgets
// where I was" bug.
//
// The fix: whenever that state changes, write it into the URL with
// history.replaceState (so browsing around doesn't pile up new
// history entries -- there's still exactly one entry for this page,
// it just keeps getting its query string updated). Back navigation
// then reloads this exact URL, and reading the same query string back
// out on boot puts the page back where it was.
window.NavState = (function () {
  "use strict";

  function readParams() {
    return new URLSearchParams(window.location.search);
  }

  // Reads one field back out of the URL. Always returns a string (or
  // `fallback`) -- callers are responsible for parsing numbers/JSON/etc.
  function get(key, fallback) {
    const v = readParams().get(key);
    return v === null ? fallback : v;
  }

  // Merges `updates` into the current query string and replaces the
  // current history entry with the result (hash is left untouched, so
  // this plays nicely with pages like index.html that use the hash for
  // which tab is active). A value of null/undefined/"" removes that key
  // instead of writing it, so optional/default state doesn't clutter
  // every URL.
  function set(updates) {
    const params = readParams();
    Object.keys(updates).forEach((k) => {
      const v = updates[k];
      if (v === null || v === undefined || v === "") params.delete(k);
      else params.set(k, String(v));
    });
    const qs = params.toString();
    const url = window.location.pathname + (qs ? "?" + qs : "") + window.location.hash;
    history.replaceState(history.state, "", url);
  }

  return { get, set };
})();

// Sidebar nav rendering (the Journal/More link lists + active-page
// highlight) used to live here, but ran too late -- see js/nav-render.js,
// which now loads right after the sidebar markup on each page instead of
// at the bottom with the rest of this file.


(function () {
  const sidebar = document.getElementById("sidebar");
  const sidebarToggle = document.getElementById("sidebar-toggle");
  if (!sidebar) return; // page doesn't use the app-shell sidebar

  // Every page is a separate load (this isn't an SPA), so without this
  // the collapsed/expanded choice was thrown away and reset to expanded
  // on every single click into a new page -- that's the "collapse
  // never sticks" bug. Applied synchronously, before anything else runs,
  // so the sidebar never flashes expanded-then-collapsed on load.
  const COLLAPSE_KEY = "sidebar-collapsed";
  try {
    if (localStorage.getItem(COLLAPSE_KEY) === "1") {
      sidebar.classList.add("collapsed");
    }
  } catch (e) {
    // localStorage unavailable (private browsing, etc.) -- collapse
    // just won't persist across pages; the toggle itself still works.
  }

  const sidebarBackdrop = document.createElement("div");
  sidebarBackdrop.className = "sidebar-backdrop";
  document.body.appendChild(sidebarBackdrop);

  function closeMobileNav() {
    sidebar.classList.remove("mobile-open");
  }

  sidebarBackdrop.addEventListener("click", closeMobileNav);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMobileNav();
  });

  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      if (window.innerWidth <= 760 && sidebar.classList.contains("mobile-open")) {
        closeMobileNav();
      } else {
        sidebar.classList.toggle("collapsed");
        try {
          localStorage.setItem(COLLAPSE_KEY, sidebar.classList.contains("collapsed") ? "1" : "0");
        } catch (e) {
          // ignore -- see comment above
        }
      }
    });
  }

  // Delegated on document (not bound directly to mobileNavBtn) so it
  // keeps working even if the SPA router (js/page-transition.js) ever
  // swaps in a topbar that recreates this button -- a direct binding
  // would go dead the moment its original element is replaced. Not
  // currently exercised (the router keeps the topbar itself out of
  // the swapped region), but costs nothing and removes a footgun for
  // whoever changes that later.
  document.addEventListener("click", (e) => {
    if (e.target.closest("#mobile-nav-btn")) {
      sidebar.classList.toggle("mobile-open");
    }
  });

  // Exposed so pages with their own tab-switching logic (index.html)
  // can close the mobile drawer on navigation without re-implementing it.
  window.closeMobileNav = closeMobileNav;

  // Touch swipe for the mobile drawer, so it behaves like any other
  // app's off-screen nav instead of only opening via the topbar button:
  // swipe right from the screen's left edge to open it, swipe left
  // anywhere on the open drawer (or its backdrop) to close it. Bound on
  // `document` (not just the sidebar) so the open-gesture works from
  // wherever the page currently is -- edgeStartMaxX keeps it from
  // hijacking an ordinary left-to-right drag/scroll started elsewhere
  // on the page.
  if (window.bindSwipe) {
    window.bindSwipe(document, {
      edgeStartMaxX: 24,
      onSwipeRight: () => { if (window.innerWidth <= 760) sidebar.classList.add("mobile-open"); },
    });
    window.bindSwipe(sidebar, { onSwipeLeft: closeMobileNav });
    window.bindSwipe(sidebarBackdrop, { onSwipeLeft: closeMobileNav });
  }
})();


/* modern.js — additive interactivity layer.
 * Safe by design: only ever *adds* classes/listeners to elements
 * that already exist. Never touches app.js/trade.js/etc. state. */
(function () {
  'use strict';
  var reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- 1. Scroll-reveal for panels/cards ---------- */
  function initReveal() {
    if (reduced || !('IntersectionObserver' in window)) return;
    var targets = document.querySelectorAll(
      '.panel-box, .card, .chart-panel, .equity-panel, .day-group, .playbook-card, .highlight-card, .dash-hero, .kpi-card'
    );
    if (!targets.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry, i) {
        if (entry.isIntersecting) {
          var el = entry.target;
          setTimeout(function () { el.classList.add('reveal-in'); }, Math.min(i * 40, 240));
          io.unobserve(el);
        }
      });
    }, { threshold: 0, rootMargin: '0px 0px -40px 0px' });
    targets.forEach(function (el) {
      if (el.dataset.revealBound) return; // boot() can run more than once
      el.dataset.revealBound = '1';
      // Elements that start (or are later toggled) display:none -- like
      // #bt-progress-box, hidden until a backtest starts -- report a 0x0
      // box here and can never satisfy the IntersectionObserver once
      // they're shown, since they aren't "scrolled into view" so much as
      // switched on by other JS. Binding them anyway meant they sat at
      // opacity:0 (from .reveal-init) until the 1800ms safety net caught
      // up -- so clicking "Run Backtest" soon after page load unhid an
      // invisible box, looking like the page had emptied out. Skip
      // reveal-on-scroll for anything not actually laid out right now;
      // it'll just render normally (opacity:1) whenever it's shown.
      if (getComputedStyle(el).display === 'none') return;
      // Tall content (e.g. a 300+ row table inside a panel) can be so much
      // taller than the viewport that it never satisfies an area-based
      // threshold. Only defer elements short enough to plausibly start
      // off-screen; anything else just reveals immediately.
      if (el.getBoundingClientRect().height > window.innerHeight * 1.2) return;
      el.classList.add('reveal-init');
      io.observe(el);
    });
    // Safety net: never leave anything stuck invisible (e.g. content that
    // grows taller than the viewport only after app.js populates it async).
    setTimeout(function () {
      document.querySelectorAll('.reveal-init:not(.reveal-in)').forEach(function (el) {
        el.classList.add('reveal-in');
      });
    }, 1800);
  }

  /* ---------- 2. Ripple on click for buttons ---------- */
  var rippleBound = false;
  function initRipple() {
    if (reduced || rippleBound) return;
    // Delegated on document, so it already covers any element matching
    // the selector that exists NOW or is added later (e.g. by the SPA
    // router swapping in a new page's buttons) -- bind it once, ever.
    // boot() (below) can run more than once (see initReveal's comment),
    // and re-adding this same delegated listener on every call would
    // stack duplicates, firing the ripple effect multiple times per click.
    rippleBound = true;
    // Selector originally covered every clickable control except a
    // handful of "tab" families that happened to ship later
    // (subtab-btn, pr-view-tab, tf-btn, pp-size-mode-btn, calc-chip,
    // chatw-icon-action) -- so pressing those didn't ripple while
    // near-identical toggle buttons elsewhere (toptab-btn, nav-item,
    // quiz-mode-btn) did. Added below so every "press one of these to
    // switch view/mode" control behaves the same everywhere.
    // (qz-move-stop-btn isn't listed separately -- it already matches
    // via its own .btn-advanced class.)
    var selector = '.filter-btn, .icon-btn, .cal-nav-btn, .sidebar-toggle, .nav-item, .btn-advanced, .btn-confirm, .btn-danger, .btn-icon, .sr-run-btn, .toptab-btn, .pp-order-btn, .quiz-answer-btn, .quiz-mode-btn, .quiz-preset-btn, .qz-speed-btn, .quiz-speed-btn, .subtab-btn, .pr-view-tab, .tf-btn, .pp-size-mode-btn, .calc-chip, .chatw-icon-action';
    document.addEventListener('click', function (e) {
      var el = e.target.closest(selector);
      if (!el) return;
      var rect = el.getBoundingClientRect();
      var x = e.clientX - rect.left;
      var y = e.clientY - rect.top;
      // Radius reaches the button's farthest corner from the click point.
      // Using rect.width/height directly (the old approach) blew the
      // ripple way past the button on wide, short controls like the
      // report tab bar -- the circle ballooned way beyond the button.
      var radius = Math.sqrt(Math.pow(Math.max(x, rect.width - x), 2) + Math.pow(Math.max(y, rect.height - y), 2));
      var size = radius * 2;
      var span = document.createElement('span');
      span.className = 'ripple';
      span.style.width = span.style.height = size + 'px';
      span.style.left = (x - radius) + 'px';
      span.style.top = (y - radius) + 'px';
      // Both of these are only ever SET here, temporarily, to contain the
      // ripple circle -- never restored, until now. That was silently
      // breaking flex layouts: a flex item's automatic minimum width is
      // its content width (it won't shrink below its own text) ONLY while
      // overflow stays 'visible'. The moment overflow becomes 'hidden',
      // that floor drops to 0, so any flex container short on space
      // (a horizontally-scrolling tab strip on a phone, e.g. the Reports
      // top tabs, being the tightest case) is then free to squeeze the
      // clicked button down to nothing -- and since the style was never
      // undone, it stayed that way forever after the first tap. Restore
      // both once the ripple animation is done (and only once every
      // ripple on this element has finished, in case of a fast double
      // click) so the element goes back to its normal, protected sizing.
      var addedPosition = false, addedOverflow = false;
      var prevPos = getComputedStyle(el).position;
      if (prevPos === 'static') { el.style.position = 'relative'; addedPosition = true; }
      if (getComputedStyle(el).overflow === 'visible') { el.style.overflow = 'hidden'; addedOverflow = true; }
      el.appendChild(span);
      span.addEventListener('animationend', function () {
        span.remove();
        if (!el.querySelector('.ripple')) {
          if (addedOverflow) el.style.overflow = '';
          if (addedPosition) el.style.position = '';
        }
      });
    }, true);
  }

  /* ---------- 3. Flash numeric values when app.js updates them ---------- */
  function initValueFlash() {
    if (reduced || !('MutationObserver' in window)) return;
    var selector = '.stat .value, .pnl-breakdown .cell .value, .streak-strip .cell .value, ' +
      '.cal-summary-strip .cell .value, .equity-head .value, .score-gauge .num, .pb-value';
    var seen = new WeakMap();
    var mo = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        var el = m.target.nodeType === 3 ? m.target.parentElement : m.target;
        if (!el || !el.matches || !el.matches(selector)) return;
        var text = el.textContent;
        if (seen.get(el) === text) return;
        seen.set(el, text);
        el.classList.remove('value-settled');
        void el.offsetWidth;
        el.classList.add('value-settled');
      });
    });
    document.querySelectorAll(selector).forEach(function (el) {
      seen.set(el, el.textContent);
      mo.observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  /* ---------- 4. Subtle magnetic tilt on stat cards (desktop only) ---------- */
  function initTilt() {
    if (reduced || window.matchMedia('(pointer: coarse)').matches) return;
    document.querySelectorAll('.stat, .highlight-card').forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        var r = card.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5;
        var y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = 'perspective(600px) rotateX(' + (-y * 3) + 'deg) rotateY(' + (x * 3) + 'deg)';
      });
      card.addEventListener('mouseleave', function () { card.style.transform = ''; });
    });
  }

  function boot() {
    initReveal();
    initRipple();
    initValueFlash();
    initTilt();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Exposed for the SPA router to call after swapping in new content --
  // re-applies scroll-reveal/value-flash/tilt to the freshly-added
  // elements. initRipple() is a no-op past its first call (see above).
  window.__rebootDecor = boot;

  /* Re-run reveal/tilt hookup after tab switches or late DOM insertions
     (app.js renders dashboard content async on load). */
  window.addEventListener('load', function () {
    setTimeout(boot, 250);
  });
})();

// ---------------------------------------------------------------------
// Hover-prefetch for sidebar navigation. Every nav-item is a real
// full-page link (journal.html, stats.html, etc.), so the biggest part
// of the "loading" feeling on navigation is just network wait for the
// next document. Warming the browser's cache for a link as soon as the
// pointer lands on it (people reliably pause on a link for a beat
// before clicking) means that by the time the click actually happens,
// the page is often already cached -- so the loading screen in
// common.css barely has anything left to cover, and the switch reads
// as instant, without changing how any page loads or is built.
(function () {
  "use strict";
  var done = Object.create(null);
  function prefetch(url) {
    if (!url || done[url]) return;
    done[url] = true;
    var link = document.createElement("link");
    link.rel = "prefetch";
    link.href = url;
    document.head.appendChild(link);
  }
  document.addEventListener("pointerenter", function (e) {
    var a = e.target.closest && e.target.closest(".nav-item[href], .sidebar a[href]");
    if (!a) return;
    var href = a.getAttribute("href");
    if (href && !/^(https?:)?\/\//.test(href) && href.indexOf("#") !== 0) prefetch(href);
  }, true);
})();

// ================================================================
// SETUP/TAG STYLING (shared by journal, trade detail, patterns,
// practice, rewind -- anywhere a setup_type or lesson tag is shown).
// Every tag renders in the same single accent color (the app's
// primary/brand color) instead of a different hue per tag -- a
// calmer, more professional look than a rainbow of per-tag colors.
(function () {
  "use strict";
  window.setupTagStyle = function () {
    return {
      bg: "var(--primary-soft)",
      border: "rgba(139,124,246,0.3)",
      fg: "var(--primary)",
    };
  };
  // Inline style-attribute shorthand for a colored pill: background +
  // border + text all in the shared accent color.
  window.setupTagStyleAttr = function () {
    var c = window.setupTagStyle();
    return "background:" + c.bg + ";border-color:" + c.border + ";color:" + c.fg + ";";
  };
  // Just a small dot, for places already showing the label as plain
  // text (table rows, breakdown lists) where a full recolored pill
  // would be too heavy.
  window.setupTagDot = function () {
    var c = window.setupTagStyle();
    return '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:' + c.fg + ';margin-right:6px;vertical-align:middle;"></span>';
  };
})();
