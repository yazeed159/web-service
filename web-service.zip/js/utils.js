// utils.js — shared formatting/escaping helpers, exposed on `window`.
// Loaded first on every page (before config.js) specifically so that
// page scripts can call these from their own synchronous top-level
// render path without a load-order ReferenceError, which is what kept
// this consolidation from happening earlier (see the removed note in
// common.js). Previously hand-duplicated per file:
//   escapeHtml   - 20 copies across .js/.html
//   fmtMoney     - 10 copies across .js/.html
//   toUnix       - 8 copies across .js
//   fmtShares    - 3 copies across .js
//   prettifyTag  - 1 copy (app.js only, centralized anyway)
// Each canonical form below was picked as the safest/most common
// existing behavior, not an arbitrary new one -- see comments per
// function for what drifted and why.

// Re-runs `fn` when the tab regains visibility, if it's been at least
// `minIntervalMs` (default 30s) since the last run -- so a read-only
// data page (Dashboard, Edge Analysis, Practice Analytics) that's just
// sitting open in a background tab picks up trades that landed while
// you were away, instead of showing stale numbers until a manual
// refresh. Deliberately opt-in per page rather than global: pages with
// live in-progress state (an open chat, a practice quiz, a backtest
// job, calculator inputs) would have that state clobbered by a re-fetch
// firing underneath them, so this is only wired into pages that purely
// display trade data with nothing to lose by re-rendering.
// `opts.signal`: pass the page's own teardown AbortController signal
// (e.g. app-shared.js's `App.signal`) on any page whose script re-runs
// on SPA navigation -- otherwise each re-run stacks one more listener
// on `document` that outlives the DOM it was meant for.
window.refreshOnFocus = function refreshOnFocus(fn, opts) {
  opts = opts || {};
  const minInterval = opts.minIntervalMs || 30000;
  let last = Date.now();
  const listenerOpts = opts.signal ? { signal: opts.signal } : undefined;
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible") return;
    if (Date.now() - last < minInterval) return;
    last = Date.now();
    fn();
  }, listenerOpts);
};

// Lightweight, non-blocking toast -- for background-failure notices
// (KV.set()/KV.delete() failing silently in auth.js, where the UI
// already updated optimistically before the network call even
// started) where UIModal.alert()'s blocking dialog would be wrong:
// nothing the user clicked triggered this, so it shouldn't demand a
// click to dismiss. Lives here (not common.js) so it's defined before
// auth.js runs, same reasoning as every other helper in this file.
// Multiple toasts stack; each auto-dismisses unless hovered.
//
// opts.action: { label, onClick } -- renders a button inside the toast
// (e.g. "Undo"). Clicking it dismisses immediately and fires onClick;
// letting the toast run out on its own instead fires opts.onExpire.
// This is what backs the delete-with-undo pattern (see bulkDelete() in
// journal.html / the capital-ledger + preset delete handlers in
// settings.html and journal.html): the row disappears from the UI
// right away, but the actual server delete is deferred until the toast
// expires, so "Undo" can cancel it outright instead of re-inserting
// the row after the fact. Trade-off worth knowing: if the tab closes
// or navigates away before the toast expires, onExpire never fires and
// the delete never reaches the server -- the row will reappear next
// load. Fine for a soft-delete UX (worst case the user deletes it
// again); not appropriate for anything that must reliably happen.
window.showToast = function showToast(message, opts) {
  opts = opts || {};
  const tone = opts.tone || "default";
  const duration = opts.duration || (opts.action ? 6000 : 5000);
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  const el = document.createElement("div");
  el.className = "toast" + (tone === "error" ? " error" : "");
  el.setAttribute("role", tone === "error" ? "alert" : "status");

  const textEl = document.createElement("span");
  textEl.className = "toast-text";
  textEl.textContent = message;
  el.appendChild(textEl);

  if (opts.action && opts.action.label) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "toast-action";
    btn.textContent = opts.action.label;
    btn.addEventListener("click", () => {
      clearTimeout(timer);
      expired = false;
      dismiss();
      if (opts.action.onClick) opts.action.onClick();
    });
    el.appendChild(btn);
  }

  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  let expired = false;
  let timer = setTimeout(() => { expired = true; dismiss(); }, duration);
  el.addEventListener("mouseenter", () => clearTimeout(timer));
  el.addEventListener("mouseleave", () => { timer = setTimeout(() => { expired = true; dismiss(); }, duration); });
  function dismiss() {
    el.classList.remove("show");
    setTimeout(() => {
      el.remove();
      if (expired && opts.onExpire) opts.onExpire();
    }, 200);
  }
  return { dismiss: () => { clearTimeout(timer); expired = false; dismiss(); } };
};

// Small shared helpers for inline (as-you-type / on-blur) form
// validation, replacing the old pattern of only discovering a bad
// field when submit already failed (silently refocusing it, or
// popping a blocking alert). Renders one message under the field the
// first time it's called, and toggles an invalid outline on the input
// itself; setFieldError("") / clearFieldError() both clear it.
window.setFieldError = function setFieldError(inputEl, message) {
  if (!inputEl) return;
  let msgEl = inputEl.__fieldErrorEl;
  if (!msgEl) {
    msgEl = document.createElement("div");
    msgEl.className = "field-error-msg";
    inputEl.insertAdjacentElement("afterend", msgEl);
    inputEl.__fieldErrorEl = msgEl;
  }
  if (message) {
    msgEl.textContent = message;
    msgEl.style.display = "block";
    inputEl.classList.add("field-invalid");
    inputEl.setAttribute("aria-invalid", "true");
  } else {
    msgEl.textContent = "";
    msgEl.style.display = "none";
    inputEl.classList.remove("field-invalid");
    inputEl.removeAttribute("aria-invalid");
  }
};
window.clearFieldError = function clearFieldError(inputEl) {
  window.setFieldError(inputEl, "");
};

// Canonical form: null/undefined -> "" instead of the literal string
// "null"/"undefined". 20 of the 21 duplicate copies used bare
// String(s), which renders those literal words when a field is
// missing; only common.js/share-export.js/auth.js/ui-modal.js/
// import-trades.html already guarded against it.
window.escapeHtml = function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
};

// Canonical form: "+$1234.56" / "-$1234.56", no thousands separator (7
// of 10 duplicate copies already formatted it this way), "—" for
// anything that isn't a finite number rather than silently coercing to
// $0.00 or rendering the literal string "NaN". practice.js/
// practice-analytics.js previously added comma thousands-separators
// no other copy used (so the same P&L rendered as a visibly different
// string depending which page you were on); global-search.js/
// search.html previously returned "" instead of "—" for bad input.
// Both now match every other page.
window.fmtMoney = function fmtMoney(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return "—";
  return (n >= 0 ? "+$" : "-$") + Math.abs(n).toFixed(2);
};

// Canonical form: always 2 decimals, no "$" (callers prepend their own
// "$" at the render site -- 6 of 7 duplicate copies already did this,
// so this matches everywhere except scanner.js's old copy, which is
// updated to prepend "$" at its call sites instead). No "$5 cutoff"
// step-up to 4 decimals: 4 of 7 duplicate copies (practice.js,
// practice-analytics.js, quiz.js, rewind.js) used to switch to 4
// decimals under $5, which meant the same sub-$5 trade price rendered
// with a different number of decimals depending which page you were
// on (e.g. "2.35" on trade.js's chart overlay vs. "2.3456" on
// rewind.js) -- always-2-decimals removes that drift.
window.fmtPrice = function fmtPrice(v) {
  const n = Number(v);
  return v === null || v === undefined || !Number.isFinite(n) ? "—" : n.toFixed(2);
};

// Canonical form: String(t) first. 6 of 8 duplicate copies guarded with
// String(t) before .replace(), so a non-string `t` (e.g. a bar whose
// `t` came through as a Date or a raw number somewhere upstream)
// degrades to a parseable string instead of throwing. trade.js's own
// copy was the one missing this guard.
window.toUnix = function toUnix(t) {
  return Math.floor(new Date(String(t).replace(" ", "T") + "Z").getTime() / 1000);
};

// Canonical form: typeof v === "number" && isFinite(v) guard (only
// report.js's copy had both checks; live-trading.js/backtester.js accepted
// any typeof "number" including NaN, which would have rendered "NaN%";
// share-export.js went the other direction and coerced any non-number to 0,
// rendering "0.0%" instead of flagging it), "—" for anything invalid to
// match fmtMoney/fmtPrice above.
window.fmtPct = function fmtPct(v) {
  return typeof v === "number" && isFinite(v) ? v.toFixed(1) + "%" : "—";
};

// Canonical form: "—" for non-finite input (calculator.js's copy lacked
// this guard; its own call sites already isFinite()-checked before calling,
// so nothing broke, but the guard now lives in the function itself like
// every other formatter here), "en-US" locale explicitly rather than the
// browser default (calculator.js passed `undefined`) so the grouping/decimal
// format doesn't shift for a user with a different regional locale --
// matches practice.js/practice-analytics.js's copies.
window.fmtUsd = function fmtUsd(v) {
  if (!Number.isFinite(v)) return "—";
  return "$" + v.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

// IBKR's "Tiered" US stock commission schedule: $0.0035/share, with a
// $0.35 floor and a 1%-of-trade-value ceiling per order. Byte-identical
// across all 4 duplicate copies (practice.js, rewind.js, calculator.js,
// quiz.js) -- no behavioral drift, just quadruplicated, including the
// 3 constants it reads.
window.IBKR_PER_SHARE = 0.0035;
window.IBKR_MIN_PER_ORDER = 0.35;
window.IBKR_MAX_PCT_OF_TRADE_VALUE = 0.01;
window.ibkrTieredCommission = function ibkrTieredCommission(shares, price) {
  if (!(shares > 0) || !(price > 0)) return 0;
  const raw = shares * window.IBKR_PER_SHARE;
  const ceiling = shares * price * window.IBKR_MAX_PCT_OF_TRADE_VALUE;
  return Math.max(window.IBKR_MIN_PER_ORDER, Math.min(raw, ceiling));
};

// Canonical form: typeof v === "number" && isFinite(v) guard (report.js's
// copy had it; backtester.js's copy checked typeof only, so a NaN R-multiple
// would have rendered "NaNR" -- same drift class as fmtPct above). "—" for
// invalid input.
window.fmtR = function fmtR(v) {
  return typeof v === "number" && isFinite(v) ? v.toFixed(2) + "R" : "—";
};

// Canonical form: practice-analytics.js's copy special-cases sub-60-second
// durations as e.g. "45s"; app.js's copy had no such case and floored
// straight to "0m" for anything under a minute, silently discarding the
// value. Went with practice-analytics.js's version since it's strictly
// more informative and every existing caller passes a duration where "0m"
// vs "45s" is a real difference the reader would notice (session/trade
// durations, not always >= 1 minute).
window.fmtDuration = function fmtDuration(mins) {
  if (mins === null || mins === undefined || !Number.isFinite(mins)) return "—";
  const totalSec = Math.round(mins * 60);
  if (totalSec < 60) return totalSec + "s";
  const total = Math.round(mins);
  const h = Math.floor(total / 60), m = total % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
};

// Deterministic string-seeded PRNG (mulberry32-style). Byte-identical
// across all 3 duplicate copies (practice.js, rewind.js, quiz.js) -- no
// drift, just triplicated. Used to generate reproducible within-bar
// "second ticks" for replay/practice playback, so the same trade_date +
// symbol always replays identically.
window.seededRng = function seededRng(seedStr) {
  let h = 1779033703 ^ seedStr.length;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
};

// One-line delegate to window.ChartIndicators.teardownStandardChart,
// identical across all 3 duplicate copies (practice.js, rewind.js,
// quiz.js) -- kept as its own named function (rather than inlining the
// call at each site) since callers read more clearly as teardownChart(h).
window.teardownChart = function teardownChart(handle) {
  return window.ChartIndicators.teardownStandardChart(handle);
};

// Generates REPLAY_SECONDS deterministic within-bar "second ticks" for
// replay/practice playback, walking a handful of OHLC waypoints with
// small random jitter so a 1-minute bar has something to animate through
// second-by-second. Byte-identical between practice.js and quiz.js -- no
// drift, just duplicated. NOT consolidated from rewind.js's copy: that
// one is a deliberately different/upgraded algorithm (extra randomized
// midpoint waypoints, volume-relative jitter scaled by an avgVolume
// param, exponentially-smoothed noise instead of independent per-tick
// jitter) written specifically for rewind.js's playback feel -- merging
// it in would silently change practice.js/quiz.js's replay behavior, so
// it stays a 3rd, separate implementation in rewind.js itself.
window.REPLAY_SECONDS = 60; // one sub-tick per real second of the 1-min bar
window.genSecondTicks = function genSecondTicks(bar, prevClose, seed) {
  const n = window.REPLAY_SECONDS;
  const rng = window.seededRng(seed);
  const o = bar.o, h = bar.h, l = bar.l, c = bar.c;
  const start = Number.isFinite(prevClose) ? prevClose : o;
  const highFirst = rng() < 0.5;
  const waypoints = [
    { t: 0, p: start },
    { t: Math.round(n * 0.1), p: o },
    { t: Math.round(n * 0.42), p: highFirst ? h : l },
    { t: Math.round(n * 0.74), p: highFirst ? l : h },
    { t: n - 1, p: c },
  ];
  const range = Math.max(h - l, 0.0001);
  const jitterAmp = range * 0.07;
  const ticks = [];
  for (let s = 0; s < n; s++) {
    let a = waypoints[0], b = waypoints[waypoints.length - 1];
    for (let i = 0; i < waypoints.length - 1; i++) {
      if (s >= waypoints[i].t && s <= waypoints[i + 1].t) { a = waypoints[i]; b = waypoints[i + 1]; break; }
    }
    const span = Math.max(1, b.t - a.t);
    const frac = (s - a.t) / span;
    let price = a.p + (b.p - a.p) * frac;
    price += (rng() - 0.5) * 2 * jitterAmp;
    price = Math.min(h, Math.max(l, price));
    ticks.push(price);
  }
  ticks[n - 1] = c; // always land exactly on the bar's real close
  return ticks;
};

// Fetches (and sessionStorage-caches) a symbol's full trading-day bars
// from chart_service.py's /full-day-bars route. Byte-identical logic
// across all 3 duplicate copies (practice.js, trade.js, rewind.js) with
// one real difference: practice.js/trade.js built their own base URL
// inline from window.CHART_SERVICE_URL with no placeholder check, while
// rewind.js's copy went through its own local chartServiceBase() helper,
// which also rejects the literal unconfigured "YOUR-NGROK-SUBDOMAIN"
// placeholder (still a live path for anyone self-hosting chart_service.py
// behind a tunnel, per the start-tunnel scripts in this repo -- see
// backtester.js/report.js's own placeholder checks). practice.js/trade.js
// would instead let a placeholder URL reach fetch() and surface a raw
// network-error message instead of the friendly "CHART_SERVICE_URL isn't
// set in config.js yet." Canonical form below carries that guard for all
// 3 callers.
window.FULL_DAY_CACHE_PREFIX = "chartSvc:fullDay:";
window.chartServiceBase = function chartServiceBase() {
  const base = (window.CHART_SERVICE_URL || "").replace(/\/+$/, "");
  if (!base || base.includes("YOUR-NGROK-SUBDOMAIN")) return "";
  return base;
};
// Full-day bars are cached in localStorage (survives reloads, closing the tab and
// the installed app restarting), most-recent-first, capped at FULL_DAY_KEEP symbol-days
// so it can't eat the browser's storage quota; sessionStorage is the fallback if
// localStorage is unavailable. Having a symbol-day cached is also what makes a trade
// page open on the full day automatically (see trade.js) instead of the narrow window.
window.FULL_DAY_INDEX_KEY = "chartSvc:fullDay:index";
window.FULL_DAY_KEEP = 10;
function fullDayIndex() {
  try { const a = JSON.parse(localStorage.getItem(window.FULL_DAY_INDEX_KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; }
}
window.peekFullDayBars = function peekFullDayBars(symbol, tradeDate) {
  const cacheKey = window.FULL_DAY_CACHE_PREFIX + symbol + ":" + tradeDate;
  for (const store of ["localStorage", "sessionStorage"]) {
    try {
      const cached = window[store].getItem(cacheKey);
      if (cached) { const bars = JSON.parse(cached); if (Array.isArray(bars) && bars.length) return bars; }
    } catch (e) { /* unavailable / corrupt -- try the next one */ }
  }
  return null;
};
function saveFullDayBars(cacheKey, bars) {
  const json = JSON.stringify(bars);
  try {
    let idx = fullDayIndex().filter((k) => k !== cacheKey);
    idx.unshift(cacheKey);
    while (idx.length > window.FULL_DAY_KEEP) { try { localStorage.removeItem(idx.pop()); } catch (e) {} }
    for (let attempt = 0; attempt < 12; attempt++) {
      try {
        localStorage.setItem(cacheKey, json);
        localStorage.setItem(window.FULL_DAY_INDEX_KEY, JSON.stringify(idx));
        return;
      } catch (e) {
        // Quota: drop the oldest other entry and retry.
        const victim = idx.length > 1 ? idx.pop() : null;
        if (!victim || victim === cacheKey) break;
        try { localStorage.removeItem(victim); } catch (e2) {}
      }
    }
  } catch (e) { /* fall through */ }
  try { sessionStorage.setItem(cacheKey, json); } catch (e) { /* quota, etc -- fine, just skip caching */ }
}
window.fetchFullDayBars = function fetchFullDayBars(symbol, tradeDate) {
  const cacheKey = window.FULL_DAY_CACHE_PREFIX + symbol + ":" + tradeDate;
  const hit = window.peekFullDayBars(symbol, tradeDate);
  if (hit) return Promise.resolve(hit);
  const base = window.chartServiceBase();
  if (!base) return Promise.reject(new Error("CHART_SERVICE_URL isn't set in config.js"));
  return fetch(`${base}/full-day-bars`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "ngrok-skip-browser-warning": "true" },
    body: JSON.stringify({ symbol, trade_date: tradeDate }),
  })
    .then((r) => r.json().then((data) => {
      if (!r.ok) throw new Error(data.error || ("HTTP " + r.status));
      return data;
    }))
    .then((data) => {
      const bars = Array.isArray(data.bars) ? data.bars : [];
      if (bars.length) saveFullDayBars(cacheKey, bars);
      return bars;
    });
};

// Signed per-share P&L for a long or short. Identical between rewind.js
// and quiz.js -- no drift.
window.pnlPerShare = function pnlPerShare(entry, exit, side) {
  return side === "short" ? entry - exit : exit - entry;
};

// Grades whether entering (or skipping) a trade was the right call given
// how it actually played out. Canonical form includes quiz.js's `correct`
// boolean on each result (used for that page's scoring); rewind.js's copy
// lacked it, but rewind.js only ever reads `.label`/`.tone` off the
// result, never enumerates or serializes the whole object, so the extra
// field is inert there -- confirmed no drift beyond that one added field.
window.gradeEntry = function gradeEntry(win, entered) {
  if (entered && win) return { label: "Good call — this one was a real winner.", tone: "good", correct: true };
  if (entered && !win) return { label: "This one lost in real life too.", tone: "bad", correct: false };
  if (!entered && !win) return { label: "Good discipline — this one was a loser.", tone: "good", correct: true };
  return { label: "This one worked out — you'd have missed it.", tone: "warn", correct: false };
};

// Grades stop placement against the setup's own suggested stop (or, if
// none was logged, just reports the raw risk %). Identical between
// rewind.js and quiz.js -- no drift.
window.gradeStop = function gradeStop(side, entryPrice, stopPrice, suggestedStop) {
  const riskUser = side === "short" ? stopPrice - entryPrice : entryPrice - stopPrice;
  if (!(riskUser > 0)) return { label: "Stop was on the wrong side of your entry.", tone: "bad" };
  const sug = Number(suggestedStop);
  if (suggestedStop != null && Number.isFinite(sug)) {
    const riskSuggested = side === "short" ? sug - entryPrice : entryPrice - sug;
    if (riskSuggested > 0) {
      const ratio = riskUser / riskSuggested;
      if (ratio < 0.5) return { label: "Too tight — likely shaken out by normal noise.", tone: "bad" };
      if (ratio < 0.8) return { label: "A little tight versus the setup's stop.", tone: "warn" };
      if (ratio <= 1.3) return { label: "Well placed — close to the setup's stop.", tone: "good" };
      if (ratio <= 2.2) return { label: "A bit wide.", tone: "warn" };
      return { label: "Too wide — risking more than the setup called for.", tone: "bad" };
    }
  }
  const pct = (riskUser / entryPrice) * 100;
  return { label: `${pct.toFixed(1)}% risk — no AI stop logged on this trade to compare against.`, tone: "neutral" };
};

// Identical across all 3 duplicate copies (practice.js, scanner.js,
// trade.js) -- no behavioral drift here, just triplicated.
window.fmtShares = function fmtShares(n) {
  if (n === null || n === undefined) return null;
  const v = Number(n);
  if (!Number.isFinite(v)) return null;
  if (v >= 1e9) return (v / 1e9).toFixed(2) + "B";
  if (v >= 1e6) return (v / 1e6).toFixed(1) + "M";
  if (v >= 1e3) return (v / 1e3).toFixed(0) + "K";
  return String(v);
};

// Only ever defined in app.js, but centralized here so every page
// hand-rolling a setup_type/label cleanup doesn't grow its own copy.
window.prettifyTag = function prettifyTag(s) {
  return String(s).replace(/_/g, " ");
};

// ---- Trade breakdown list w/ "Load more" ----------------------------
// Used by app.js, edge-analysis.js, patterns.html, and stats.html for
// the same UI: click a leaderboard/breakdown row (by symbol, tag, day,
// etc.) to reveal the trades behind it as a <ul>, paged
// TRADE_LIST_PAGE_SIZE at a time rather than dumping hundreds of <li>s
// into the DOM at once. All four had byte-identical copies of
// tradeListItemHtml/tradeListMoreHtml/tradeListHtml/
// TRADE_LIST_PAGE_SIZE/tradeListState; bindTradeToggles was identical
// in 3 of the 4 (edge-analysis.js, stats.html, and patterns.html's own
// inlined version all follow a toggle-open-row with a
// data-load-more-driven "reveal next page" click, then re-sync the
// tag/uid into the URL) -- app.js's copy is the same shape minus the
// URL-sync step, which is why bindTradeToggles below takes that step
// as an optional onChange callback instead of assuming it.
window.TRADE_LIST_PAGE_SIZE = 25;
window.tradeListState = new Map(); // uid -> { rows, shown }

window.tradeListItemHtml = function tradeListItemHtml(r) {
  return `<li><a href="trade.html?id=${encodeURIComponent(r.id)}">${escapeHtml(r.symbol)} — ${escapeHtml(r.trade_date)} <span class="${r.win ? "up" : "down"}">${r.win ? "WIN" : "LOSS"}</span></a></li>`;
};

window.tradeListMoreHtml = function tradeListMoreHtml(uid, remaining) {
  return `<li class="tag-trade-list-more"><button type="button" class="btn-load-more" data-load-more="${uid}">Load more (${remaining} left)</button></li>`;
};

window.tradeListHtml = function tradeListHtml(rowsList, uid) {
  const sorted = rowsList.slice().sort((a, b) => (b.trade_date || "").localeCompare(a.trade_date || ""));
  const shown = Math.min(window.TRADE_LIST_PAGE_SIZE, sorted.length);
  window.tradeListState.set(uid, { rows: sorted, shown });
  const items = sorted.slice(0, shown).map(window.tradeListItemHtml).join("");
  const more = shown < sorted.length ? window.tradeListMoreHtml(uid, sorted.length - shown) : "";
  return `<ul class="tag-trade-list" id="${uid}">${items}${more}</ul>`;
};

// onChange(uid, isOpen), if given, fires after every click:
// - a toggle-open click passes isOpen as true/false (the row's new
//   open state), so a caller tracking its own "which uids are open"
//   Set (for URL round-tripping) can update it correctly -- it runs
//   after the toggle already happened, so reading classList inside
//   onChange would also work, but passing it avoids that lookup.
// - a load-more click passes isOpen as undefined, since it doesn't
//   change open/closed state, just reveals more rows.
// edge-analysis.js/stats.html/patterns.html all pass a callback that
// updates their own openUids/openTags Set and then calls their own
// syncUrlState; app.js's dashboard has no such state, so it omits
// onChange entirely.
window.bindTradeToggles = function bindTradeToggles(container, onChange) {
  container.querySelectorAll("[data-trade-toggle]").forEach((row) => {
    row.addEventListener("click", () => {
      const uid = row.getAttribute("data-trade-toggle");
      const list = document.getElementById(uid);
      const nowOpen = list ? list.classList.toggle("open") : undefined;
      if (onChange) onChange(uid, nowOpen);
    });
  });
  container.querySelectorAll("[data-load-more]").forEach((btn) => {
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const uid = btn.getAttribute("data-load-more");
      const state = window.tradeListState.get(uid);
      if (!state) return;
      const nextShown = Math.min(state.shown + window.TRADE_LIST_PAGE_SIZE, state.rows.length);
      const newItemsHtml = state.rows.slice(state.shown, nextShown).map(window.tradeListItemHtml).join("");
      state.shown = nextShown;
      const moreLi = btn.closest("li");
      moreLi.insertAdjacentHTML("beforebegin", newItemsHtml);
      if (state.shown < state.rows.length) {
        btn.textContent = `Load more (${state.rows.length - state.shown} left)`;
      } else {
        moreLi.remove();
      }
      if (onChange) onChange(uid);
    });
  });
};

// Lightweight single-touch swipe helper -- shared by anywhere a page wants
// "swipe left/right" (calendar month nav, an off-screen drawer) without
// pulling in a gesture library for one thing. Tracks one active touch,
// and ignores drags that are mostly vertical (so it never fights the
// page's own scrolling) or too short to be a deliberate swipe.
window.bindSwipe = function bindSwipe(el, opts) {
  opts = opts || {};
  const threshold = opts.threshold || 45; // px of horizontal travel to count as a swipe
  let startX = 0, startY = 0, tracking = false;
  const listenerOpts = { passive: true };
  if (opts.signal) listenerOpts.signal = opts.signal;
  el.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1) { tracking = false; return; }
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
    tracking = true;
  }, listenerOpts);
  el.addEventListener("touchend", (e) => {
    if (!tracking) return;
    tracking = false;
    const t = e.changedTouches[0];
    const dx = t.clientX - startX;
    const dy = t.clientY - startY;
    // Too short, or more vertical than horizontal (a scroll, not a swipe).
    if (Math.abs(dx) < threshold || Math.abs(dx) < Math.abs(dy) * 1.5) return;
    if (dx < 0 && opts.onSwipeLeft) { opts.onSwipeLeft(); return; }
    if (dx > 0 && opts.onSwipeRight) {
      // edgeStartMaxX: only fire a right-swipe that BEGAN within this many
      // px of the left edge -- e.g. opening an off-screen drawer, where a
      // rightward drag starting mid-page more likely means a scroll or a
      // text selection than a request to open it.
      if (opts.edgeStartMaxX != null && startX > opts.edgeStartMaxX) return;
      opts.onSwipeRight();
    }
  }, listenerOpts);
};


// emptyStateHtml — a small shared set of illustrated "nothing here yet"
// states (icon + heading + message + optional action link), used for
// the one true first-run hero on each page (dashboard, journal, stats,
// edge analysis, patterns, settings ledger, practice, backtester) --
// NOT the dozens of small in-page "No data yet." fallbacks scattered
// through report/edge-analysis/stats rendering, which stay as plain
// text on purpose (illustrating every single one would be noisy, not
// helpful, for a sub-widget that's empty only because of a filter).
// Icons are a tiny inline SVG set (no external assets, no extra
// request) that reuse the app's existing --primary/--text-faint theme
// tokens, so they already adapt to the light/dark toggle.
window.EMPTY_STATE_ICONS = {
  chart: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="6" y="26" width="7" height="14" rx="1.5" fill="currentColor" opacity="0.35"/><rect x="20.5" y="16" width="7" height="24" rx="1.5" fill="currentColor" opacity="0.55"/><rect x="35" y="8" width="7" height="32" rx="1.5" fill="currentColor"/></svg>',
  journal: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="9" y="6" width="26" height="36" rx="3" stroke="currentColor" stroke-width="2.2"/><path d="M16 16h14M16 24h14M16 32h9" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" opacity="0.7"/></svg>',
  target: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="24" cy="24" r="16" stroke="currentColor" stroke-width="2.2"/><circle cx="24" cy="24" r="9.5" stroke="currentColor" stroke-width="2.2" opacity="0.7"/><circle cx="24" cy="24" r="3" fill="currentColor"/></svg>',
  wallet: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="6" y="12" width="36" height="26" rx="4" stroke="currentColor" stroke-width="2.2"/><path d="M6 20h36" stroke="currentColor" stroke-width="2.2"/><circle cx="33" cy="29" r="2.5" fill="currentColor"/></svg>',
  flask: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 6h10M20 6v13l-9.5 17a3 3 0 0 0 2.6 4.5h21.8a3 3 0 0 0 2.6-4.5L28 19V6" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><path d="M15.5 30h17" stroke="currentColor" stroke-width="2.2" opacity="0.6"/></svg>',
  puzzle: '<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17 8h8a2.5 2.5 0 0 1 0 5 2.5 2.5 0 0 0 0 5h8v8a2.5 2.5 0 0 1-5 0 2.5 2.5 0 0 0-5 0v8H8v-8a2.5 2.5 0 0 1 5 0 2.5 2.5 0 0 0 5 0v-8a2.5 2.5 0 0 1-5 0 2.5 2.5 0 0 0-5 0V8h9Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
};
window.emptyStateHtml = function emptyStateHtml(opts) {
  opts = opts || {};
  const icon = window.EMPTY_STATE_ICONS[opts.icon] || window.EMPTY_STATE_ICONS.chart;
  const title = opts.title ? `<div class="empty-state-hero-title">${opts.title}</div>` : "";
  const message = opts.message ? `<div class="empty-state-hero-msg">${opts.message}</div>` : "";
  // Primary action is a link (actionHref) or a button the page wires up itself (actionId);
  // an optional secondary link sits beside it. On phones they stack full-width.
  const btn = opts.actionHref
    ? `<a class="empty-state-hero-action" href="${opts.actionHref}">${opts.actionLabel || "Get started"}</a>`
    : opts.actionId
      ? `<button type="button" class="empty-state-hero-action" id="${opts.actionId}">${opts.actionLabel || "Get started"}</button>`
      : "";
  const second = opts.secondaryHref
    ? `<a class="empty-state-hero-action secondary" href="${opts.secondaryHref}">${opts.secondaryLabel || "Learn more"}</a>`
    : "";
  const actions = btn || second ? `<div class="empty-state-hero-actions">${btn}${second}</div>` : "";
  return `<div class="empty-state-hero"><div class="empty-state-hero-icon">${icon}</div>${title}${message}${actions}</div>`;
};

// chartThemeColors — grid/axis/text colors for the lightweight-charts
// instances (chart-indicators.js, trade.js's MACD pane, report.js's
// equity + MACD charts, edge-analysis.js, share-export.js), so they
// adapt to the light/dark toggle instead of staying hardcoded dark.
// Chart colors are handed to the canvas library as raw hex at chart
// creation time, not CSS custom properties, so this reads the same
// tokens common.css defines for each theme and returns plain values a
// createChart() call can use directly. Series colors (candles, EMAs,
// P&L green/red) are intentionally left alone -- they're tuned to work
// on either background and don't need to switch.
window.chartThemeColors = function chartThemeColors() {
  const light = document.documentElement.getAttribute("data-theme") === "light";
  // bg = the panel color the chart sits on (--panel in common.css). The chart's own
  // layout background is transparent, so anything that exports it to an image
  // (trade.html's PNG button) has to paint this behind it.
  return light
    ? { text: "#565a6b", grid: "#eceef3", border: "#dfe2ea", bg: "#ffffff" }
    : { text: "#8b98a5", grid: "#1c2127", border: "#232830", bg: "#14161c" };
};
