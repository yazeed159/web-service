// Unit tests for the journal modules (trade-notes.js, daily-notes.js,
// discipline.js, share-export.js). Run with:  node --test tests/journal.test.js
// No browser or Supabase: a tiny window/localStorage shim is installed first.
const test = require("node:test");
const assert = require("node:assert/strict");

global.window = global;
const store = {};
global.localStorage = {
  getItem: (k) => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: (k) => { delete store[k]; },
};
require("../js/utils.js");
require("../js/tag-catalog.js");
require("../js/trade-notes.js");
require("../js/daily-notes.js");
require("../js/discipline.js");
require("../js/share-export.js");

const close = (a, b, tol = 1e-9) => assert.ok(Math.abs(a - b) <= tol, `expected ${b}, got ${a}`);
const reset = () => Object.keys(store).forEach((k) => delete store[k]);

test("metrics: long trade R and planned R:R", () => {
  const t = { side: "long", entry_price: 5, shares: 100, pnl_after_comm: 38 };
  const m = TradeNotes.metrics(t, { plan_stop: 4.8, plan_target: 5.6 });
  close(m.risk_dollars, 20); close(m.r_multiple, 1.9); close(m.planned_rr, 3);
});

test("metrics: short trade uses stop above entry", () => {
  const t = { side: "short", entry_price: 10, shares: 50, pnl_after_comm: -25 };
  const m = TradeNotes.metrics(t, { plan_stop: 10.5, plan_target: 9 });
  close(m.risk_dollars, 25); close(m.r_multiple, -1); close(m.planned_rr, 2);
});

test("metrics: stop on the wrong side or missing gives nulls, not garbage", () => {
  const t = { side: "long", entry_price: 5, shares: 100, pnl_after_comm: 10 };
  assert.equal(TradeNotes.metrics(t, { plan_stop: 5.2 }).r_multiple, null);
  assert.equal(TradeNotes.metrics(t, {}).r_multiple, null);
  assert.equal(TradeNotes.metrics(t, null).risk_dollars, null);
});

test("save: dedupes tags, drops non-positive prices, deletes empty entries", () => {
  reset();
  TradeNotes.save("A", { plan_stop: -3, plan_target: "abc", setup: " Breakout ", mistakes: ["FOMO", "FOMO", " "], followed_rules: true, notes: "" });
  const e = TradeNotes.get("A");
  assert.equal(e.plan_stop, null); assert.equal(e.plan_target, null);
  assert.equal(e.setup, "Breakout"); assert.deepEqual(e.mistakes, ["FOMO"]);
  TradeNotes.save("A", { plan_stop: "", setup: "", mistakes: [], followed_rules: null, notes: "  " });
  assert.equal(TradeNotes.get("A"), null);
});

test("save: followed_rules false is kept (not treated as empty)", () => {
  reset();
  TradeNotes.save("B", { followed_rules: false });
  assert.equal(TradeNotes.get("B").followed_rules, false);
});

test("DailyNotes: round trip and empty day is removed", () => {
  reset();
  DailyNotes.save("2026-09-18", { plan: "gappers", max_loss: 50, checks: { a: true } });
  assert.equal(DailyNotes.get("2026-09-18").max_loss, 50);
  DailyNotes.save("2026-09-18", { plan: "", max_loss: "", goal: null, checks: {}, followed_plan: null });
  assert.equal(DailyNotes.get("2026-09-18"), null);
});

test("DailyNotes: checklist defaults and dedupe", () => {
  reset();
  assert.ok(DailyNotes.getChecklist().length >= 4);
  DailyNotes.setChecklist(["x", "x", " ", "y"]);
  assert.deepEqual(DailyNotes.getChecklist(), ["x", "y"]);
});

test("Discipline: no data -> null score; max-loss breach lowers it", () => {
  assert.equal(Discipline.compute([], { entries: {}, days: {} }).score, null);
  const trades = [
    { id: "1", trade_date: "2026-09-18", entry_time: "09:35", pnl_after_comm: -40, shares: 100 },
    { id: "2", trade_date: "2026-09-18", entry_time: "09:50", pnl_after_comm: -30, shares: 100 },
  ];
  const held = Discipline.compute(trades, { entries: {}, days: { "2026-09-18": { max_loss: 100 } } });
  const broke = Discipline.compute(trades, { entries: {}, days: { "2026-09-18": { max_loss: 50 } } });
  assert.ok(broke.score < held.score, `${broke.score} !< ${held.score}`);
});

const rulesOf = (r) => r.components.find((c) => c.key === "rules");
test("Discipline: auto clean-trade tags drive the rules component", () => {
  const mk = (tags) => [
    { id: "1", trade_date: "2026-09-18", entry_time: "09:35", pnl_after_comm: 5, shares: 100, behavior_tags: tags },
    { id: "2", trade_date: "2026-09-18", entry_time: "09:50", pnl_after_comm: 5, shares: 100, behavior_tags: tags },
  ];
  const good = Discipline.compute(mk(["session_open", "clean_trade"]), { entries: {}, days: {} });
  const bad = Discipline.compute(mk(["session_open", "revenge_trade"]), { entries: {}, days: {} });
  assert.ok(good.score > bad.score);
  assert.equal(rulesOf(good).value, 100);
  assert.equal(rulesOf(bad).value, 0);
  // Trades that haven't been tagged yet are left out rather than counted against you.
  const untagged = Discipline.compute(mk(null), { entries: {}, days: {} });
  assert.equal(rulesOf(untagged).n, 0);
});

test("share export: journal card present, notes HTML-escaped, R shown", () => {
  reset();
  TradeNotes.save("T1", { plan_stop: 4.8, plan_target: 5.6, setup: "Breakout", mistakes: ["Chased entry"], followed_rules: true, notes: "<img src=x onerror=alert(1)>" });
  const trade = { id: "T1", symbol: "ABCD", trade_date: "2026-09-18", entry_time: "09:35", exit_time: "09:40", entry_price: 5, exit_price: 5.4, shares: 100, pnl_before_comm: 40, pnl_after_comm: 38, commission: 2, win: true };
  const html = TradeLogShare.buildTradeSharePage(trade);
  assert.ok(html.includes("Trader's journal"));
  assert.ok(html.includes("+1.90R"));
  assert.ok(!html.includes("<img src=x"));
  assert.ok(html.includes("&lt;img"));
});

test("share export: set page shows auto flags and clean verdict, hides notes and old manual tags", () => {
  reset();
  TradeNotes.save("T1", { setup: "Breakout", followed_rules: false, notes: "secret note" });
  const rows = [
    { id: "T1", symbol: "ABCD", trade_date: "2026-09-18", entry_time: "09:35", entry_price: 5, exit_price: 5.4, shares: 100, pnl_after_comm: 38, win: true, behavior_tags: ["revenge_trade", "session_open"] },
    { id: "T2", symbol: "WXYZ", trade_date: "2026-09-18", entry_time: "09:50", entry_price: 5, exit_price: 5.4, shares: 100, pnl_after_comm: 38, win: true, behavior_tags: ["clean_trade"] },
  ];
  const html = TradeLogShare.buildSetSharePage(rows, {});
  assert.ok(html.includes("<th>Flags</th>") && html.includes("<th>Clean</th>"));
  assert.ok(html.includes("Revenge trade"));
  assert.ok(!html.includes("secret note"));
  assert.ok(!html.includes("Breakout"));
});

test("TagCatalog: every tag the guide knows has criteria, unknown tags fall back to the AI note, clean verdict", () => {
  const all = TagCatalog.all();
  assert.ok(all.length > 60);
  all.forEach((e) => assert.ok(e.label && e.summary && e.rule.length > 20, e.key));
  assert.equal(TagCatalog.tone("sold_near_high"), "good");
  assert.equal(TagCatalog.tone("revenge_trade"), "watch");
  assert.equal(TagCatalog.get("some_ai_lesson_tag").unknown, true);
  assert.equal(TagCatalog.isClean({ behavior_tags: ["clean_trade"] }), true);
  assert.equal(TagCatalog.isClean({ behavior_tags: ["rapid_fire"] }), false);
  assert.equal(TagCatalog.isClean({ behavior_tags: null }), null);
  assert.ok(TagCatalog.pillHtml("overtrading").includes('data-tag-info="overtrading"'));
});

test("TradeNotes.save keeps old manual setup/mistakes/rules when a caller doesn't mention them", () => {
  reset();
  TradeNotes.save("T9", { setup: "Breakout", mistakes: ["FOMO"], followed_rules: false, notes: "a" });
  TradeNotes.save("T9", { plan_stop: 4.5, notes: "b" });          // e.g. the note-only quick edit
  const e = TradeNotes.get("T9");
  assert.equal(e.setup, "Breakout");
  assert.deepEqual(e.mistakes, ["FOMO"]);
  assert.equal(e.followed_rules, false);
  assert.equal(e.notes, "b");
  assert.equal(typeof TradeNotes.knownTags, "undefined");
});

test("TagCatalog: colour scale runs red to green for entry/exit tags only, needs 3+ trades", () => {
  const mk = (setup, tags, pnl) => ({ setup_type: setup, behavior_tags: tags, pnl_after_comm: pnl });
  const rows = [];
  for (let i = 0; i < 4; i++) rows.push(mk("red_to_green", ["sold_near_high", "session_open"], 50));
  for (let i = 0; i < 4; i++) rows.push(mk("chase", ["sold_the_low", "session_open"], -50));
  rows.push(mk("other", ["ran_after_exit"], 10));            // only 1 trade: no colour yet
  TagCatalog.setTrades(rows);
  assert.equal(TagCatalog.colorOf("red_to_green").hue, 120);
  assert.equal(TagCatalog.colorOf("chase").hue, 0);
  assert.equal(TagCatalog.colorOf("ran_after_exit"), null);
  assert.equal(TagCatalog.colorOf("session_open"), null);     // not entry/exit related
  assert.equal(TagCatalog.colorOf("some_ai_lesson_tag"), null);
  assert.ok(TagCatalog.pillHtml("red_to_green").includes("--tg-h:120"));
  assert.ok(!TagCatalog.pillHtml("session_open").includes("tc-scored"));
});

test("TagCatalog: old tags still get an entry, and keys like 'constructor' don't break lookups", () => {
  assert.equal(TagCatalog.get("breakout").legacy, true);
  assert.equal(TagCatalog.get("breakout").group, "setup");
  assert.equal(TagCatalog.get("constructor").unknown, true);
  assert.equal(TagCatalog.get("__proto__").unknown, true);
});
