-- 004_trade_facts.sql  --  stock facts straight from the broker file
--
-- Run once in the Supabase SQL editor. Safe to re-run.
--
-- issuer_country : IBKR's IssuerCountryCode for the stock (CN, KY, US, ...)
-- sub_category   : IBKR's SubCategory (ADR, COMMON, ...)
-- Used by Reports for "P&L by country" and "ADR vs common". Trades synced before this keep
-- them empty (re-import the original statement / CSV to fill them in).

alter table public.trades
  add column if not exists issuer_country text,
  add column if not exists sub_category   text;
