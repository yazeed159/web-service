-- 003_commission_split.sql  --  real commission paid on the way IN vs. the way OUT of each trade
--
-- Run once in the Supabase SQL editor. Safe to re-run.
--
-- Why: IBKR reports a commission on every execution. The sync already matched them
-- (opening execution vs. closing execution) but only saved the combined total. These two
-- columns keep the real split so Reports can show "commission in / out" per trade.
-- commission_in + commission_out = commission. Per-execution amounts are also saved inside
-- trade_details.fills (commission_entry / commission_exit).
--
-- Trades synced BEFORE this change keep these columns empty (the per-side numbers were never
-- stored); re-import the original statement / CSV for them and the columns fill in.

alter table public.trades
  add column if not exists commission_in  numeric,
  add column if not exists commission_out numeric;
