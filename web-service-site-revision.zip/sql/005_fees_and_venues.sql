-- 005_fees_and_venues.sql  --  regulatory fees + per-exchange execution stats
--
-- Run once in the Supabase SQL editor. Safe to re-run.
--
-- fees   : SEC / FINRA TAF etc. charged on the orders behind this trade (from the statement's
--          taxes/fees section). NOT included in commission or P&L -- shown on its own.
-- venues : {"ARCA": {"sh": 1667, "comm": 8.5156}, ...}  shares executed on each exchange and the
--          commission the broker charged on them (powers Reports > "By exchange").
--
-- Trades synced before this keep both empty (re-import the original statement to fill them in).

alter table public.trades
  add column if not exists fees   numeric,
  add column if not exists venues jsonb;
